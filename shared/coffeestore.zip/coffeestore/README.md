# CoffeeStore - Premium Coffee eCommerce

A fully dynamic, production-ready Coffee Ecommerce Website built with Core PHP, MySQL (PDO), Bootstrap 5, HTML5, CSS3, JavaScript, and AJAX. The project features three distinct panels (User, Admin, Delivery) with a responsive "Premium Coffee Dark + Cream" theme.

## 🌟 Features

### 🛒 User Panel
*   **Browse & Shop**: Explore coffee blends with dynamic filtering (Category, Roast Level, Price Sort).
*   **Cart & Wishlist**: AJAX-powered add to cart and wishlist functionality without page reloads.
*   **Checkout Flow**: Apply discount coupons, choose between Cash on Delivery (COD) or dynamic UPI QR Code payment.
*   **Order Tracking**: Public order tracking page (`track.php`) to see real-time order status.
*   **Profile Management**: Update personal details and upload profile pictures.

### 🛡️ Admin Panel
*   **Dashboard**: Overview of total sales, users, orders, and active deliveries with recent order listings.
*   **Catalog Management**: Full CRUD operations for Products and Categories, including image uploads and stock management.
*   **Order Management**: View full order details, update statuses (Confirmed, Preparing, Out for delivery, Delivered), assign delivery boys, and verify UPI payment screenshots.
*   **User & Delivery Management**: View and manage customer and delivery partner accounts.
*   **Coupons**: Create dynamic discount codes with expiry dates and usage limits.
*   **Settings**: Update Store Name and UPI ID dynamically from the dashboard.

### 🛵 Delivery Panel
*   **Dashboard**: Overview of active and completed order assignments.
*   **Order Management**: View destination address, customer contact details, and payment method (to know if cash needs to be collected).
*   **Status Updates**: Mark assigned orders as "Delivered", reflecting immediately for the admin and user.

## 🛠️ Technology Stack
*   **Backend**: Core PHP (PHP 7.4+ recommended), PDO for secure database interactions.
*   **Database**: MySQL.
*   **Frontend**: HTML5, CSS3, JavaScript, jQuery, AJAX.
*   **UI Framework**: Bootstrap 5.
*   **Icons**: FontAwesome 6.

## 🚀 Installation & Setup

1. **Prerequisites**: Ensure you have a local server environment like XAMPP, WAMP, or MAMP installed.

2. **Clone/Copy Project**:
   Place the `coffeestore` folder inside your server's document root (e.g., `C:\xampp\htdocs\coffeestore`).

3. **Database Setup**:
   * Open phpMyAdmin (`http://localhost/phpmyadmin`).
   * Create a new database named `coffeestore`.
   * Import the provided `database.sql` file into the `coffeestore` database. This will create all necessary tables and insert default admin data.

4. **Configuration**:
   * Open `config/db.php`.
   * Verify the database connection details. By default, it connects to `localhost`, uses `root` as the username, and an empty password. Adjust if your local setup is different.

5. **Run the Application**:
   * Open your web browser and navigate to `http://localhost/coffeestore`.

## 🔑 Default Credentials

The `database.sql` file comes with pre-configured accounts for testing:

*   **Admin Login**:
    *   Email: `admin@coffeestore.com`
    *   Password: `password`

*   *(Optional)* Delivery Partners and Users can be registered via the frontend or added from the Admin panel.

## 📁 Folder Structure

```
coffeestore/
│
├── admin/          # Admin panel files (Dashboard, Products, Orders, etc.)
├── assets/         # CSS, JS, and Images
│   ├── css/        # Custom stylesheets (style.css)
│   ├── profile/    # Uploaded user/admin/delivery profile images
│   └── uploads/    # Uploaded product and payment proof images
├── config/         # Database configuration (db.php)
├── delivery/       # Delivery boy panel files
├── includes/       # Shared files (header, footer, navbar, functions)
├── user/           # User portal and frontend pages (Shop, Cart, Checkout, etc.)
│
├── database.sql    # Database schema and initial data
├── index.php       # Root redirect to user frontend
└── README.md       # Project documentation
```

## 🔒 Security Implementations
*   **Password Hashing**: `password_hash()` and `password_verify()` used for all accounts.
*   **SQL Injection Prevention**: Exclusive use of PDO Prepared Statements.
*   **XSS Protection**: Consistent use of `htmlspecialchars()` when outputting database content.
*   **Access Control**: Session-based middleware functions (`requireAdmin()`, `requireUser()`, `requireDelivery()`) blocking unauthorized page access.

---
Enjoy building and extending CoffeeStore! ☕
