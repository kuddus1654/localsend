<?php
$page_title = "UPI Payment";
require_once '../includes/header.php';
require_once '../includes/navbar.php';
requireUser();

$user_id = $_SESSION['user_id'];
$total = $_SESSION['cart_total'] ?? 0;

if ($total == 0 || !isset($_SESSION['checkout_method']) || $_SESSION['checkout_method'] != 'UPI') {
    redirect('checkout.php');
}

$settings = getSettings($pdo);
$upi_id = $settings['upi_id'];
$store_name = rawurlencode($settings['store_name']);
$amount = number_format($total, 2, '.', '');

// Generate UPI deep link
$upi_url = "upi://pay?pa={$upi_id}&pn={$store_name}&am={$amount}&cu=INR";
// API for QR Code
$qr_url = "https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=" . urlencode($upi_url);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $txn_id = trim($_POST['transaction_id']);

    // Upload screenshot
    $proof = null;
    if (isset($_FILES['payment_proof']) && $_FILES['payment_proof']['error'] == 0) {
        $ext = strtolower(pathinfo($_FILES['payment_proof']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg', 'jpeg', 'png']) && $_FILES['payment_proof']['size'] <= 2097152) {
            $new_name = 'pmt_' . $user_id . '_' . time() . '.' . $ext;
            if (move_uploaded_file($_FILES['payment_proof']['tmp_name'], "../assets/uploads/" . $new_name)) {
                $proof = $new_name;
            }
        }
    }

    if (empty($txn_id) || empty($proof)) {
        flash('error', 'Transaction ID and Payment Screenshot are required.');
    } else {
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("INSERT INTO orders (user_id, total_amount, payment_method, payment_status, payment_proof, transaction_id, order_status) VALUES (?, ?, 'UPI', 'Verification Pending', ?, ?, 'Confirmed')");
            $stmt->execute([$user_id, $total, $proof, $txn_id]);
            $order_id = $pdo->lastInsertId();

            $stmt = $pdo->prepare("SELECT c.quantity, p.id, p.price, p.discount_price FROM cart c JOIN products p ON c.product_id = p.id WHERE c.user_id = ?");
            $stmt->execute([$user_id]);
            $items = $stmt->fetchAll();

            foreach ($items as $item) {
                $price = $item['discount_price'] ? $item['discount_price'] : $item['price'];
                $pdo->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)")->execute([$order_id, $item['id'], $item['quantity'], $price]);
                $pdo->prepare("UPDATE products SET stock = stock - ? WHERE id = ?")->execute([$item['quantity'], $item['id']]);
            }

            $pdo->prepare("DELETE FROM cart WHERE user_id = ?")->execute([$user_id]);
            unset($_SESSION['cart_total']);
            unset($_SESSION['checkout_method']);
            unset($_SESSION['checkout_address']);

            if (isset($_SESSION['coupon'])) {
                $pdo->prepare("UPDATE coupons SET times_used = times_used + 1 WHERE id = ?")->execute([$_SESSION['coupon']['id']]);
                unset($_SESSION['coupon']);
            }

            $pdo->commit();
            flash('success', 'Order placed successfully! Subject to payment verification.');
            redirect('orders.php');
        } catch (PDOException $e) {
            $pdo->rollBack();
            flash('error', 'Checkout failed. ' . $e->getMessage());
        }
    }
}
?>

<div class="container my-5 flex-grow-1">
    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            <div class="card p-4 border-0 shadow" style="border-top: 5px solid var(--accent-color) !important;">
                <h3 class="text-center text-primary fw-bold mb-4"><i class="fa-solid fa-qrcode"></i> UPI Secure Payment
                </h3>

                <div class="text-center mb-4">
                    <div class="qr-container bg-light d-inline-block rounded p-3 mb-3 shadow-sm border">
                        <img src="<?= $qr_url ?>" alt="UPI QR Code" class="img-fluid rounded">
                    </div>

                    <h5 class="fw-bold mb-1">UPI ID: <span class="text-accent">
                            <?= htmlspecialchars($settings['upi_id']) ?>
                        </span></h5>
                    <h4 class="fw-bold text-success mb-3">Amount to Pay: ₹
                        <?= number_format($total, 2) ?>
                    </h4>
                    <p class="text-muted small">Scan the QR code with any UPI app (GPay, PhonePe, Paytm, etc.) or
                        manually copy the UPI ID to make the payment.</p>
                </div>

                <hr class="mb-4">

                <form method="POST" action="" enctype="multipart/form-data">
                    <h5 class="fw-bold mb-3"><i class="fa-solid fa-check-circle text-primary"></i> Verification Details
                    </h5>
                    <div class="mb-3">
                        <label class="form-label text-muted fw-bold">12-Digit Transaction / UTR No.</label>
                        <input type="text" name="transaction_id" class="form-control form-control-lg"
                            placeholder="e.g. 123456789012" required>
                    </div>
                    <div class="mb-4">
                        <label class="form-label text-muted fw-bold">Upload Payment Screenshot</label>
                        <input type="file" name="payment_proof" class="form-control form-control-lg"
                            accept=".jpg,.jpeg,.png" required>
                        <small class="text-danger mt-1 d-block"><i class="fa-solid fa-triangle-exclamation"></i> Must
                            clearly show Transaction ID and Amount Paid.</small>
                    </div>
                    <button type="submit" class="btn btn-primary btn-lg w-100 shadow">Submit Payment Proof</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>