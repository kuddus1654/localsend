<?php
session_start();
unset($_SESSION['user_id']);
unset($_SESSION['user_name']);
$_SESSION['flash']['success'] = "Logged out successfully.";
header("Location: /coffeestore/user/login.php");
exit;
