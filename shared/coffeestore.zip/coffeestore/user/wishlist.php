<?php
$page_title = "My Wishlist";
require_once '../includes/header.php';
require_once '../includes/navbar.php';
requireUser();

// Remove from wishlist
if (isset($_GET['remove'])) {
    $id = (int) $_GET['remove'];
    $pdo->prepare("DELETE FROM wishlist WHERE id = ? AND user_id = ?")->execute([$id, $_SESSION['user_id']]);
    flash('success', 'Item removed from wishlist.');
    redirect('wishlist.php');
}

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT w.id as wishlist_id, p.*, c.name as category_name FROM wishlist w JOIN products p ON w.product_id = p.id JOIN categories c ON p.category_id = c.id WHERE w.user_id = ? ORDER BY w.created_at DESC");
$stmt->execute([$user_id]);
$items = $stmt->fetchAll();
?>
<div class="container my-5 flex-grow-1">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-primary m-0 fw-bold"><i class="fa-solid fa-heart me-2 text-danger"></i> My Wishlist</h2>
        <span class="text-muted border bg-white rounded px-3 py-1">
            <?= count($items) ?> items
        </span>
    </div>

    <div class="row g-4">
        <?php if (count($items) > 0): ?>
            <?php foreach ($items as $p): ?>
                <div class="col-md-3 col-sm-6">
                    <div class="card h-100 product-card shadow-sm border-0 position-relative" style="transition: 0.3s;"
                        onmouseover="this.classList.add('shadow');" onmouseout="this.classList.remove('shadow');">
                        <?php if ($p['discount_price']): ?>
                            <div class="position-absolute top-0 end-0 bg-danger text-white px-3 py-1 m-2 rounded-pill fw-bold z-1"
                                style="font-size: 0.8rem;">SALE</div>
                        <?php endif; ?>
                        <a href="wishlist.php?remove=<?= $p['wishlist_id'] ?>"
                            class="btn btn-light rounded-circle shadow-sm position-absolute top-0 start-0 m-2 z-1 text-danger border-0 hover-danger"
                            onclick="return confirm('Remove from wishlist?');">
                            <i class="fa-solid fa-trash"></i>
                        </a>
                        <img src="/coffeestore/assets/uploads/<?= htmlspecialchars($p['image']) ?>" class="card-img-top"
                            alt="<?= htmlspecialchars($p['name']) ?>">
                        <div class="card-body d-flex flex-column">
                            <small class="text-muted mb-1">
                                <?= htmlspecialchars($p['category_name']) ?> &bull; <span
                                    class="badge bg-light text-dark border">
                                    <?= $p['roast_level'] ?> Roast
                                </span>
                            </small>
                            <h5 class="card-title fw-bold text-dark">
                                <?= htmlspecialchars($p['name']) ?>
                            </h5>
                            <div class="mt-auto pt-3 border-top d-flex justify-content-between align-items-center">
                                <div class="price-wrap">
                                    <?php if ($p['discount_price']): ?>
                                        <span class="fs-5 fw-bold text-success">₹
                                            <?= number_format($p['discount_price'], 2) ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="fs-5 fw-bold text-primary">₹
                                            <?= number_format($p['price'], 2) ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <?php if ($p['stock'] > 0): ?>
                                    <button class="btn btn-sm btn-primary add-to-cart rounded-pill px-3"
                                        data-id="<?= $p['id'] ?>"><i class="fa-solid fa-cart-plus me-1"></i> Add</button>
                                <?php else: ?>
                                    <span class="badge bg-danger p-2 rounded-pill">Out of Stock</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12 py-5 text-center bg-white rounded shadow-sm border-0">
                <i class="fa-regular fa-heart fa-4x text-muted mb-3 opacity-50"></i>
                <h4 class="text-muted">Your wishlist is empty!</h4>
                <a href="shop.php" class="btn btn-primary mt-3 px-4">Explore Products</a>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
    .hover-danger:hover {
        background-color: #dc3545 !important;
        color: white !important;
    }
</style>

<script>
    $(document).ready(function () {
        $('.add-to-cart').click(function (e) {
            e.preventDefault();
            var btn = $(this);
            var originalText = btn.html();
            btn.html('<i class="fa-solid fa-spinner fa-spin"></i>').prop('disabled', true);

            var id = $(this).data('id');
            $.post('ajax_cart.php', { action: 'add', product_id: id, quantity: 1 }, function (res) {
                let data = JSON.parse(res);
                if (data.status == 'success') {
                    $('#cart-count').text(data.count);
                    btn.html('<i class="fa-solid fa-check me-1"></i> Added').removeClass('btn-primary').addClass('btn-success');
                    setTimeout(() => { btn.html(originalText).prop('disabled', false).removeClass('btn-success').addClass('btn-primary'); }, 2000);
                } else {
                    alert(data.message);
                    btn.html(originalText).prop('disabled', false);
                }
            });
        });
    });
</script>
<?php require_once '../includes/footer.php'; ?>