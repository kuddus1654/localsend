<?php
$page_title = "Login";
require_once '../includes/header.php';
require_once '../includes/navbar.php';

if (isUser())
    redirect('/coffeestore/user/index.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        flash('error', 'All fields are required.');
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            flash('success', 'Welcome back, ' . htmlspecialchars($user['name']));
            redirect('/coffeestore/user/index.php');
        } else {
            flash('error', 'Invalid email or password.');
        }
    }
}
?>
<div class="container my-5 flex-grow-1">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-5">
            <div class="card p-4">
                <h3 class="text-center mb-4"><i class="fa-solid fa-right-to-bracket text-accent"></i> Login</h3>
                <form method="POST" action="">
                    <div class="mb-3">
                        <label class="form-label">Email Address</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="mb-4">
                        <label class="form-label">Password</label>
                        <div class="input-group">
                            <input type="password" name="password" id="loginPassword" class="form-control" required>
                            <button class="btn btn-outline-secondary toggle-password" type="button"
                                data-target="#loginPassword">
                                <i class="fa-regular fa-eye"></i>
                            </button>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Login</button>
                </form>
                <div class="text-center mt-3">
                    Don't have an account? <a href="register.php"
                        class="text-accent fw-bold text-decoration-none">Register here</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>