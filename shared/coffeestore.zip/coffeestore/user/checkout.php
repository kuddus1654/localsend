<?php
$page_title = "Checkout";
require_once '../includes/header.php';
require_once '../includes/navbar.php';
requireUser();

$user_id = $_SESSION['user_id'];
$total = $_SESSION['cart_total'] ?? 0;

if ($total == 0) {
    flash('error', 'Your cart is empty.');
    redirect('cart.php');
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $payment_method = $_POST['payment_method']; // COD or UPI
    $address = trim($_POST['address']);

    if (empty($address)) {
        flash('error', 'Delivery Address is required.');
        redirect('checkout.php');
    }

    // Update user address
    $pdo->prepare("UPDATE users SET address = ? WHERE id = ?")->execute([$address, $user_id]);

    if ($payment_method == 'UPI') {
        // Save order details to process after verifying UPI
        $_SESSION['checkout_method'] = 'UPI';
        $_SESSION['checkout_address'] = $address;
        redirect('payment.php');
    } else {
        // COD
        try {
            $pdo->beginTransaction();
            // Insert Order
            $stmt = $pdo->prepare("INSERT INTO orders (user_id, total_amount, payment_method, payment_status, order_status) VALUES (?, ?, 'COD', 'Verification Pending', 'Confirmed')");
            $stmt->execute([$user_id, $total]);
            $order_id = $pdo->lastInsertId();

            // Insert Items & Deduct Stock
            $stmt = $pdo->prepare("SELECT c.quantity, p.id, p.price, p.discount_price FROM cart c JOIN products p ON c.product_id = p.id WHERE c.user_id = ?");
            $stmt->execute([$user_id]);
            $items = $stmt->fetchAll();

            foreach ($items as $item) {
                $price = $item['discount_price'] ? $item['discount_price'] : $item['price'];
                $pdo->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)")->execute([$order_id, $item['id'], $item['quantity'], $price]);
                $pdo->prepare("UPDATE products SET stock = stock - ? WHERE id = ?")->execute([$item['quantity'], $item['id']]);
            }

            // Clear Cart & Coupon
            $pdo->prepare("DELETE FROM cart WHERE user_id = ?")->execute([$user_id]);
            unset($_SESSION['cart_total']);

            if (isset($_SESSION['coupon'])) {
                $pdo->prepare("UPDATE coupons SET times_used = times_used + 1 WHERE id = ?")->execute([$_SESSION['coupon']['id']]);
                unset($_SESSION['coupon']);
            }

            $pdo->commit();
            flash('success', 'Order placed successfully via Cash on Delivery!');
            redirect('orders.php');
        } catch (PDOException $e) {
            $pdo->rollBack();
            flash('error', 'Checkout failed. Please try again.');
        }
    }
}
?>

<div class="container my-5 flex-grow-1">
    <h2 class="text-primary mb-4 fw-bold"><i class="fa-solid fa-credit-card me-2"></i> Checkout</h2>
    <div class="row">
        <div class="col-md-7">
            <div class="card p-4 border-0 shadow-sm mb-4">
                <h4 class="mb-4">Shipping & Delivery Details</h4>
                <form method="POST" action="">
                    <div class="mb-3">
                        <label class="form-label text-muted fw-bold">Full Name</label>
                        <input type="text" class="form-control" value="<?= htmlspecialchars($user['name']) ?>" readonly>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted fw-bold">Contact Number</label>
                        <input type="text" class="form-control" value="<?= htmlspecialchars($user['phone']) ?>"
                            readonly>
                    </div>
                    <div class="mb-4">
                        <label class="form-label text-muted fw-bold">Complete Delivery Address</label>
                        <textarea name="address" class="form-control" rows="4"
                            placeholder="Enter house no, street, area, city, pincode"
                            required><?= htmlspecialchars($user['address'] ?? '') ?></textarea>
                    </div>

                    <h4 class="mb-3 mt-5">Payment Method</h4>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label
                                class="card border border-2 border-primary rounded p-3 text-center cursor-pointer radio-card">
                                <input type="radio" name="payment_method" value="UPI" class="d-none radio-input"
                                    required>
                                <i class="fa-solid fa-qrcode fa-2x text-primary mb-2"></i>
                                <h6 class="m-0 fw-bold">Pay via UPI</h6>
                                <small class="text-muted">GPay, PhonePe, Paytm</small>
                            </label>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="card border border-2 rounded p-3 text-center cursor-pointer radio-card">
                                <input type="radio" name="payment_method" value="COD" class="d-none radio-input"
                                    required>
                                <i class="fa-solid fa-money-bill-wave fa-2x text-success mb-2"></i>
                                <h6 class="m-0 fw-bold">Cash on Delivery</h6>
                                <small class="text-muted">Pay at doorstep</small>
                            </label>
                        </div>
                    </div>

                    <button class="btn btn-primary btn-lg w-100 mt-4 shadow" type="submit">Place Order / Proceed to
                        Pay</button>
                </form>
            </div>
        </div>

        <div class="col-md-5">
            <div class="card p-4 border-0 shadow-sm sticky-top"
                style="top: 80px; z-index:10; background-color: var(--bg-color);">
                <h4 class="mb-4 fw-bold text-primary">Order Summary</h4>
                <div
                    class="d-flex justify-content-between align-items-center bg-white p-3 rounded shadow-sm border mb-3">
                    <span class="fs-5 fw-bold text-dark">Amount Payable</span>
                    <span class="fs-3 fw-bold text-success">₹
                        <?= number_format($total, 2) ?>
                    </span>
                </div>
                <!-- Mini Cart items preview -->
                <?php
                $stmt = $pdo->prepare("SELECT c.quantity, p.name, p.image FROM cart c JOIN products p ON c.product_id = p.id WHERE c.user_id = ?");
                $stmt->execute([$user_id]);
                $items = $stmt->fetchAll();
                ?>
                <h6 class="mt-4 mb-3 text-muted">Items included (
                    <?= count($items) ?> unique items)
                </h6>
                <ul class="list-group list-group-flush rounded border">
                    <?php foreach ($items as $i): ?>
                        <li class="list-group-item d-flex align-items-center">
                            <img src="/coffeestore/assets/uploads/<?= htmlspecialchars($i['image']) ?>" width="40"
                                height="40" class="rounded me-3 object-fit-cover border">
                            <div>
                                <span class="d-block fw-bold">
                                    <?= htmlspecialchars($i['name']) ?>
                                </span>
                                <small class="text-muted">Qty:
                                    <?= $i['quantity'] ?>
                                </small>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
</div>

<style>
    .cursor-pointer {
        cursor: pointer;
    }

    .radio-input:checked+i+h6+small {
        /* target siblings if needed */
    }

    .radio-input:checked~h6,
    .radio-input:checked~i,
    .radio-input:checked~small {}

    .radio-card:has(input:checked) {
        background-color: rgba(200, 169, 81, 0.1);
        /* accent low opacity */
        border-color: var(--primary-color) !important;
    }

    .radio-card:not(:has(input:checked)) {
        border-color: #dee2e6 !important;
    }

    /* Fallback for browsers not supporting :has() */
    .radio-active-fallback {
        background-color: rgba(200, 169, 81, 0.1);
        border-color: var(--primary-color) !important;
    }
</style>

<script>
    $(document).ready(function () {
        $('.radio-input').change(function () {
            $('.radio-card').removeClass('radio-active-fallback').css('border-color', '#dee2e6');
            $(this).parent('.radio-card').addClass('radio-active-fallback').css('border-color', 'var(--primary-color)');
        });
    });
</script>
<?php require_once '../includes/footer.php'; ?>