<?php
$page_title = "Home";
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();
$featured = $pdo->query("SELECT p.*, c.name as category_name FROM products p JOIN categories c ON p.category_id = c.id ORDER BY p.created_at DESC LIMIT 8")->fetchAll();
?>
<!-- Hero Section -->
<section class="hero text-white position-relative"
    style="background: url('https://images.unsplash.com/photo-1497935586351-b67a49e012bf?auto=format&fit=crop&q=80&w=1920') no-repeat center center/cover; min-height: 60vh;">
    <div class="position-absolute w-100 h-100 bg-dark" style="opacity: 0.6;"></div>
    <div class="container position-relative h-100 d-flex flex-column justify-content-center" style="min-height: 60vh;">
        <div class="row w-100">
            <div class="col-md-8 col-lg-6">
                <h1 class="display-3 fw-bold text-white mb-3">Premium Coffee Delivered Hot</h1>
                <p class="lead mb-4">Experience the rich aroma and bold flavors of our freshly roasted coffee beans.
                    Sourced globally, crafted locally.</p>
                <a href="shop.php" class="btn btn-accent btn-lg px-5 shadow">Shop Now <i
                        class="fa-solid fa-arrow-right ms-2"></i></a>
            </div>
        </div>
    </div>
</section>

<!-- Categories -->
<section class="py-5 bg-light">
    <div class="container text-center">
        <h2 class="mb-5 fw-bold text-primary">Explore Our Blends</h2>
        <div class="row justify-content-center g-4">
            <?php foreach ($categories as $c): ?>
                <div class="col-6 col-md-3">
                    <a href="shop.php?category=<?= $c['id'] ?>" class="text-decoration-none">
                        <div class="card p-4 border-0 shadow-sm category-card text-center"
                            style="border-radius: 20px; transition: 0.3s; cursor:pointer;"
                            onmouseover="this.classList.add('shadow');" onmouseout="this.classList.remove('shadow');">
                            <i class="fa-solid fa-mug-saucer fa-3x text-accent mb-3"></i>
                            <h5 class="text-dark m-0 fw-bold">
                                <?= htmlspecialchars($c['name']) ?>
                            </h5>
                        </div>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Featured Products -->
<section class="py-5">
    <div class="container">
        <div class="d-flex justify-content-between align-items-end mb-4">
            <h2 class="fw-bold text-primary m-0">Featured Picks</h2>
            <a href="shop.php" class="text-accent fw-bold text-decoration-none">View All Products</a>
        </div>
        <div class="row g-4">
            <?php foreach ($featured as $p): ?>
                <div class="col-md-3 col-sm-6">
                    <div class="card h-100 product-card shadow-sm border-0 position-relative">
                        <?php if ($p['discount_price']): ?>
                            <div class="position-absolute top-0 end-0 bg-danger text-white px-3 py-1 m-2 rounded-pill fw-bold z-1"
                                style="font-size: 0.8rem;">SALE</div>
                        <?php endif; ?>
                        <img src="/coffeestore/assets/uploads/<?= htmlspecialchars($p['image']) ?>" class="card-img-top"
                            alt="<?= htmlspecialchars($p['name']) ?>">
                        <div class="card-body d-flex flex-column">
                            <small class="text-muted mb-1">
                                <?= htmlspecialchars($p['category_name']) ?> &bull;
                                <?= $p['roast_level'] ?> Roast
                            </small>
                            <h5 class="card-title fw-bold text-dark">
                                <?= htmlspecialchars($p['name']) ?>
                            </h5>
                            <div class="mt-auto d-flex justify-content-between align-items-center pt-3 border-top">
                                <div class="price-wrap">
                                    <?php if ($p['discount_price']): ?>
                                        <span class="fs-5 fw-bold text-success">₹
                                            <?= number_format($p['discount_price'], 2) ?>
                                        </span>
                                        <small class="text-muted text-decoration-line-through ms-1">₹
                                            <?= number_format($p['price'], 2) ?>
                                        </small>
                                    <?php else: ?>
                                        <span class="fs-5 fw-bold text-primary">₹
                                            <?= number_format($p['price'], 2) ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <?php if ($p['stock'] > 0): ?>
                                    <button class="btn btn-sm btn-outline-primary add-to-cart" data-id="<?= $p['id'] ?>"><i
                                            class="fa-solid fa-cart-plus"></i></button>
                                <?php else: ?>
                                    <span class="badge bg-danger">Out of Stock</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Promo Banner -->
<section class="py-5 bg-primary text-white text-center">
    <div class="container py-4">
        <h2 class="display-5 fw-bold mb-3 text-accent">Get 20% Off Your First Order!</h2>
        <p class="lead mb-4">Use code <strong>WELCOME20</strong> at checkout on orders over ₹500.</p>
        <a href="shop.php" class="btn btn-light btn-lg fw-bold text-primary px-5 shadow">Claim Offer</a>
    </div>
</section>

<!-- Testimonials -->
<section class="py-5 bg-light">
    <div class="container text-center">
        <h2 class="mb-5 fw-bold text-primary">What Coffeelovers Say</h2>
        <div class="row g-4 justify-content-center">
            <div class="col-md-4">
                <div class="card p-4 border-0 shadow-sm h-100"
                    style="border-top: 4px solid var(--accent-color) !important;">
                    <div class="text-warning mb-3">
                        <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i
                            class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i
                            class="fa-solid fa-star"></i>
                    </div>
                    <p class="text-muted fst-italic">"Absolutely the best coffee I've ever had. The Dark Roast is
                        incredibly smooth!"</p>
                    <h6 class="fw-bold mt-auto pt-3 m-0">- Sarah L.</h6>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-4 border-0 shadow-sm h-100"
                    style="border-top: 4px solid var(--accent-color) !important;">
                    <div class="text-warning mb-3">
                        <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i
                            class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i
                            class="fa-solid fa-star-half-stroke"></i>
                    </div>
                    <p class="text-muted fst-italic">"Fast delivery and amazing packaging. The whole beans were
                        perfectly fresh."</p>
                    <h6 class="fw-bold mt-auto pt-3 m-0">- James M.</h6>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card p-4 border-0 shadow-sm h-100"
                    style="border-top: 4px solid var(--accent-color) !important;">
                    <div class="text-warning mb-3">
                        <i class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i
                            class="fa-solid fa-star"></i><i class="fa-solid fa-star"></i><i
                            class="fa-solid fa-star"></i>
                    </div>
                    <p class="text-muted fst-italic">"My morning routine is saved! Prices are reasonable for such high
                        quality."</p>
                    <h6 class="fw-bold mt-auto pt-3 m-0">- Priya K.</h6>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
    $(document).ready(function () {
        $('.add-to-cart').click(function () {
        <?php if (!isUser()): ?>
                    window.location.href = 'login.php';
                return;
        <?php endif; ?>
        
        var btn = $(this);
            var originalText = btn.html();
            btn.html('<i class="fa-solid fa-spinner fa-spin"></i>').prop('disabled', true);

            var id = $(this).data('id');
            $.post('ajax_cart.php', { action: 'add', product_id: id, quantity: 1 }, function (res) {
                let data = JSON.parse(res);
                if (data.status == 'success') {
                    $('#cart-count').text(data.count);
                    btn.html('<i class="fa-solid fa-check"></i>').removeClass('btn-outline-primary').addClass('btn-success');
                    setTimeout(() => { btn.html(originalText).prop('disabled', false).removeClass('btn-success').addClass('btn-outline-primary'); }, 2000);
                } else {
                    alert(data.message);
                    btn.html(originalText).prop('disabled', false);
                }
            });
        });
    });
</script>
<?php require_once '../includes/footer.php'; ?>