<?php
$page_title = "Shopping Cart";
require_once '../includes/header.php';
require_once '../includes/navbar.php';
requireUser();

$user_id = $_SESSION['user_id'];

// Handle Coupon Application
if (isset($_POST['apply_coupon'])) {
    $code = strtoupper(trim($_POST['coupon_code']));
    $stmt = $pdo->prepare("SELECT * FROM coupons WHERE code = ? AND expiry_date >= CURDATE() AND (usage_limit = 0 OR times_used < usage_limit)");
    $stmt->execute([$code]);
    $coupon = $stmt->fetch();

    if ($coupon) {
        $_SESSION['coupon'] = $coupon;
        flash('success', 'Coupon applied successfully!');
    } else {
        flash('error', 'Invalid or expired coupon.');
        unset($_SESSION['coupon']);
    }
    redirect('cart.php');
}

// Handle Remove Coupon
if (isset($_GET['remove_coupon'])) {
    unset($_SESSION['coupon']);
    flash('success', 'Coupon removed.');
    redirect('cart.php');
}

// Fetch Cart Items
$stmt = $pdo->prepare("SELECT c.id as cart_id, c.quantity, p.*, cat.name as category_name FROM cart c JOIN products p ON c.product_id = p.id JOIN categories cat ON p.category_id = cat.id WHERE c.user_id = ?");
$stmt->execute([$user_id]);
$cart_items = $stmt->fetchAll();

$subtotal = 0;
foreach ($cart_items as $item) {
    $price = $item['discount_price'] ? $item['discount_price'] : $item['price'];
    $subtotal += $price * $item['quantity'];
}

$discount_amount = 0;
if (isset($_SESSION['coupon']) && $subtotal > 0) {
    $discount_amount = ($subtotal * $_SESSION['coupon']['discount_percent']) / 100;
}

$total = $subtotal - $discount_amount;
$_SESSION['cart_total'] = $total;
?>

<div class="container my-5 flex-grow-1">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-primary m-0 fw-bold"><i class="fa-solid fa-cart-shopping me-2"></i> Your Cart</h2>
        <span class="text-muted border bg-white rounded px-3 py-1">
            <?= count($cart_items) ?> unique items
        </span>
    </div>

    <?php if (count($cart_items) > 0): ?>
        <div class="row">
            <!-- Cart Items List -->
            <div class="col-lg-8 mb-4">
                <div class="card p-4 border-0 shadow-sm">
                    <div class="table-responsive">
                        <table class="table align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Product</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Total</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($cart_items as $item):
                                    $price = $item['discount_price'] ? $item['discount_price'] : $item['price'];
                                    $item_total = $price * $item['quantity'];
                                    ?>
                                    <tr id="cart-row-<?= $item['id'] ?>">
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <img src="/coffeestore/assets/uploads/<?= htmlspecialchars($item['image']) ?>"
                                                    class="cart-img me-3 border" alt="Product Image">
                                                <div>
                                                    <h6 class="mb-1 fw-bold text-dark">
                                                        <?= htmlspecialchars($item['name']) ?>
                                                    </h6>
                                                    <small class="text-muted">
                                                        <?= htmlspecialchars($item['category_name']) ?> &bull;
                                                        <?= $item['roast_level'] ?>
                                                    </small>
                                                </div>
                                            </div>
                                        </td>
                                        <td><span class="fw-bold">₹
                                                <?= number_format($price, 2) ?>
                                            </span></td>
                                        <td>
                                            <div class="input-group input-group-sm" style="width: 110px;">
                                                <button class="btn btn-outline-secondary px-2 update-qty"
                                                    data-id="<?= $item['id'] ?>" data-action="decrease">-</button>
                                                <input type="number" class="form-control text-center px-0 qty-input"
                                                    id="qty-<?= $item['id'] ?>" value="<?= $item['quantity'] ?>" min="1"
                                                    max="<?= $item['stock'] ?>" readonly>
                                                <button class="btn btn-outline-secondary px-2 update-qty"
                                                    data-id="<?= $item['id'] ?>" data-action="increase" <?= $item['quantity'] >= $item['stock'] ? 'disabled' : '' ?>>+</button>
                                            </div>
                                        </td>
                                        <td><span class="fw-bold text-primary">₹
                                                <?= number_format($item_total, 2) ?>
                                            </span></td>
                                        <td>
                                            <button class="btn btn-sm btn-light text-danger remove-item"
                                                data-id="<?= $item['id'] ?>" title="Remove">
                                                <i class="fa-solid fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="mt-3">
                        <a href="shop.php" class="text-decoration-none fw-bold"><i class="fa-solid fa-arrow-left me-1"></i>
                            Continue Shopping</a>
                    </div>
                </div>
            </div>

            <!-- Order Summary & Checkout -->
            <div class="col-lg-4">
                <div class="card p-4 border-0 shadow-sm sticky-top" style="top: 80px; z-index:10;">
                    <h5 class="fw-bold mb-4 border-bottom pb-2">Order Summary</h5>

                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-muted">Subtotal</span>
                        <span class="fw-bold">₹
                            <?= number_format($subtotal, 2) ?>
                        </span>
                    </div>

                    <?php if (isset($_SESSION['coupon'])): ?>
                        <div class="d-flex justify-content-between mb-2 text-success">
                            <span>Discount (
                                <?= $_SESSION['coupon']['code'] ?> -
                                <?= $_SESSION['coupon']['discount_percent'] ?>%)
                            </span>
                            <span>- ₹
                                <?= number_format($discount_amount, 2) ?>
                            </span>
                        </div>
                        <div class="text-end mb-3">
                            <a href="cart.php?remove_coupon=1" class="text-danger small text-decoration-none">Remove Coupon</a>
                        </div>
                    <?php endif; ?>

                    <hr>
                    <div class="d-flex justify-content-between mb-4">
                        <h5 class="fw-bold m-0">Total</h5>
                        <h4 class="fw-bold text-primary m-0">₹
                            <?= number_format($total, 2) ?>
                        </h4>
                    </div>

                    <?php if (!isset($_SESSION['coupon'])): ?>
                        <form method="POST" action="" class="mb-4">
                            <label class="form-label small fw-bold text-muted">Have a coupon?</label>
                            <div class="input-group">
                                <input type="text" name="coupon_code" class="form-control text-uppercase"
                                    placeholder="Enter code" required>
                                <button class="btn btn-outline-primary" type="submit" name="apply_coupon">Apply</button>
                            </div>
                        </form>
                    <?php endif; ?>

                    <a href="checkout.php" class="btn btn-accent btn-lg w-100 fw-bold shadow-sm">Proceed to Checkout <i
                            class="fa-solid fa-lock ms-2"></i></a>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="text-center py-5 bg-white rounded shadow-sm border-0">
            <i class="fa-solid fa-cart-shopping fa-5x text-muted mb-4 opacity-50"></i>
            <h3 class="text-muted">Your cart is currently empty.</h3>
            <p class="text-muted mb-4">Looks like you haven't added any premium coffee to your cart yet.</p>
            <a href="shop.php" class="btn btn-primary btn-lg px-5">Go to Shop</a>
        </div>
    <?php endif; ?>
</div>

<script>
    $(document).ready(function () {
        $('.update-qty').click(function () {
            var btn = $(this);
            var id = btn.data('id');
            var action = btn.data('action');
            var input = $('#qty-' + id);
            var currentQty = parseInt(input.val());
            var maxQty = parseInt(input.attr('max'));

            var newQty = currentQty;
            if (action === 'increase' && currentQty < maxQty) newQty++;
            if (action === 'decrease' && currentQty > 1) newQty--;

            if (newQty !== currentQty) {
                $.post('ajax_cart.php', { action: 'update_qty', product_id: id, quantity: newQty }, function (res) {
                    location.reload(); // Reload to update totals cleanly
                });
            }
        });

        $('.remove-item').click(function () {
            if (confirm('Remove this item from your cart?')) {
                var id = $(this).data('id');
                $.post('ajax_cart.php', { action: 'remove', product_id: id }, function (res) {
                    location.reload();
                });
            }
        });
    });
</script>
<?php require_once '../includes/footer.php'; ?>