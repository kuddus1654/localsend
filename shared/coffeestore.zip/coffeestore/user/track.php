<?php
$page_title = "Track Order";
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$order = null;
$searched = false;

if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['order_id'])) {
    $searched = true;
    $order_id_raw = trim($_POST['order_id']);

    // Extract numbers in case they typed "ORD-00012" or "#12"
    preg_match('/\d+/', $order_id_raw, $matches);
    $search_id = isset($matches[0]) ? (int) $matches[0] : 0;

    $stmt = $pdo->prepare("SELECT o.*, d.name as delivery_name, d.phone as delivery_phone FROM orders o LEFT JOIN delivery_boys d ON o.delivery_boy_id = d.id WHERE o.id = ?");
    $stmt->execute([$search_id]);
    $order = $stmt->fetch();

    if (!$order) {
        flash('error', 'Order not found. Please review the Order ID and try again.');
    }
}
?>

<div class="container my-5 flex-grow-1">
    <div class="row justify-content-center mb-5">
        <div class="col-md-8 text-center pt-4">
            <h2 class="fw-bold text-primary mb-3"><i class="fa-solid fa-truck-fast me-2"></i> Track Your Coffee</h2>
            <p class="text-muted mb-4 fs-5">Enter your Order ID below to check the real-time delivery status.</p>

            <form method="POST" action="" class="bg-white p-4 rounded shadow-sm border mx-auto"
                style="max-width: 550px;">
                <div class="input-group input-group-lg">
                    <span class="input-group-text bg-light text-muted border-end-0 fw-bold"
                        id="basic-addon1">#ORD-</span>
                    <input type="text" name="order_id" class="form-control border-start-0 ps-0" placeholder="e.g. 00012"
                        required autofocus
                        value="<?= isset($_POST['order_id']) ? htmlspecialchars($_POST['order_id']) : '' ?>">
                    <button class="btn btn-primary px-4 fw-bold" type="submit">Track Order</button>
                </div>
            </form>
        </div>
    </div>

    <?php if ($searched && $order): ?>
        <div class="row justify-content-center pb-5">
            <div class="col-md-7">
                <div class="card p-5 shadow border-0" style="border-top: 5px solid var(--accent-color) !important;">
                    <div class="d-flex justify-content-between align-items-center border-bottom pb-3 mb-4">
                        <h4 class="fw-bold text-primary m-0">Order <span class="text-dark">#ORD-
                                <?= str_pad($order['id'], 5, '0', STR_PAD_LEFT) ?>
                            </span></h4>
                        <span class="badge bg-light text-dark border p-2"><i
                                class="fa-solid fa-calendar me-1 text-primary"></i>
                            <?= date('d M Y, h:i A', strtotime($order['created_at'])) ?>
                        </span>
                    </div>

                    <div class="text-center mb-5 mt-4">
                        <h6 class="text-muted text-uppercase fw-bold letter-spacing-1 mb-4">Current Delivery Status</h6>
                        <?php
                        $bgs = 'bg-info text-dark';
                        $icon = 'fa-spinner fa-spin';
                        if ($order['order_status'] == 'Confirmed') {
                            $bgs = 'bg-primary text-white';
                            $icon = 'fa-check-circle text-white';
                        }
                        if ($order['order_status'] == 'Preparing') {
                            $bgs = 'bg-warning text-dark';
                            $icon = 'fa-fire-burner text-dark';
                        }
                        if ($order['order_status'] == 'Out for delivery') {
                            $bgs = 'bg-info text-dark';
                            $icon = 'fa-motorcycle text-dark';
                        }
                        if ($order['order_status'] == 'Delivered') {
                            $bgs = 'bg-success text-white';
                            $icon = 'fa-box-open text-white';
                        }
                        ?>
                        <div class="d-inline-block px-5 py-4 rounded shadow-sm border <?= $bgs ?>">
                            <i class="fa-solid <?= $icon ?> fa-3x mb-3"></i>
                            <h3 class="fw-bold m-0">
                                <?= $order['order_status'] ?>
                            </h3>
                        </div>
                    </div>

                    <div class="row bg-light rounded p-4 m-0 border align-items-center">
                        <div class="col-md-6 border-end-md mb-3 mb-md-0">
                            <h6 class="text-muted text-uppercase fw-bold mb-3">Payment Info</h6>
                            <div class="d-flex align-items-center mb-2">
                                <span class="me-2 text-muted">Status:</span>
                                <?php
                                $bg = 'bg-warning text-dark';
                                if ($order['payment_status'] == 'Paid')
                                    $bg = 'bg-success';
                                if ($order['payment_status'] == 'Failed')
                                    $bg = 'bg-danger';
                                ?>
                                <span class="badge <?= $bg ?>">
                                    <?= $order['payment_status'] ?>
                                </span>
                            </div>
                            <div class="d-flex align-items-center">
                                <span class="me-2 text-muted">Method:</span>
                                <span class="fw-bold text-dark">
                                    <?= $order['payment_method'] == 'UPI' ? '<i class="fa-solid fa-qrcode text-primary"></i> UPI' : '<i class="fa-solid fa-money-bill-wave text-success"></i> COD' ?>
                                </span>
                            </div>
                        </div>
                        <div class="col-md-6 ps-md-4">
                            <h6 class="text-muted text-uppercase fw-bold mb-3">Delivery Partner</h6>
                            <?php if ($order['delivery_boy_id']): ?>
                                <div class="d-flex align-items-center">
                                    <div class="bg-white rounded-circle p-2 border me-3"><i
                                            class="fa-solid fa-user text-primary"></i></div>
                                    <div>
                                        <div class="fw-bold text-dark">
                                            <?= htmlspecialchars($order['delivery_name']) ?>
                                        </div>
                                        <div class="text-muted small mt-1"><i class="fa-solid fa-phone me-1"></i> <a
                                                href="tel:<?= htmlspecialchars($order['delivery_phone']) ?>"
                                                class="text-decoration-none text-muted">
                                                <?= htmlspecialchars($order['delivery_phone']) ?>
                                            </a></div>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="text-muted fst-italic py-2"><i class="fa-solid fa-clock opacity-50 me-2"></i>
                                    Partner will be assigned soon.</div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<style>
    @media (min-width: 768px) {
        .border-end-md {
            border-right: 1px solid #dee2e6 !important;
        }
    }

    .letter-spacing-1 {
        letter-spacing: 1px;
    }
</style>

<?php require_once '../includes/footer.php'; ?>