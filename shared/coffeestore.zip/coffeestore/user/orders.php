<?php
$page_title = "My Orders";
require_once '../includes/header.php';
require_once '../includes/navbar.php';
requireUser();

$user_id = $_SESSION['user_id'];

if (isset($_GET['view'])) {
    $order_id = (int) $_GET['view'];
    $stmt = $pdo->prepare("SELECT o.*, d.name as delivery_name, d.phone as delivery_phone FROM orders o LEFT JOIN delivery_boys d ON o.delivery_boy_id = d.id WHERE o.id = ? AND o.user_id = ?");
    $stmt->execute([$order_id, $user_id]);
    $order = $stmt->fetch();

    if (!$order) {
        flash('error', 'Order not found.');
        redirect('orders.php');
    }

    $stmt = $pdo->prepare("SELECT oi.*, p.name, p.image FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?");
    $stmt->execute([$order_id]);
    $items = $stmt->fetchAll();

} else {
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC");
    $stmt->execute([$user_id]);
    $orders = $stmt->fetchAll();
}
?>

<div class="container my-5 flex-grow-1">
    <?php if (isset($_GET['view'])): ?>
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="text-primary m-0 fw-bold"><i class="fa-solid fa-file-invoice me-2"></i> Order Details</h2>
            <a href="orders.php" class="btn btn-outline-secondary"><i class="fa-solid fa-arrow-left me-1"></i> Back to
                Orders</a>
        </div>

        <div class="row">
            <div class="col-md-8">
                <div class="card p-4 shadow-sm border-0 mb-4">
                    <div class="d-flex justify-content-between border-bottom pb-3 mb-3">
                        <h5 class="fw-bold m-0">Order <span class="text-primary">#ORD-
                                <?= str_pad($order['id'], 5, '0', STR_PAD_LEFT) ?>
                            </span></h5>
                        <span class="text-muted"><i class="fa-solid fa-calendar me-1"></i>
                            <?= date('d M Y, h:i A', strtotime($order['created_at'])) ?>
                        </span>
                    </div>

                    <div class="table-responsive mb-3">
                        <table class="table align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>Item</th>
                                    <th>Price</th>
                                    <th>Qty</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($items as $item): ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <img src="/coffeestore/assets/uploads/<?= htmlspecialchars($item['image']) ?>"
                                                    width="50" height="50" class="rounded me-3 border"
                                                    style="object-fit:cover;">
                                                <span class="fw-bold">
                                                    <?= htmlspecialchars($item['name']) ?>
                                                </span>
                                            </div>
                                        </td>
                                        <td>₹
                                            <?= number_format($item['price'], 2) ?>
                                        </td>
                                        <td>x
                                            <?= $item['quantity'] ?>
                                        </td>
                                        <td class="fw-bold text-dark">₹
                                            <?= number_format($item['price'] * $item['quantity'], 2) ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="text-end border-top pt-3">
                        <h5 class="m-0 text-muted d-inline-block me-3">Grand Total:</h5>
                        <h3 class="m-0 fw-bold text-success d-inline-block">₹
                            <?= number_format($order['total_amount'], 2) ?>
                        </h3>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card p-4 shadow-sm border-0 mb-4">
                    <h5 class="fw-bold mb-4 border-bottom pb-2">Status Overview</h5>

                    <div class="mb-4">
                        <small class="text-muted d-block text-uppercase fw-bold mb-1">Order Status</small>
                        <?php
                        $bgs = 'bg-info text-dark';
                        if ($order['order_status'] == 'Delivered')
                            $bgs = 'bg-success';
                        if ($order['order_status'] == 'Confirmed')
                            $bgs = 'bg-primary';
                        if ($order['order_status'] == 'Preparing')
                            $bgs = 'bg-warning text-dark';
                        ?>
                        <span class="badge <?= $bgs ?> fs-6 py-2 px-3">
                            <?= $order['order_status'] ?>
                        </span>
                    </div>

                    <div class="mb-4">
                        <small class="text-muted d-block text-uppercase fw-bold mb-1">Payment Method</small>
                        <span class="fs-5">
                            <?= $order['payment_method'] == 'UPI' ? '<i class="fa-solid fa-qrcode text-primary"></i> UPI' : '<i class="fa-solid fa-money-bill-wave text-success"></i> Cash on Delivery' ?>
                        </span>
                    </div>

                    <div>
                        <small class="text-muted d-block text-uppercase fw-bold mb-1">Payment Status</small>
                        <?php
                        $bg = 'bg-warning text-dark';
                        if ($order['payment_status'] == 'Paid')
                            $bg = 'bg-success';
                        if ($order['payment_status'] == 'Failed')
                            $bg = 'bg-danger';
                        ?>
                        <span class="badge <?= $bg ?> fs-6">
                            <?= $order['payment_status'] ?>
                        </span>

                        <?php if ($order['payment_method'] == 'UPI' && $order['payment_status'] == 'Verification Pending'): ?>
                            <div class="alert alert-info py-2 px-3 mt-3 mb-0 small"><i class="fa-solid fa-clock me-1"></i>
                                Verifying payment screenshot...</div>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if ($order['delivery_boy_id']): ?>
                    <div class="card p-4 shadow-sm border-0" style="border-left: 4px solid var(--accent-color) !important;">
                        <h5 class="fw-bold mb-3"><i class="fa-solid fa-motorcycle text-accent me-2"></i> Delivery Partner</h5>
                        <div class="d-flex align-items-center mb-2">
                            <div class="bg-light rounded-circle p-3 me-3 text-primary"><i class="fa-solid fa-user"></i></div>
                            <div>
                                <h6 class="mb-0 fw-bold">
                                    <?= htmlspecialchars($order['delivery_name']) ?>
                                </h6>
                                <small class="text-muted">Assigned Rider</small>
                            </div>
                        </div>
                        <a href="tel:<?= htmlspecialchars($order['delivery_phone']) ?>"
                            class="btn btn-outline-primary btn-sm w-100 mt-2"><i class="fa-solid fa-phone me-1"></i> Call
                            Rider</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>

    <?php else: ?>
        <h2 class="text-primary mb-4 fw-bold"><i class="fa-solid fa-box-open me-2"></i> My Order History</h2>

        <?php if (count($orders) > 0): ?>
            <div class="card p-0 shadow-sm border-0 overflow-hidden">
                <div class="table-responsive">
                    <table class="table table-hover align-middle m-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">Order ID</th>
                                <th>Date</th>
                                <th>Amount</th>
                                <th>Type</th>
                                <th>Payment</th>
                                <th>Status</th>
                                <th class="text-end pe-4">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($orders as $o): ?>
                                <tr>
                                    <td class="ps-4 fw-bold text-dark">#ORD-
                                        <?= str_pad($o['id'], 5, '0', STR_PAD_LEFT) ?>
                                    </td>
                                    <td class="text-muted"><i class="fa-solid fa-calendar-day me-1"></i>
                                        <?= date('d M Y', strtotime($o['created_at'])) ?>
                                    </td>
                                    <td class="fw-bold text-success">₹
                                        <?= number_format($o['total_amount'], 2) ?>
                                    </td>
                                    <td><span class="badge bg-secondary">
                                            <?= $o['payment_method'] ?>
                                        </span></td>
                                    <td>
                                        <?php
                                        $bg = 'bg-warning text-dark';
                                        if ($o['payment_status'] == 'Paid')
                                            $bg = 'bg-success';
                                        if ($o['payment_status'] == 'Failed')
                                            $bg = 'bg-danger';
                                        ?>
                                        <span class="badge <?= $bg ?>">
                                            <?= $o['payment_status'] ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php
                                        $bgs = 'bg-info text-dark';
                                        if ($o['order_status'] == 'Delivered')
                                            $bgs = 'bg-success';
                                        if ($o['order_status'] == 'Confirmed')
                                            $bgs = 'bg-primary';
                                        if ($o['order_status'] == 'Preparing')
                                            $bgs = 'bg-warning text-dark';
                                        ?>
                                        <span class="badge <?= $bgs ?> rounded-pill"><i class="fa-solid fa-circle fa-2xs me-1"></i>
                                            <?= $o['order_status'] ?>
                                        </span>
                                    </td>
                                    <td class="text-end pe-4">
                                        <a href="orders.php?view=<?= $o['id'] ?>" class="btn btn-sm btn-outline-primary px-3">View
                                            Details</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php else: ?>
            <div class="text-center py-5 bg-white rounded shadow-sm border-0">
                <i class="fa-solid fa-receipt fa-4x text-muted mb-3 opacity-50"></i>
                <h4 class="text-muted">You haven't placed any orders yet.</h4>
                <a href="shop.php" class="btn btn-primary mt-3 px-4">Start Shopping</a>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>