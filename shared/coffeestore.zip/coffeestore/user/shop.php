<?php
$page_title = "Shop";
require_once '../includes/header.php';
require_once '../includes/navbar.php';

$cat_id = $_GET['category'] ?? '';
$roast = $_GET['roast'] ?? '';
$sort = $_GET['sort'] ?? '';

$query = "SELECT p.*, c.name as category_name FROM products p JOIN categories c ON p.category_id = c.id WHERE 1=1";
$params = [];

if ($cat_id) {
    $query .= " AND p.category_id = ?";
    $params[] = $cat_id;
}
if ($roast) {
    $query .= " AND p.roast_level = ?";
    $params[] = $roast;
}
if ($sort == 'low') {
    $query .= " ORDER BY COALESCE(p.discount_price, p.price) ASC";
} elseif ($sort == 'high') {
    $query .= " ORDER BY COALESCE(p.discount_price, p.price) DESC";
} else {
    $query .= " ORDER BY p.created_at DESC";
}

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$products = $stmt->fetchAll();

$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();
?>
<div class="container my-5 flex-grow-1">
    <div class="row">
        <!-- Filters Sidebar -->
        <div class="col-md-3 mb-4">
            <div class="card p-4 border-0 shadow-sm sticky-top" style="top: 80px; z-index:10;">
                <h5 class="fw-bold text-primary mb-3"><i class="fa-solid fa-filter me-2"></i> Filters</h5>
                <form method="GET" action="shop.php">
                    <div class="mb-3">
                        <label class="form-label text-muted fw-bold">Category</label>
                        <select name="category" class="form-select">
                            <option value="">All Categories</option>
                            <?php foreach ($categories as $c): ?>
                                <option value="<?= $c['id'] ?>" <?= $cat_id == $c['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($c['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted fw-bold">Roast Level</label>
                        <select name="roast" class="form-select">
                            <option value="">All Roasts</option>
                            <option value="Light" <?= $roast == 'Light' ? 'selected' : '' ?>>Light</option>
                            <option value="Medium" <?= $roast == 'Medium' ? 'selected' : '' ?>>Medium</option>
                            <option value="Dark" <?= $roast == 'Dark' ? 'selected' : '' ?>>Dark</option>
                        </select>
                    </div>
                    <div class="mb-4">
                        <label class="form-label text-muted fw-bold">Sort By Price</label>
                        <select name="sort" class="form-select">
                            <option value="">Newest First</option>
                            <option value="low" <?= $sort == 'low' ? 'selected' : '' ?>>Lowest to Highest</option>
                            <option value="high" <?= $sort == 'high' ? 'selected' : '' ?>>Highest to Lowest</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary w-100 mb-2">Apply Filters</button>
                    <a href="shop.php" class="btn btn-outline-secondary w-100">Clear All</a>
                </form>
            </div>
        </div>

        <!-- Products Grid -->
        <div class="col-md-9">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="text-primary m-0 fw-bold">Explore Our Coffee</h2>
                <span class="text-muted border rounded px-3 py-1 bg-white">
                    <?= count($products) ?> Products found
                </span>
            </div>

            <div class="row g-4">
                <?php if (count($products) > 0): ?>
                    <?php foreach ($products as $p): ?>
                        <div class="col-md-4 col-sm-6">
                            <div class="card h-100 product-card shadow-sm border-0 position-relative"
                                style="transition: 0.3s; cursor:pointer;" onmouseover="this.classList.add('shadow');"
                                onmouseout="this.classList.remove('shadow');">
                                <?php if ($p['discount_price']): ?>
                                    <div class="position-absolute top-0 end-0 bg-danger text-white px-3 py-1 m-2 rounded-pill fw-bold z-1"
                                        style="font-size: 0.8rem;">SALE</div>
                                <?php endif; ?>
                                <button
                                    class="btn btn-light rounded-circle shadow-sm position-absolute top-0 start-0 m-2 z-1 text-danger border-0 add-to-wishlist"
                                    data-id="<?= $p['id'] ?>">
                                    <i class="fa-regular fa-heart"></i>
                                </button>
                                <img src="/coffeestore/assets/uploads/<?= htmlspecialchars($p['image']) ?>" class="card-img-top"
                                    alt="<?= htmlspecialchars($p['name']) ?>">
                                <div class="card-body d-flex flex-column">
                                    <small class="text-muted mb-1">
                                        <?= htmlspecialchars($p['category_name']) ?> &bull; <span
                                            class="badge bg-light text-dark border">
                                            <?= $p['roast_level'] ?> Roast
                                        </span>
                                    </small>
                                    <h5 class="card-title fw-bold text-dark">
                                        <?= htmlspecialchars($p['name']) ?>
                                    </h5>
                                    <p class="small text-muted text-truncate">
                                        <?= htmlspecialchars($p['description']) ?>
                                    </p>
                                    <div class="mt-auto border-top pt-3 d-flex justify-content-between align-items-center">
                                        <div class="price-wrap">
                                            <?php if ($p['discount_price']): ?>
                                                <span class="fs-5 fw-bold text-success">₹
                                                    <?= number_format($p['discount_price'], 2) ?>
                                                </span>
                                                <br><small class="text-muted text-decoration-line-through">₹
                                                    <?= number_format($p['price'], 2) ?>
                                                </small>
                                            <?php else: ?>
                                                <span class="fs-5 fw-bold text-primary">₹
                                                    <?= number_format($p['price'], 2) ?>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <?php if ($p['stock'] > 0): ?>
                                            <button class="btn btn-primary add-to-cart px-3 rounded-pill"
                                                data-id="<?= $p['id'] ?>"><i class="fa-solid fa-cart-shopping me-1"></i>
                                                Add</button>
                                        <?php else: ?>
                                            <span class="badge bg-danger p-2 rounded-pill">Out of Stock</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="col-12 py-5 text-center bg-white rounded shadow-sm border-0">
                        <i class="fa-solid fa-mug-hot fa-4x text-muted mb-3 opacity-50"></i>
                        <h4 class="text-muted">No products found matching your criteria.</h4>
                        <a href="shop.php" class="btn btn-outline-primary mt-3 px-4">Clear Filters</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
        $('.add-to-cart').click(function (e) {
            e.preventDefault();
        <?php if (!isUser()): ?>
                    window.location.href = 'login.php';
                return;
        <?php endif; ?>
        
        var btn = $(this);
            var originalText = btn.html();
            btn.html('<i class="fa-solid fa-spinner fa-spin"></i>').prop('disabled', true);

            var id = btn.data('id');
            $.post('ajax_cart.php', { action: 'add', product_id: id, quantity: 1 }, function (res) {
                let data = JSON.parse(res);
                if (data.status == 'success') {
                    $('#cart-count').text(data.count);
                    btn.html('<i class="fa-solid fa-check me-1"></i> Added').removeClass('btn-primary').addClass('btn-success');
                    setTimeout(() => { btn.html(originalText).prop('disabled', false).removeClass('btn-success').addClass('btn-primary'); }, 2000);
                } else {
                    alert(data.message);
                    btn.html(originalText).prop('disabled', false);
                }
            });
        });

        $('.add-to-wishlist').click(function (e) {
            e.preventDefault();
        <?php if (!isUser()): ?>
                    window.location.href = 'login.php';
                return;
        <?php endif; ?>
        
        var id = $(this).data('id');
            var btn = $(this);
            $.post('ajax_wishlist.php', { action: 'toggle', product_id: id }, function (res) {
                let data = JSON.parse(res);
                if (data.status == 'added') {
                    btn.find('i').removeClass('fa-regular').addClass('fa-solid');
                } else if (data.status == 'removed') {
                    btn.find('i').removeClass('fa-solid').addClass('fa-regular');
                } else {
                    alert(data.message);
                }
            });
        });
    });
</script>
<?php require_once '../includes/footer.php'; ?>