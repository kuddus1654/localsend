<?php
$settings = getSettings($pdo);
?>
<nav class="navbar navbar-expand-lg sticky-top">
    <div class="container">
        <a class="navbar-brand fw-bold text-accent" href="/coffeestore/user/index.php">
            <i class="fa-solid fa-mug-hot"></i>
            <?= htmlspecialchars($settings['store_name']) ?>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto align-items-center">

                <?php if (isAdmin()): ?>
                    <li class="nav-item"><a class="nav-link" href="/coffeestore/admin/dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="/coffeestore/admin/products.php">Products</a></li>
                    <li class="nav-item"><a class="nav-link" href="/coffeestore/admin/orders.php">Orders</a></li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fa-solid fa-user-tie"></i> Admin
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="/coffeestore/admin/profile.php">Profile</a></li>
                            <li><a class="dropdown-item" href="/coffeestore/admin/settings.php">Settings</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item text-danger" href="/coffeestore/admin/logout.php">Logout</a></li>
                        </ul>
                    </li>

                <?php elseif (isDelivery()): ?>
                    <li class="nav-item"><a class="nav-link" href="/coffeestore/delivery/dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="/coffeestore/delivery/orders.php">Deliveries</a></li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fa-solid fa-motorcycle"></i> Account
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="/coffeestore/delivery/profile.php">Profile</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item text-danger" href="/coffeestore/delivery/logout.php">Logout</a></li>
                        </ul>
                    </li>

                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="/coffeestore/user/index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="/coffeestore/user/shop.php">Shop</a></li>
                    <li class="nav-item"><a class="nav-link" href="/coffeestore/user/track.php">Track Order</a></li>

                    <?php if (isUser()): ?>
                        <li class="nav-item">
                            <a class="nav-link position-relative" href="/coffeestore/user/cart.php">
                                <i class="fa-solid fa-cart-shopping"></i> Cart
                                <span class="position-absolute top-1 start-100 translate-middle badge rounded-pill bg-danger"
                                    id="cart-count">
                                    <?= getCartCount($pdo, $_SESSION['user_id']) ?>
                                </span>
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-bs-toggle="dropdown">
                                <i class="fa-solid fa-user"></i> Account
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="/coffeestore/user/profile.php">Profile</a></li>
                                <li><a class="dropdown-item" href="/coffeestore/user/orders.php">My Orders</a></li>
                                <li><a class="dropdown-item" href="/coffeestore/user/wishlist.php">Wishlist</a></li>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item text-danger" href="/coffeestore/user/logout.php">Logout</a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link" href="/coffeestore/user/login.php">Login</a></li>
                        <li class="nav-item"><a class="btn btn-accent ms-2 py-1 px-3"
                                href="/coffeestore/user/register.php">Register</a></li>
                    <?php endif; ?>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-3">
    <?php if ($msg = flash('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?= $msg ?> <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <?php if ($msg = flash('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <?= $msg ?> <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
</div>