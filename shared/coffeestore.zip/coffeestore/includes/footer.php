<footer class="bg-primary text-white text-center py-4 mt-auto">
    <div class="container">
        <p class="mb-1">&copy;
            <?= date('Y'); ?>
            <?= htmlspecialchars($settings['store_name']) ?>. All Rights Reserved.
        </p>
        <small>Premium Coffee Delivered Fast</small>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Auto hide alerts after 3 seconds
    setTimeout(() => {
        $('.alert:not(.alert-permanent)').fadeOut(500);
    }, 3000);

    // Password visibility toggle
    document.querySelectorAll('.toggle-password').forEach(button => {
        button.addEventListener('click', function () {
            const input = document.querySelector(this.getAttribute('data-target'));
            const icon = this.querySelector('i');
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    });
</script>
</body>

</html>