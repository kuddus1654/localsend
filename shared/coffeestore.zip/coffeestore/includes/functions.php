<?php
session_start();
ob_start();
require_once __DIR__ . '/../config/db.php';

function redirect($url)
{
    header("Location: $url");
    exit;
}

function flash($key, $message = null)
{
    if ($message !== null) {
        $_SESSION['flash'][$key] = $message;
    } else {
        if (isset($_SESSION['flash'][$key])) {
            $msg = $_SESSION['flash'][$key];
            unset($_SESSION['flash'][$key]);
            return $msg;
        }
    }
    return '';
}

function isUser()
{
    return isset($_SESSION['user_id']);
}
function isAdmin()
{
    return isset($_SESSION['admin_id']);
}
function isDelivery()
{
    return isset($_SESSION['delivery_boy_id']);
}

function requireUser()
{
    if (!isUser())
        redirect('/coffeestore/user/login.php');
}
function requireAdmin()
{
    if (!isAdmin())
        redirect('/coffeestore/admin/login.php');
}
function requireDelivery()
{
    if (!isDelivery())
        redirect('/coffeestore/delivery/login.php');
}

function getSettings($pdo)
{
    $stmt = $pdo->query("SELECT * FROM settings LIMIT 1");
    return $stmt->fetch();
}

function getCartCount($pdo, $user_id)
{
    $stmt = $pdo->prepare("SELECT SUM(quantity) as count FROM cart WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $res = $stmt->fetch();
    return $res['count'] ? $res['count'] : 0;
}

function getTitle($title = "")
{
    $base = "CoffeeStore";
    return $title ? "$title - $base" : $base;
}
?>