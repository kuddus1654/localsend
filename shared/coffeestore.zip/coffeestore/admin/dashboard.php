<?php
$page_title = "Admin Dashboard";
require_once '../includes/header.php';
require_once '../includes/navbar.php';
requireAdmin();

// Total Sales
$stmt = $pdo->query("SELECT SUM(total_amount) as total FROM orders WHERE payment_status = 'Paid'");
$total_sales = $stmt->fetchColumn() ?: 0;

// Total Users
$stmt = $pdo->query("SELECT COUNT(*) FROM users");
$total_users = $stmt->fetchColumn();

// Total Orders
$stmt = $pdo->query("SELECT COUNT(*) FROM orders");
$total_orders = $stmt->fetchColumn();

// Pending Deliveries
$stmt = $pdo->query("SELECT COUNT(*) FROM orders WHERE order_status IN ('Confirmed', 'Preparing', 'Out for delivery')");
$pending_deliveries = $stmt->fetchColumn();

// Recent Orders
$stmt = $pdo->query("SELECT o.*, u.name as user_name FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC LIMIT 5");
$recent_orders = $stmt->fetchAll();
?>
<div class="container-fluid my-5 flex-grow-1">
    <div class="row">
        <!-- Admin Sidebar -->
        <div class="col-md-3 col-lg-2 d-none d-md-block admin-sidebar p-3">
            <h5 class="mb-4 text-center text-primary fw-bold">Admin Menu</h5>
            <div class="nav flex-column nav-pills">
                <a class="nav-link active" href="dashboard.php"><i class="fa-solid fa-chart-line me-2"></i> Dashboard</a>
                <a class="nav-link" href="products.php"><i class="fa-solid fa-box-open me-2"></i> Products</a>
                <a class="nav-link" href="orders.php"><i class="fa-solid fa-list-check me-2"></i> Orders</a>
                <a class="nav-link" href="users.php"><i class="fa-solid fa-users me-2"></i> Users</a>
                <a class="nav-link" href="delivery.php"><i class="fa-solid fa-motorcycle me-2"></i> Delivery Boys</a>
                <a class="nav-link" href="coupons.php"><i class="fa-solid fa-tags me-2"></i> Coupons</a>
                <a class="nav-link" href="settings.php"><i class="fa-solid fa-gear me-2"></i> Settings</a>
                <a class="nav-link" href="profile.php"><i class="fa-solid fa-user-shield me-2"></i> Profile</a>
            </div>
        </div>

        <div class="col-md-9 col-lg-10 px-md-4">
            <h2 class="mb-4 text-primary"><i class="fa-solid fa-chart-pie me-2"></i> Dashboard Overview</h2>
            
            <div class="row mb-4">
                <div class="col-md-3 mb-3">
                    <div class="card p-3 shadow-sm dash-card primary border-0">
                        <h6 class="text-muted">Total Sales</h6>
                        <h3 class="fw-bold text-primary">₹<?= number_format($total_sales, 2) ?></h3>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card p-3 shadow-sm dash-card text-success border-0" style="border-left-color: #198754;">
                        <h6 class="text-muted">Total Users</h6>
                        <h3 class="fw-bold text-success"><?= $total_users ?></h3>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card p-3 shadow-sm dash-card text-info border-0" style="border-left-color: #0dcaf0;">
                        <h6 class="text-muted">Total Orders</h6>
                        <h3 class="fw-bold text-info"><?= $total_orders ?></h3>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card p-3 shadow-sm dash-card text-warning border-0" style="border-left-color: #ffc107;">
                        <h6 class="text-muted">Active Deliveries</h6>
                        <h3 class="fw-bold text-warning"><?= $pending_deliveries ?></h3>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card p-4 shadow-sm border-0">
                        <h5 class="mb-3">Recent Orders</h5>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle">
                                <thead class="table-light">
                                    <tr>
                                        <th>Order ID</th>
                                        <th>Customer</th>
                                        <th>Amount</th>
                                        <th>Method</th>
                                        <th>Payment</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (count($recent_orders) > 0): ?>
                                        <?php foreach($recent_orders as $order): ?>
                                        <tr>
                                            <td>#ORD-<?= str_pad($order['id'], 5, '0', STR_PAD_LEFT) ?></td>
                                            <td><?= htmlspecialchars($order['user_name']) ?></td>
                                            <td>₹<?= number_format($order['total_amount'], 2) ?></td>
                                            <td><span class="badge bg-secondary"><?= $order['payment_method'] ?></span></td>
                                            <td>
                                                <?php 
                                                    $bg = 'bg-warning text-dark';
                                                    if ($order['payment_status'] == 'Paid') $bg = 'bg-success';
                                                    if ($order['payment_status'] == 'Failed') $bg = 'bg-danger';
                                                ?>
                                                <span class="badge <?= $bg ?>"><?= $order['payment_status'] ?></span>
                                            </td>
                                            <td>
                                                <?php 
                                                    $bg_stat = 'bg-info text-dark';
                                                    if ($order['order_status'] == 'Delivered') $bg_stat = 'bg-success';
                                                ?>
                                                <span class="badge <?= $bg_stat ?>"><?= $order['order_status'] ?></span>
                                            </td>
                                            <td>
                                                <a href="orders.php?view=<?= $order['id'] ?>" class="btn btn-sm btn-outline-primary">View</a>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr><td colspan="7" class="text-center">No recent orders.</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="text-end mt-2">
                            <a href="orders.php" class="text-decoration-none fw-bold text-accent">View All Orders &rarr;</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Dummy Revenue Chart container for completeness -->
            <div class="row mt-4">
                <div class="col-12">
                    <div class="card p-4 shadow-sm border-0">
                        <h5 class="mb-3">Revenue Chart (Demo)</h5>
                        <div class="bg-light d-flex align-items-center justify-content-center rounded" style="height: 250px;">
                            <span class="text-muted"><i class="fa-solid fa-chart-column fa-3x"></i> Loading chart data...</span>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
