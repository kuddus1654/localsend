<?php
$page_title = "Manage Coupons";
require_once '../includes/header.php';
require_once '../includes/navbar.php';
requireAdmin();

// Add Coupon
if (isset($_POST['add_coupon'])) {
    $code = strtoupper(trim($_POST['code']));
    $discount = $_POST['discount_percent'];
    $expiry = $_POST['expiry_date'];
    $limit = (int) $_POST['usage_limit'];

    try {
        $stmt = $pdo->prepare("INSERT INTO coupons (code, discount_percent, expiry_date, usage_limit) VALUES (?, ?, ?, ?)");
        $stmt->execute([$code, $discount, $expiry, $limit]);
        flash('success', 'Coupon added successfully.');
    } catch (PDOException $e) {
        flash('error', 'Coupon code already exists or invalid data.');
    }
    redirect('coupons.php');
}

// Delete Coupon
if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    $pdo->prepare("DELETE FROM coupons WHERE id = ?")->execute([$id]);
    flash('success', 'Coupon deleted.');
    redirect('coupons.php');
}

$coupons = $pdo->query("SELECT * FROM coupons ORDER BY expiry_date DESC")->fetchAll();
$today = date('Y-m-d');
?>
<div class="container-fluid my-5 flex-grow-1">
    <div class="row">
        <!-- Admin Sidebar -->
        <div class="col-md-3 col-lg-2 d-none d-md-block admin-sidebar p-3">
            <h5 class="mb-4 text-center text-primary fw-bold">Admin Menu</h5>
            <div class="nav flex-column nav-pills">
                <a class="nav-link" href="dashboard.php"><i class="fa-solid fa-chart-line me-2"></i> Dashboard</a>
                <a class="nav-link" href="products.php"><i class="fa-solid fa-box-open me-2"></i> Products</a>
                <a class="nav-link" href="orders.php"><i class="fa-solid fa-list-check me-2"></i> Orders</a>
                <a class="nav-link" href="users.php"><i class="fa-solid fa-users me-2"></i> Users</a>
                <a class="nav-link" href="delivery.php"><i class="fa-solid fa-motorcycle me-2"></i> Delivery Boys</a>
                <a class="nav-link active" href="coupons.php"><i class="fa-solid fa-tags me-2"></i> Coupons</a>
                <a class="nav-link" href="settings.php"><i class="fa-solid fa-gear me-2"></i> Settings</a>
                <a class="nav-link" href="profile.php"><i class="fa-solid fa-user-shield me-2"></i> Profile</a>
            </div>
        </div>

        <div class="col-md-9 col-lg-10 px-md-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="text-primary m-0"><i class="fa-solid fa-tags me-2"></i> Discount Coupons</h2>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addCouponModal">+ Add
                    Coupon</button>
            </div>

            <div class="card p-4 shadow-sm border-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Coupon Code</th>
                                <th>Discount (%)</th>
                                <th>Expiry Date</th>
                                <th>Usage</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($coupons) > 0): ?>
                                <?php foreach ($coupons as $c):
                                    $is_expired = ($c['expiry_date'] < $today);
                                    $is_exhausted = ($c['usage_limit'] > 0 && $c['times_used'] >= $c['usage_limit']);
                                    ?>
                                    <tr>
                                        <td><span class="badge bg-secondary fs-6">
                                                <?= htmlspecialchars($c['code']) ?>
                                            </span></td>
                                        <td class="fw-bold text-success">
                                            <?= $c['discount_percent'] ?>%
                                        </td>
                                        <td>
                                            <?= date('d M Y', strtotime($c['expiry_date'])) ?>
                                        </td>
                                        <td>
                                            <?= $c['times_used'] ?> /
                                            <?= $c['usage_limit'] == 0 ? '&infin;' : $c['usage_limit'] ?>
                                        </td>
                                        <td>
                                            <?php if ($is_expired): ?>
                                                <span class="badge bg-danger">Expired</span>
                                            <?php elseif ($is_exhausted): ?>
                                                <span class="badge bg-warning text-dark">Limit Reached</span>
                                            <?php else: ?>
                                                <span class="badge bg-success">Active</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="coupons.php?delete=<?= $c['id'] ?>" class="btn btn-sm btn-outline-danger"
                                                onclick="return confirm('Delete this coupon?');">
                                                <i class="fa-solid fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center">No coupons created yet.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- Add Coupon Modal -->
<div class="modal fade" id="addCouponModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="">
                <div class="modal-header">
                    <h5 class="modal-title">New Coupon</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label>Coupon Code</label>
                        <input type="text" name="code" class="form-control text-uppercase" placeholder="e.g. SUMMER20"
                            required>
                    </div>
                    <div class="mb-3">
                        <label>Discount Percentage (%)</label>
                        <input type="number" step="0.01" min="1" max="100" name="discount_percent" class="form-control"
                            required>
                    </div>
                    <div class="mb-3">
                        <label>Expiry Date</label>
                        <input type="date" name="expiry_date" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Usage Limit (0 for unlimited)</label>
                        <input type="number" name="usage_limit" class="form-control" value="0" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" name="add_coupon" class="btn btn-primary">Save Coupon</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>