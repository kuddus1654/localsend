<?php
$page_title = "Manage Users";
require_once '../includes/header.php';
require_once '../includes/navbar.php';
requireAdmin();

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $pdo->prepare("SELECT profile_image FROM users WHERE id = ?");
    $stmt->execute([$id]);
    $img = $stmt->fetchColumn();
    if ($img && $img !== 'default_avatar.png' && file_exists("../assets/profile/" . $img)) {
        unlink("../assets/profile/" . $img);
    }
    $pdo->prepare("DELETE FROM users WHERE id = ?")->execute([$id]);
    flash('success', 'User deleted successfully.');
    redirect('users.php');
}

$users = $pdo->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll();
?>
<div class="container-fluid my-5 flex-grow-1">
    <div class="row">
        <!-- Admin Sidebar -->
        <div class="col-md-3 col-lg-2 d-none d-md-block admin-sidebar p-3">
            <h5 class="mb-4 text-center text-primary fw-bold">Admin Menu</h5>
            <div class="nav flex-column nav-pills">
                <a class="nav-link" href="dashboard.php"><i class="fa-solid fa-chart-line me-2"></i> Dashboard</a>
                <a class="nav-link" href="products.php"><i class="fa-solid fa-box-open me-2"></i> Products</a>
                <a class="nav-link" href="orders.php"><i class="fa-solid fa-list-check me-2"></i> Orders</a>
                <a class="nav-link active" href="users.php"><i class="fa-solid fa-users me-2"></i> Users</a>
                <a class="nav-link" href="delivery.php"><i class="fa-solid fa-motorcycle me-2"></i> Delivery Boys</a>
                <a class="nav-link" href="coupons.php"><i class="fa-solid fa-tags me-2"></i> Coupons</a>
                <a class="nav-link" href="settings.php"><i class="fa-solid fa-gear me-2"></i> Settings</a>
                <a class="nav-link" href="profile.php"><i class="fa-solid fa-user-shield me-2"></i> Profile</a>
            </div>
        </div>

        <div class="col-md-9 col-lg-10 px-md-4">
            <h2 class="mb-4 text-primary"><i class="fa-solid fa-users me-2"></i> Manage Users</h2>
            
            <div class="card p-4 shadow-sm border-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Profile</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Joined At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($users) > 0): ?>
                                <?php foreach($users as $user): ?>
                                <tr>
                                    <td>
                                        <img src="/coffeestore/assets/profile/<?= htmlspecialchars($user['profile_image']) ?>" class="rounded-circle" width="40" height="40" style="object-fit:cover;" alt="Avatar">
                                    </td>
                                    <td class="fw-bold"><?= htmlspecialchars($user['name']) ?></td>
                                    <td><?= htmlspecialchars($user['email']) ?></td>
                                    <td><?= htmlspecialchars($user['phone']) ?></td>
                                    <td><?= date('d M Y', strtotime($user['created_at'])) ?></td>
                                    <td>
                                        <a href="users.php?delete=<?= $user['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this user permanently?');">
                                            <i class="fa-solid fa-trash"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="6" class="text-center">No users registered yet.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>
