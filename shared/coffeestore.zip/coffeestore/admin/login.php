<?php
$page_title = "Admin Login";
require_once '../includes/header.php';
require_once '../includes/navbar.php';

if (isAdmin())
    redirect('/coffeestore/admin/dashboard.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        flash('error', 'All fields are required.');
    } else {
        $stmt = $pdo->prepare("SELECT * FROM admins WHERE email = ?");
        $stmt->execute([$email]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['password'])) {
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_name'] = $admin['name'];
            flash('success', 'Admin login successful.');
            redirect('/coffeestore/admin/dashboard.php');
        } else {
            flash('error', 'Invalid admin credentials.');
        }
    }
}
?>
<div class="container my-5 flex-grow-1">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card p-4 border-0 shadow" style="border-top: 5px solid var(--primary-color) !important;">
                <h3 class="text-center mb-4"><i class="fa-solid fa-user-shield text-primary"></i> Admin Panel</h3>
                <form method="POST" action="">
                    <div class="mb-3">
                        <label class="form-label">Admin Email</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="mb-4">
                        <label class="form-label">Password</label>
                        <div class="input-group">
                            <input type="password" name="password" id="adminPassword" class="form-control" required>
                            <button class="btn btn-outline-secondary toggle-password" type="button"
                                data-target="#adminPassword">
                                <i class="fa-regular fa-eye"></i>
                            </button>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100 mb-3">Access Restricted Area</button>
                    <div class="text-center p-3 bg-light rounded border">
                        <small class="text-muted d-block fw-bold mb-1"><i class="fa-solid fa-circle-info me-1"></i>
                            Default Demo Credentials</small>
                        <small class="d-block">Email: <strong>admin@coffeestore.com</strong></small>
                        <small class="d-block">Password: <strong>password</strong></small>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>