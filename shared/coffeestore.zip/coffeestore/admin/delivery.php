<?php
$page_title = "Manage Delivery Partners";
require_once '../includes/header.php';
require_once '../includes/navbar.php';
requireAdmin();

// Toggle Status
if (isset($_GET['toggle'])) {
    $id = (int)$_GET['toggle'];
    $stmt = $pdo->prepare("UPDATE delivery_boys SET is_active = NOT is_active WHERE id = ?");
    $stmt->execute([$id]);
    flash('success', 'Status toggled.');
    redirect('delivery.php');
}

// Add Delivery Boy
if (isset($_POST['add_delivery'])) {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];
    
    // Check if email exists
    $stmt = $pdo->prepare("SELECT id FROM delivery_boys WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        flash('error', 'Email already in use.');
    } else {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO delivery_boys (name, email, phone, password) VALUES (?, ?, ?, ?)");
        $stmt->execute([$name, $email, $phone, $hashed]);
        flash('success', 'Delivery partner added.');
    }
    redirect('delivery.php');
}

// Delete Delivery Boy
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $pdo->prepare("SELECT profile_image FROM delivery_boys WHERE id = ?");
    $stmt->execute([$id]);
    $img = $stmt->fetchColumn();
    if ($img && $img !== 'default_avatar.png' && file_exists("../assets/profile/" . $img)) {
        unlink("../assets/profile/" . $img);
    }
    $pdo->prepare("DELETE FROM delivery_boys WHERE id = ?")->execute([$id]);
    flash('success', 'Delivery partner deleted.');
    redirect('delivery.php');
}

$boys = $pdo->query("SELECT * FROM delivery_boys ORDER BY created_at DESC")->fetchAll();
?>
<div class="container-fluid my-5 flex-grow-1">
    <div class="row">
        <!-- Admin Sidebar -->
        <div class="col-md-3 col-lg-2 d-none d-md-block admin-sidebar p-3">
            <h5 class="mb-4 text-center text-primary fw-bold">Admin Menu</h5>
            <div class="nav flex-column nav-pills">
                <a class="nav-link" href="dashboard.php"><i class="fa-solid fa-chart-line me-2"></i> Dashboard</a>
                <a class="nav-link" href="products.php"><i class="fa-solid fa-box-open me-2"></i> Products</a>
                <a class="nav-link" href="orders.php"><i class="fa-solid fa-list-check me-2"></i> Orders</a>
                <a class="nav-link" href="users.php"><i class="fa-solid fa-users me-2"></i> Users</a>
                <a class="nav-link active" href="delivery.php"><i class="fa-solid fa-motorcycle me-2"></i> Delivery Boys</a>
                <a class="nav-link" href="coupons.php"><i class="fa-solid fa-tags me-2"></i> Coupons</a>
                <a class="nav-link" href="settings.php"><i class="fa-solid fa-gear me-2"></i> Settings</a>
                <a class="nav-link" href="profile.php"><i class="fa-solid fa-user-shield me-2"></i> Profile</a>
            </div>
        </div>

        <div class="col-md-9 col-lg-10 px-md-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="text-primary m-0"><i class="fa-solid fa-motorcycle me-2"></i> Delivery Partners</h2>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addDeliveryModal">+ Add Partner</button>
            </div>
            
            <div class="card p-4 shadow-sm border-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Profile</th>
                                <th>Name</th>
                                <th>Contact</th>
                                <th>Status</th>
                                <th>Joined</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($boys) > 0): ?>
                                <?php foreach($boys as $boy): ?>
                                <tr>
                                    <td>
                                        <img src="/coffeestore/assets/profile/<?= htmlspecialchars($boy['profile_image']) ?>" class="rounded-circle" width="40" height="40" style="object-fit:cover;" alt="Avatar">
                                    </td>
                                    <td class="fw-bold"><?= htmlspecialchars($boy['name']) ?></td>
                                    <td>
                                        <div class="small"><i class="fa-solid fa-envelope"></i> <?= htmlspecialchars($boy['email']) ?></div>
                                        <div class="small"><i class="fa-solid fa-phone"></i> <?= htmlspecialchars($boy['phone']) ?></div>
                                    </td>
                                    <td>
                                        <?php if ($boy['is_active']): ?>
                                            <span class="badge bg-success">Active</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= date('d M Y', strtotime($boy['created_at'])) ?></td>
                                    <td>
                                        <a href="delivery.php?toggle=<?= $boy['id'] ?>" class="btn btn-sm <?= $boy['is_active'] ? 'btn-outline-warning' : 'btn-outline-success' ?>" title="Toggle Status">
                                            <i class="fa-solid fa-power-off"></i>
                                        </a>
                                        <a href="delivery.php?delete=<?= $boy['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this delivery boy completely?');" title="Delete">
                                            <i class="fa-solid fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="6" class="text-center">No delivery partners found. Add one above.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
        </div>
    </div>
</div>

<!-- Add Delivery Modal -->
<div class="modal fade" id="addDeliveryModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form method="POST" action="">
          <div class="modal-header">
            <h5 class="modal-title">New Delivery Partner</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <div class="mb-3">
                <label>Full Name</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Email Address</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Phone Number</label>
                <input type="text" name="phone" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
          </div>
          <div class="modal-footer">
            <button type="submit" name="add_delivery" class="btn btn-primary">Add Partner</button>
          </div>
      </form>
    </div>
  </div>
</div>

<?php require_once '../includes/footer.php'; ?>
