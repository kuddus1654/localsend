<?php
session_start();
unset($_SESSION['admin_id']);
unset($_SESSION['admin_name']);
$_SESSION['flash']['success'] = "Admin logged out.";
header("Location: /coffeestore/admin/login.php");
exit;
?>