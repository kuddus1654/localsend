<?php
$page_title = "Manage Orders";
require_once '../includes/header.php';
require_once '../includes/navbar.php';
requireAdmin();

// Handle Status Update
if (isset($_POST['update_status'])) {
    $order_id = (int) $_POST['order_id'];
    $status = $_POST['order_status'];
    $delivery_boy_id = !empty($_POST['delivery_boy_id']) ? $_POST['delivery_boy_id'] : null;

    $stmt = $pdo->prepare("UPDATE orders SET order_status = ?, delivery_boy_id = ? WHERE id = ?");
    $stmt->execute([$status, $delivery_boy_id, $order_id]);
    flash('success', 'Order updated successfully.');
    redirect("orders.php?view=$order_id");
}

// Handle Payment Verification
if (isset($_POST['verify_payment'])) {
    $order_id = (int) $_POST['order_id'];
    $payment_status = $_POST['payment_status'];
    $stmt = $pdo->prepare("UPDATE orders SET payment_status = ? WHERE id = ?");
    $stmt->execute([$payment_status, $order_id]);
    flash('success', 'Payment status updated to ' . $payment_status . '.');
    redirect("orders.php?view=$order_id");
}

if (isset($_GET['view'])) {
    $order_id = (int) $_GET['view'];
    $stmt = $pdo->prepare("SELECT o.*, u.name as user_name, u.email, u.phone, u.address as user_address, d.name as delivery_name FROM orders o JOIN users u ON o.user_id = u.id LEFT JOIN delivery_boys d ON o.delivery_boy_id = d.id WHERE o.id = ?");
    $stmt->execute([$order_id]);
    $order = $stmt->fetch();

    if (!$order)
        redirect('orders.php');

    $stmt = $pdo->prepare("SELECT oi.*, p.name, p.image FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?");
    $stmt->execute([$order_id]);
    $items = $stmt->fetchAll();

    $delivery_boys = $pdo->query("SELECT id, name FROM delivery_boys WHERE is_active = 1")->fetchAll();
    $statuses = ['Confirmed', 'Preparing', 'Out for delivery', 'Delivered'];
} else {
    $orders = $pdo->query("SELECT o.*, u.name as user_name, u.phone, d.name as delivery_name FROM orders o JOIN users u ON o.user_id = u.id LEFT JOIN delivery_boys d ON o.delivery_boy_id = d.id ORDER BY o.created_at DESC")->fetchAll();
}
?>
<div class="container-fluid my-5 flex-grow-1">
    <div class="row">
        <!-- Admin Sidebar -->
        <div class="col-md-3 col-lg-2 d-none d-md-block admin-sidebar p-3">
            <h5 class="mb-4 text-center text-primary fw-bold">Admin Menu</h5>
            <div class="nav flex-column nav-pills">
                <a class="nav-link" href="dashboard.php"><i class="fa-solid fa-chart-line me-2"></i> Dashboard</a>
                <a class="nav-link" href="products.php"><i class="fa-solid fa-box-open me-2"></i> Products</a>
                <a class="nav-link active" href="orders.php"><i class="fa-solid fa-list-check me-2"></i> Orders</a>
                <a class="nav-link" href="users.php"><i class="fa-solid fa-users me-2"></i> Users</a>
                <a class="nav-link" href="delivery.php"><i class="fa-solid fa-motorcycle me-2"></i> Delivery Boys</a>
                <a class="nav-link" href="coupons.php"><i class="fa-solid fa-tags me-2"></i> Coupons</a>
                <a class="nav-link" href="settings.php"><i class="fa-solid fa-gear me-2"></i> Settings</a>
                <a class="nav-link" href="profile.php"><i class="fa-solid fa-user-shield me-2"></i> Profile</a>
            </div>
        </div>

        <div class="col-md-9 col-lg-10 px-md-4">
            <?php if (isset($_GET['view'])): ?>
                <!-- Single Order View -->
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2 class="text-primary m-0"><i class="fa-solid fa-file-invoice me-2"></i> Order #ORD-
                        <?= str_pad($order['id'], 5, '0', STR_PAD_LEFT) ?>
                    </h2>
                    <a href="orders.php" class="btn btn-outline-secondary"><i class="fa-solid fa-arrow-left me-1"></i>
                        Back</a>
                </div>

                <div class="row">
                    <div class="col-md-8">
                        <div class="card p-4 shadow-sm border-0 mb-4">
                            <h5 class="mb-3 border-bottom pb-2">Order Summary</h5>
                            <div class="table-responsive mb-3">
                                <table class="table align-middle">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Product</th>
                                            <th>Price</th>
                                            <th>Qty</th>
                                            <th>Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($items as $item): ?>
                                            <tr>
                                                <td>
                                                    <img src="/coffeestore/assets/uploads/<?= htmlspecialchars($item['image']) ?>"
                                                        width="40" height="40" class="rounded me-2" style="object-fit:cover;">
                                                    <?= htmlspecialchars($item['name']) ?>
                                                </td>
                                                <td>₹
                                                    <?= number_format($item['price'], 2) ?>
                                                </td>
                                                <td>x
                                                    <?= $item['quantity'] ?>
                                                </td>
                                                <td class="fw-bold">₹
                                                    <?= number_format($item['price'] * $item['quantity'], 2) ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <h4 class="text-end fw-bold text-primary">Final Amount: ₹
                                <?= number_format($order['total_amount'], 2) ?>
                            </h4>
                        </div>

                        <!-- Payment Verification Box (if UPI and Pending) -->
                        <?php if ($order['payment_method'] == 'UPI'): ?>
                            <div class="card p-4 shadow-sm border-0 mb-4"
                                style="border-left: 4px solid var(--accent-color) !important;">
                                <h5 class="mb-3 text-accent"><i class="fa-solid fa-qrcode me-2"></i> UPI Payment Info</h5>
                                <div class="row">
                                    <div class="col-md-6">
                                        <p><strong>Transaction ID:</strong> <span class="text-primary fw-bold">
                                                <?= htmlspecialchars($order['transaction_id'] ?? 'N/A') ?>
                                            </span></p>
                                        <p><strong>Status:</strong>
                                            <?php
                                            $bg = 'bg-warning text-dark';
                                            if ($order['payment_status'] == 'Paid')
                                                $bg = 'bg-success';
                                            if ($order['payment_status'] == 'Failed')
                                                $bg = 'bg-danger';
                                            ?>
                                            <span class="badge <?= $bg ?>">
                                                <?= $order['payment_status'] ?>
                                            </span>
                                        </p>
                                    </div>
                                    <div class="col-md-6 text-center">
                                        <?php if ($order['payment_proof']): ?>
                                            <p class="mb-1 fw-bold">Payment Screenshot</p>
                                            <a href="/coffeestore/assets/uploads/<?= htmlspecialchars($order['payment_proof']) ?>"
                                                target="_blank">
                                                <img src="/coffeestore/assets/uploads/<?= htmlspecialchars($order['payment_proof']) ?>"
                                                    class="img-thumbnail" style="max-height: 120px; cursor: pointer;">
                                            </a>
                                            <br><small class="text-muted">Click to enlarge</small>
                                        <?php else: ?>
                                            <div class="text-muted p-3 bg-light rounded">No screenshot uploaded.</div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <?php if ($order['payment_status'] == 'Verification Pending'): ?>
                                    <hr>
                                    <form method="POST" action="" class="d-flex align-items-center justify-content-end">
                                        <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                                        <span class="fw-bold me-3">Verify Payment:</span>
                                        <button type="submit" name="verify_payment" value="1" class="btn btn-success me-2"
                                            onclick="document.getElementById('pmt_stat_<?= $order['id'] ?>').value='Paid';">Approve</button>
                                        <button type="submit" name="verify_payment" value="1" class="btn btn-danger"
                                            onclick="document.getElementById('pmt_stat_<?= $order['id'] ?>').value='Failed';">Reject</button>
                                        <input type="hidden" name="payment_status" id="pmt_stat_<?= $order['id'] ?>" value="">
                                    </form>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>

                    </div>

                    <div class="col-md-4">
                        <div class="card p-4 shadow-sm border-0 mb-4 bg-light">
                            <h5 class="mb-3">Customer Details</h5>
                            <p class="mb-1"><strong><i class="fa-solid fa-user me-2"></i></strong>
                                <?= htmlspecialchars($order['user_name']) ?>
                            </p>
                            <p class="mb-1"><strong><i class="fa-solid fa-envelope me-2"></i></strong>
                                <?= htmlspecialchars($order['email']) ?>
                            </p>
                            <p class="mb-1"><strong><i class="fa-solid fa-phone me-2"></i></strong>
                                <?= htmlspecialchars($order['phone']) ?>
                            </p>
                            <p class="mb-0"><strong><i class="fa-solid fa-map-location-dot me-2"></i></strong>
                                <?= nl2br(htmlspecialchars($order['user_address'])) ?>
                            </p>
                        </div>

                        <div class="card p-4 shadow-sm border-0">
                            <h5 class="mb-3">Update Order</h5>
                            <form method="POST" action="">
                                <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                                <div class="mb-3">
                                    <label class="form-label text-muted">Order Status</label>
                                    <select name="order_status" class="form-select fw-bold text-primary">
                                        <?php foreach ($statuses as $st): ?>
                                            <option value="<?= $st ?>" <?= $order['order_status'] == $st ? 'selected' : '' ?>>
                                                <?= $st ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label text-muted">Assign Delivery Partner</label>
                                    <select name="delivery_boy_id" class="form-select">
                                        <option value="">-- Unassigned --</option>
                                        <?php foreach ($delivery_boys as $db): ?>
                                            <option value="<?= $db['id'] ?>" <?= $order['delivery_boy_id'] == $db['id'] ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($db['name']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <button type="submit" name="update_status" class="btn btn-primary w-100">Save
                                    Updates</button>
                            </form>
                        </div>
                    </div>
                </div>

            <?php else: ?>
                <!-- All Orders List -->
                <h2 class="mb-4 text-primary"><i class="fa-solid fa-list-check me-2"></i> Customer Orders</h2>
                <div class="card p-4 shadow-sm border-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th>ID</th>
                                    <th>Customer</th>
                                    <th>Amount</th>
                                    <th>Method</th>
                                    <th>Payment</th>
                                    <th>Status</th>
                                    <th>Delivery</th>
                                    <th>Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($orders) > 0): ?>
                                    <?php foreach ($orders as $o): ?>
                                        <tr>
                                            <td><span class="fw-bold">#ORD-
                                                    <?= str_pad($o['id'], 5, '0', STR_PAD_LEFT) ?>
                                                </span></td>
                                            <td>
                                                <?= htmlspecialchars($o['user_name']) ?><br><small class="text-muted">
                                                    <?= htmlspecialchars($o['phone']) ?>
                                                </small>
                                            </td>
                                            <td class="fw-bold">₹
                                                <?= number_format($o['total_amount'], 2) ?>
                                            </td>
                                            <td><span class="badge bg-secondary">
                                                    <?= $o['payment_method'] ?>
                                                </span></td>
                                            <td>
                                                <?php
                                                $bg = 'bg-warning text-dark';
                                                if ($o['payment_status'] == 'Paid')
                                                    $bg = 'bg-success';
                                                if ($o['payment_status'] == 'Failed')
                                                    $bg = 'bg-danger';
                                                ?>
                                                <span class="badge <?= $bg ?>">
                                                    <?= $o['payment_status'] ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php
                                                $bgs = 'bg-info text-dark';
                                                if ($o['order_status'] == 'Delivered')
                                                    $bgs = 'bg-success';
                                                ?>
                                                <span class="badge <?= $bgs ?>">
                                                    <?= $o['order_status'] ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?= $o['delivery_name'] ? htmlspecialchars($o['delivery_name']) : '<span class="text-muted fst-italic">Unassigned</span>' ?>
                                            </td>
                                            <td class="small">
                                                <?= date('d M, Y', strtotime($o['created_at'])) ?>
                                            </td>
                                            <td>
                                                <a href="orders.php?view=<?= $o['id'] ?>"
                                                    class="btn btn-sm btn-outline-primary">Process</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="9" class="text-center">No orders yet.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>