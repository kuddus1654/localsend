<?php
$page_title = "Store Settings";
require_once '../includes/header.php';
require_once '../includes/navbar.php';
requireAdmin();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $store_name = trim($_POST['store_name'] ?? '');
    $upi_id = trim($_POST['upi_id'] ?? '');

    if (empty($store_name) || empty($upi_id)) {
        flash('error', 'Store Name and UPI ID are required.');
    } else {
        $stmt = $pdo->prepare("UPDATE settings SET store_name = ?, upi_id = ?");
        if ($stmt->execute([$store_name, $upi_id])) {
            flash('success', 'Settings updated successfully.');
            redirect('settings.php');
        } else {
            flash('error', 'Failed to update settings.');
        }
    }
}
$settings = getSettings($pdo);
?>
<div class="container-fluid my-5 flex-grow-1">
    <div class="row">
        <!-- Admin Sidebar -->
        <div class="col-md-3 col-lg-2 d-none d-md-block admin-sidebar p-3">
            <h5 class="mb-4 text-center text-primary fw-bold">Admin Menu</h5>
            <div class="nav flex-column nav-pills">
                <a class="nav-link" href="dashboard.php"><i class="fa-solid fa-chart-line me-2"></i> Dashboard</a>
                <a class="nav-link" href="products.php"><i class="fa-solid fa-box-open me-2"></i> Products</a>
                <a class="nav-link" href="orders.php"><i class="fa-solid fa-list-check me-2"></i> Orders</a>
                <a class="nav-link" href="users.php"><i class="fa-solid fa-users me-2"></i> Users</a>
                <a class="nav-link" href="delivery.php"><i class="fa-solid fa-motorcycle me-2"></i> Delivery Boys</a>
                <a class="nav-link" href="coupons.php"><i class="fa-solid fa-tags me-2"></i> Coupons</a>
                <a class="nav-link active" href="settings.php"><i class="fa-solid fa-gear me-2"></i> Settings</a>
                <a class="nav-link" href="profile.php"><i class="fa-solid fa-user-shield me-2"></i> Profile</a>
            </div>
        </div>

        <div class="col-md-9 col-lg-10 px-md-4">
            <h2 class="mb-4 text-primary"><i class="fa-solid fa-gear me-2"></i> Store Settings</h2>

            <div class="row">
                <div class="col-md-8 mb-4">
                    <div class="card p-4 border-0 shadow">
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label class="form-label fw-bold">Store Name</label>
                                <input type="text" name="store_name" class="form-control"
                                    value="<?= htmlspecialchars($settings['store_name']) ?>" required>
                                <small class="text-muted">This name will appear on the navbar and user emails.</small>
                            </div>
                            <div class="mb-4">
                                <label class="form-label fw-bold">Dynamic UPI ID</label>
                                <input type="text" name="upi_id" class="form-control"
                                    value="<?= htmlspecialchars($settings['upi_id']) ?>" required>
                                <small class="text-muted">Payments will be collected on this UPI ID using dynamic QR
                                    codes.</small>
                            </div>
                            <button type="submit" class="btn btn-primary px-4"><i class="fa-solid fa-save me-2"></i>
                                Update Settings</button>
                        </form>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card p-4 border-0 shadow"
                        style="background-color: var(--bg-color); border-left: 4px solid var(--accent-color) !important;">
                        <h5 class="fw-bold text-primary"><i class="fa-solid fa-circle-info"></i> Information</h5>
                        <p class="mb-3 text-muted"><strong>UPI ID Note:</strong> Ensure the UPI ID is fully active and
                            merchant verified. Payments will directly map <code>pa=</code> payload during checkout.</p>
                        <p class="mb-0 text-muted">Changes to the UPI ID will take effect instantly across the whole
                            application.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>