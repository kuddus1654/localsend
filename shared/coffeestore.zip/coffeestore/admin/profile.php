<?php
$page_title = "Admin Profile";
require_once '../includes/header.php';
require_once '../includes/navbar.php';
requireAdmin();

$admin_id = $_SESSION['admin_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';

    $profile_image = null;
    $has_error = false;

    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png'];
        $filename = $_FILES['profile_image']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        $size = $_FILES['profile_image']['size'];

        if (in_array($ext, $allowed) && $size <= 2097152) {
            $new_name = 'admin_' . $admin_id . '_' . time() . '.' . $ext;
            $dest = '../assets/profile/' . $new_name;
            if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $dest)) {
                $profile_image = $new_name;

                $stmt = $pdo->prepare("SELECT profile_image FROM admins WHERE id = ?");
                $stmt->execute([$admin_id]);
                $old_img = $stmt->fetchColumn();
                if ($old_img && $old_img !== 'default_avatar.png' && file_exists('../assets/profile/' . $old_img)) {
                    unlink('../assets/profile/' . $old_img);
                }
            } else {
                flash('error', 'Failed to move uploaded file.');
                $has_error = true;
            }
        } else {
            flash('error', 'Invalid image format or size exceeds 2MB.');
            $has_error = true;
        }
    }

    if (!$has_error) {
        if (empty($name) || empty($phone)) {
            flash('error', 'Name and Phone are required.');
        } else {
            $query = "UPDATE admins SET name = ?, phone = ?";
            $params = [$name, $phone];

            if (!empty($password)) {
                $query .= ", password = ?";
                $params[] = password_hash($password, PASSWORD_DEFAULT);
            }

            if ($profile_image) {
                $query .= ", profile_image = ?";
                $params[] = $profile_image;
            }

            $query .= " WHERE id = ?";
            $params[] = $admin_id;

            $stmt = $pdo->prepare($query);
            if ($stmt->execute($params)) {
                $_SESSION['admin_name'] = $name;
                flash('success', 'Profile updated successfully.');
                redirect('profile.php');
            } else {
                flash('error', 'Update failed.');
            }
        }
    }
}

$stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch();
?>
<div class="container-fluid my-5 flex-grow-1">
    <div class="row">
        <!-- Admin Sidebar -->
        <div class="col-md-3 col-lg-2 d-none d-md-block admin-sidebar p-3">
            <h5 class="mb-4 text-center text-primary fw-bold">Admin Menu</h5>
            <div class="nav flex-column nav-pills">
                <a class="nav-link" href="dashboard.php"><i class="fa-solid fa-chart-line me-2"></i> Dashboard</a>
                <a class="nav-link" href="products.php"><i class="fa-solid fa-box-open me-2"></i> Products</a>
                <a class="nav-link" href="orders.php"><i class="fa-solid fa-list-check me-2"></i> Orders</a>
                <a class="nav-link" href="users.php"><i class="fa-solid fa-users me-2"></i> Users</a>
                <a class="nav-link" href="delivery.php"><i class="fa-solid fa-motorcycle me-2"></i> Delivery Boys</a>
                <a class="nav-link" href="coupons.php"><i class="fa-solid fa-tags me-2"></i> Coupons</a>
                <a class="nav-link" href="settings.php"><i class="fa-solid fa-gear me-2"></i> Settings</a>
                <a class="nav-link active" href="profile.php"><i class="fa-solid fa-user-shield me-2"></i> Profile</a>
            </div>
        </div>

        <div class="col-md-9 col-lg-10 px-md-4">
            <h2 class="mb-4"><i class="fa-solid fa-user-shield text-primary"></i> Admin Profile</h2>

            <div class="row">
                <div class="col-md-4 text-center mb-4">
                    <div class="card p-4">
                        <img src="/coffeestore/assets/profile/<?= htmlspecialchars($admin['profile_image']) ?>"
                            class="profile-img-preview mx-auto mb-3" alt="Profile">
                        <h4 class="mb-0">
                            <?= htmlspecialchars($admin['name']) ?>
                        </h4>
                        <p class="text-muted">
                            <?= htmlspecialchars($admin['email']) ?>
                        </p>
                        <span class="badge bg-primary mx-auto w-50 p-2">Administrator</span>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="card p-4 border-0 shadow"
                        style="border-top: 5px solid var(--primary-color) !important;">
                        <h4 class="mb-4">Edit Details</h4>
                        <form method="POST" action="" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Full Name</label>
                                    <input type="text" name="name" class="form-control"
                                        value="<?= htmlspecialchars($admin['name']) ?>" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Phone Number</label>
                                    <input type="text" name="phone" class="form-control"
                                        value="<?= htmlspecialchars($admin['phone']) ?>" required>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Profile Image (Max 2MB, JPG/PNG)</label>
                                <input type="file" name="profile_image" class="form-control" accept=".jpg,.jpeg,.png">
                            </div>
                            <hr>
                            <div class="mb-4">
                                <label class="form-label">Change Password (leave blank to keep current)</label>
                                <input type="password" name="password" class="form-control">
                            </div>
                            <button type="submit" class="btn btn-primary">Save Changes</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>