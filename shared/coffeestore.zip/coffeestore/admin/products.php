<?php
$page_title = "Manage Products & Categories";
require_once '../includes/header.php';
require_once '../includes/navbar.php';
requireAdmin();

// Handle Category Addition
if (isset($_POST['add_category'])) {
    $name = trim($_POST['cat_name']);
    if (!empty($name)) {
        $stmt = $pdo->prepare("INSERT INTO categories (name) VALUES (?)");
        $stmt->execute([$name]);
        flash('success', 'Category added.');
    }
    redirect('products.php');
}

// Handle Category Deletion
if (isset($_GET['delete_cat'])) {
    $id = (int)$_GET['delete_cat'];
    $pdo->prepare("DELETE FROM categories WHERE id = ?")->execute([$id]);
    flash('success', 'Category deleted.');
    redirect('products.php');
}

// Handle Product Deletion
if (isset($_GET['delete_prod'])) {
    $id = (int)$_GET['delete_prod'];
    // Delete image first
    $stmt = $pdo->prepare("SELECT image FROM products WHERE id = ?");
    $stmt->execute([$id]);
    $img = $stmt->fetchColumn();
    if ($img && file_exists("../assets/uploads/" . $img)) {
        unlink("../assets/uploads/" . $img);
    }
    $pdo->prepare("DELETE FROM products WHERE id = ?")->execute([$id]);
    flash('success', 'Product deleted.');
    redirect('products.php');
}

// Handle Product Add / Edit
if (isset($_POST['save_product'])) {
    $id = $_POST['product_id'] ?? '';
    $cat_id = $_POST['category_id'];
    $name = trim($_POST['name']);
    $desc = trim($_POST['description']);
    $roast = $_POST['roast_level'];
    $price = $_POST['price'];
    $disc_price = !empty($_POST['discount_price']) ? $_POST['discount_price'] : null;
    $stock = $_POST['stock'];
    
    $image = $_POST['existing_image'] ?? '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg', 'jpeg', 'png']) && $_FILES['image']['size'] <= 2097152) {
            $new_name = 'prod_' . time() . '.' . $ext;
            if (move_uploaded_file($_FILES['image']['tmp_name'], "../assets/uploads/" . $new_name)) {
                // delete old one
                if ($image && file_exists("../assets/uploads/" . $image)) unlink("../assets/uploads/" . $image);
                $image = $new_name;
            }
        }
    }
    
    if (empty($id)) {
        if (empty($image)) {
            flash('error', 'Image is required for new product.');
            redirect('products.php');
        }
        $stmt = $pdo->prepare("INSERT INTO products (category_id, name, description, roast_level, price, discount_price, stock, image) VALUES (?,?,?,?,?,?,?,?)");
        $stmt->execute([$cat_id, $name, $desc, $roast, $price, $disc_price, $stock, $image]);
        flash('success', 'Product added.');
    } else {
        $stmt = $pdo->prepare("UPDATE products SET category_id=?, name=?, description=?, roast_level=?, price=?, discount_price=?, stock=?, image=? WHERE id=?");
        $stmt->execute([$cat_id, $name, $desc, $roast, $price, $disc_price, $stock, $image, $id]);
        flash('success', 'Product updated.');
    }
    redirect('products.php');
}

$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();
$products = $pdo->query("SELECT p.*, c.name as cat_name FROM products p JOIN categories c ON p.category_id = c.id ORDER BY p.id DESC")->fetchAll();
?>
<div class="container-fluid my-5 flex-grow-1">
    <div class="row">
        <!-- Admin Sidebar -->
        <div class="col-md-3 col-lg-2 d-none d-md-block admin-sidebar p-3">
            <h5 class="mb-4 text-center text-primary fw-bold">Admin Menu</h5>
            <div class="nav flex-column nav-pills">
                <a class="nav-link" href="dashboard.php"><i class="fa-solid fa-chart-line me-2"></i> Dashboard</a>
                <a class="nav-link active" href="products.php"><i class="fa-solid fa-box-open me-2"></i> Products</a>
                <a class="nav-link" href="orders.php"><i class="fa-solid fa-list-check me-2"></i> Orders</a>
                <a class="nav-link" href="users.php"><i class="fa-solid fa-users me-2"></i> Users</a>
                <a class="nav-link" href="delivery.php"><i class="fa-solid fa-motorcycle me-2"></i> Delivery Boys</a>
                <a class="nav-link" href="coupons.php"><i class="fa-solid fa-tags me-2"></i> Coupons</a>
                <a class="nav-link" href="settings.php"><i class="fa-solid fa-gear me-2"></i> Settings</a>
                <a class="nav-link" href="profile.php"><i class="fa-solid fa-user-shield me-2"></i> Profile</a>
            </div>
        </div>

        <div class="col-md-9 col-lg-10 px-md-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2 class="text-primary m-0"><i class="fa-solid fa-box-open me-2"></i> Products & Categories</h2>
                <div>
                    <button class="btn btn-outline-primary me-2" data-bs-toggle="modal" data-bs-target="#categoryModal">Manage Categories</button>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#productModal" onclick="resetForm()">+ Add Product</button>
                </div>
            </div>
            
            <div class="card p-4 shadow-sm border-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Image</th>
                                <th>Name / Category</th>
                                <th>Roast</th>
                                <th>Price</th>
                                <th>Stock</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($products) > 0): ?>
                                <?php foreach($products as $p): ?>
                                <tr>
                                    <td>
                                        <img src="/coffeestore/assets/uploads/<?= htmlspecialchars($p['image']) ?>" width="60" height="60" style="object-fit:cover; border-radius:8px;">
                                    </td>
                                    <td>
                                        <span class="fw-bold d-block"><?= htmlspecialchars($p['name']) ?></span>
                                        <small class="text-muted"><?= htmlspecialchars($p['cat_name']) ?></small>
                                    </td>
                                    <td><span class="badge bg-secondary"><?= $p['roast_level'] ?></span></td>
                                    <td>
                                        ₹<?= number_format($p['price'], 2) ?>
                                        <?php if($p['discount_price']): ?>
                                            <br><small class="text-success"><i class="fa-solid fa-tag"></i> <?= number_format($p['discount_price'], 2) ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($p['stock'] > 10): ?>
                                            <span class="badge bg-success"><?= $p['stock'] ?></span>
                                        <?php elseif($p['stock'] > 0): ?>
                                            <span class="badge bg-warning text-dark"><?= $p['stock'] ?></span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Out of Stock</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-secondary" onclick='editProduct(<?= json_encode($p) ?>)'><i class="fa-solid fa-pen"></i> Edit</button>
                                        <a href="products.php?delete_prod=<?= $p['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this product?');"><i class="fa-solid fa-trash"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="6" class="text-center">No products found. Add a category and then a product.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
        </div>
    </div>
</div>

<!-- Category Modal -->
<div class="modal fade" id="categoryModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Manage Categories</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <form method="POST" action="">
            <div class="input-group mb-3">
                <input type="text" class="form-control" name="cat_name" placeholder="New Category Name" required>
                <button type="submit" name="add_category" class="btn btn-primary">Add</button>
            </div>
        </form>
        <hr>
        <ul class="list-group">
            <?php foreach($categories as $c): ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                <?= htmlspecialchars($c['name']) ?>
                <a href="products.php?delete_cat=<?= $c['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deleting a category deletes its products. Proceed?');"><i class="fa-solid fa-trash"></i></a>
            </li>
            <?php endforeach; ?>
        </ul>
      </div>
    </div>
  </div>
</div>

<!-- Product Modal -->
<div class="modal fade" id="productModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <form method="POST" action="" enctype="multipart/form-data">
          <div class="modal-header">
            <h5 class="modal-title" id="productModalTitle">Add Product</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <input type="hidden" name="product_id" id="prod_id">
            <input type="hidden" name="existing_image" id="existing_image">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label>Product Name</label>
                    <input type="text" name="name" id="prod_name" class="form-control" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label>Category</label>
                    <select name="category_id" id="prod_cat" class="form-select" required>
                        <option value="">Select...</option>
                        <?php foreach($categories as $c): ?>
                            <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-12 mb-3">
                    <label>Description</label>
                    <textarea name="description" id="prod_desc" class="form-control" rows="3" required></textarea>
                </div>
                <div class="col-md-4 mb-3">
                    <label>Roast Level</label>
                    <select name="roast_level" id="prod_roast" class="form-select" required>
                        <option value="Light">Light</option>
                        <option value="Medium" selected>Medium</option>
                        <option value="Dark">Dark</option>
                    </select>
                </div>
                <div class="col-md-4 mb-3">
                    <label>Price (₹)</label>
                    <input type="number" step="0.01" name="price" id="prod_price" class="form-control" required>
                </div>
                <div class="col-md-4 mb-3">
                    <label>Discount Price (₹) <small class="text-muted">(Optional)</small></label>
                    <input type="number" step="0.01" name="discount_price" id="prod_disc" class="form-control">
                </div>
                <div class="col-md-6 mb-3">
                    <label>Stock Quantity</label>
                    <input type="number" name="stock" id="prod_stock" class="form-control" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label>Product Image</label>
                    <input type="file" name="image" class="form-control" accept=".jpg,.jpeg,.png">
                    <small class="text-muted" id="img_help">Required for new product.</small>
                </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="submit" name="save_product" class="btn btn-primary">Save Product</button>
          </div>
      </form>
    </div>
  </div>
</div>

<script>
function resetForm() {
    document.getElementById('productModalTitle').innerText = 'Add Product';
    document.getElementById('prod_id').value = '';
    document.getElementById('existing_image').value = '';
    document.getElementById('prod_name').value = '';
    document.getElementById('prod_cat').value = '';
    document.getElementById('prod_desc').value = '';
    document.getElementById('prod_roast').value = 'Medium';
    document.getElementById('prod_price').value = '';
    document.getElementById('prod_disc').value = '';
    document.getElementById('prod_stock').value = '';
    document.getElementById('img_help').innerText = 'Required for new product.';
}

function editProduct(p) {
    document.getElementById('productModalTitle').innerText = 'Edit Product';
    document.getElementById('prod_id').value = p.id;
    document.getElementById('existing_image').value = p.image;
    document.getElementById('prod_name').value = p.name;
    document.getElementById('prod_cat').value = p.category_id;
    document.getElementById('prod_desc').value = p.description;
    document.getElementById('prod_roast').value = p.roast_level;
    document.getElementById('prod_price').value = p.price;
    document.getElementById('prod_disc').value = p.discount_price || '';
    document.getElementById('prod_stock').value = p.stock;
    document.getElementById('img_help').innerText = 'Leave empty to keep current image.';
    var myModal = new bootstrap.Modal(document.getElementById('productModal'));
    myModal.show();
}
</script>

<?php require_once '../includes/footer.php'; ?>
