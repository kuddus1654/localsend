<?php
$page_title = "Delivery Profile";
require_once '../includes/header.php';
require_once '../includes/navbar.php';
requireDelivery();

$delivery_id = $_SESSION['delivery_boy_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $password = $_POST['password'] ?? '';

    $profile_image = null;
    $has_error = false;

    if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png'];
        $filename = $_FILES['profile_image']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        $size = $_FILES['profile_image']['size'];

        if (in_array($ext, $allowed) && $size <= 2097152) {
            $new_name = 'del_' . $delivery_id . '_' . time() . '.' . $ext;
            $dest = '../assets/profile/' . $new_name;
            if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $dest)) {
                $profile_image = $new_name;

                $stmt = $pdo->prepare("SELECT profile_image FROM delivery_boys WHERE id = ?");
                $stmt->execute([$delivery_id]);
                $old_img = $stmt->fetchColumn();
                if ($old_img && $old_img !== 'default_avatar.png' && file_exists('../assets/profile/' . $old_img)) {
                    unlink('../assets/profile/' . $old_img);
                }
            } else {
                flash('error', 'Failed to move uploaded file.');
                $has_error = true;
            }
        } else {
            flash('error', 'Invalid image format or size exceeds 2MB.');
            $has_error = true;
        }
    }

    if (!$has_error) {
        if (empty($name) || empty($phone)) {
            flash('error', 'Name and Phone are required.');
        } else {
            $query = "UPDATE delivery_boys SET name = ?, phone = ?, address = ?";
            $params = [$name, $phone, $address];

            if (!empty($password)) {
                $query .= ", password = ?";
                $params[] = password_hash($password, PASSWORD_DEFAULT);
            }

            if ($profile_image) {
                $query .= ", profile_image = ?";
                $params[] = $profile_image;
            }

            $query .= " WHERE id = ?";
            $params[] = $delivery_id;

            $stmt = $pdo->prepare($query);
            if ($stmt->execute($params)) {
                $_SESSION['delivery_boy_name'] = $name;
                flash('success', 'Profile updated successfully.');
                redirect('profile.php');
            } else {
                flash('error', 'Update failed.');
            }
        }
    }
}

$stmt = $pdo->prepare("SELECT * FROM delivery_boys WHERE id = ?");
$stmt->execute([$delivery_id]);
$delivery = $stmt->fetch();
?>
<div class="container my-5 flex-grow-1">
    <div class="row">
        <div class="col-md-4 text-center mb-4">
            <div class="card p-4 border-0 shadow" style="border-top: 5px solid var(--accent-color) !important;">
                <img src="/coffeestore/assets/profile/<?= htmlspecialchars($delivery['profile_image']) ?>"
                    class="profile-img-preview mx-auto mb-3" alt="Profile">
                <h4 class="mb-0">
                    <?= htmlspecialchars($delivery['name']) ?>
                </h4>
                <p class="text-muted mb-2">
                    <?= htmlspecialchars($delivery['email']) ?>
                </p>
                <span class="badge bg-success mx-auto p-2">Active Partner</span>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card p-4 border-0 shadow">
                <h4 class="mb-4"><i class="fa-solid fa-motorcycle text-accent"></i> Delivery Partner Profile</h4>
                <form method="POST" action="" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Full Name</label>
                            <input type="text" name="name" class="form-control"
                                value="<?= htmlspecialchars($delivery['name']) ?>" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Phone Number</label>
                            <input type="text" name="phone" class="form-control"
                                value="<?= htmlspecialchars($delivery['phone']) ?>" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Area / Address</label>
                        <textarea name="address" class="form-control"
                            rows="3"><?= htmlspecialchars($delivery['address'] ?? '') ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Profile Image (Max 2MB, JPG/PNG)</label>
                        <input type="file" name="profile_image" class="form-control" accept=".jpg,.jpeg,.png">
                    </div>
                    <hr>
                    <div class="mb-4">
                        <label class="form-label">Change Password (leave blank to keep current)</label>
                        <input type="password" name="password" class="form-control">
                    </div>
                    <button type="submit" class="btn btn-accent w-100 fw-bold">Update Details</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>