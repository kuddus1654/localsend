<?php
$page_title = "Delivery Login";
require_once '../includes/header.php';
require_once '../includes/navbar.php';

if (isDelivery())
    redirect('/coffeestore/delivery/dashboard.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        flash('error', 'All fields are required.');
    } else {
        $stmt = $pdo->prepare("SELECT * FROM delivery_boys WHERE email = ?");
        $stmt->execute([$email]);
        $delivery = $stmt->fetch();

        if ($delivery && password_verify($password, $delivery['password'])) {
            if ($delivery['is_active']) {
                $_SESSION['delivery_boy_id'] = $delivery['id'];
                $_SESSION['delivery_boy_name'] = $delivery['name'];
                flash('success', 'Delivery partner login successful.');
                redirect('/coffeestore/delivery/dashboard.php');
            } else {
                flash('error', 'Your account is disabled. Contact Admin.');
            }
        } else {
            flash('error', 'Invalid delivery credentials.');
        }
    }
}
?>
<div class="container my-5 flex-grow-1">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card p-4 border-0 shadow" style="border-top: 5px solid var(--accent-color) !important;">
                <h3 class="text-center mb-4"><i class="fa-solid fa-motorcycle text-accent"></i> Delivery Partner</h3>
                <form method="POST" action="">
                    <div class="mb-3">
                        <label class="form-label">Email Address</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="mb-4">
                        <label class="form-label">Password</label>
                        <div class="input-group">
                            <input type="password" name="password" id="deliveryPassword" class="form-control" required>
                            <button class="btn btn-outline-secondary toggle-password" type="button"
                                data-target="#deliveryPassword">
                                <i class="fa-regular fa-eye"></i>
                            </button>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-accent w-100">Start Shift</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>