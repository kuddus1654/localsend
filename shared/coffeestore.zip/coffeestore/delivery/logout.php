<?php
session_start();
unset($_SESSION['delivery_boy_id']);
unset($_SESSION['delivery_boy_name']);
$_SESSION['flash']['success'] = "Delivery logged out.";
header("Location: /coffeestore/delivery/login.php");
exit;
?>