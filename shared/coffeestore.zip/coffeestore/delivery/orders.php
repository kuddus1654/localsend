<?php
$page_title = "Assigned Orders";
require_once '../includes/header.php';
require_once '../includes/navbar.php';
requireDelivery();

$delivery_id = $_SESSION['delivery_boy_id'];

// Handle Status Update
if (isset($_POST['update_status'])) {
    $order_id = (int) $_POST['order_id'];
    $status = $_POST['order_status'];

    // Verify it belongs to this delivery boy
    $stmt = $pdo->prepare("UPDATE orders SET order_status = ? WHERE id = ? AND delivery_boy_id = ?");
    $stmt->execute([$status, $order_id, $delivery_id]);

    flash('success', 'Order status updated successfully.');
    redirect("orders.php?view=$order_id");
}

if (isset($_GET['view'])) {
    $order_id = (int) $_GET['view'];
    $stmt = $pdo->prepare("SELECT o.*, u.name as user_name, u.phone, u.address FROM orders o JOIN users u ON o.user_id = u.id WHERE o.id = ? AND o.delivery_boy_id = ?");
    $stmt->execute([$order_id, $delivery_id]);
    $order = $stmt->fetch();

    if (!$order)
        redirect('orders.php');

    $stmt = $pdo->prepare("SELECT oi.*, p.name FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?");
    $stmt->execute([$order_id]);
    $items = $stmt->fetchAll();

    $statuses = ['Confirmed', 'Preparing', 'Out for delivery', 'Delivered'];
} else {
    $stmt = $pdo->prepare("SELECT o.*, u.name as user_name, u.phone FROM orders o JOIN users u ON o.user_id = u.id WHERE o.delivery_boy_id = ? ORDER BY o.created_at DESC");
    $stmt->execute([$delivery_id]);
    $orders = $stmt->fetchAll();
}
?>

<div class="container-fluid my-5 flex-grow-1">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 col-lg-2 d-none d-md-block admin-sidebar p-3">
            <h5 class="mb-4 text-center text-accent fw-bold">Delivery Menu</h5>
            <div class="nav flex-column nav-pills">
                <a class="nav-link" href="dashboard.php"><i class="fa-solid fa-motorcycle me-2"></i> Dashboard</a>
                <a class="nav-link active" href="orders.php"><i class="fa-solid fa-list-check me-2"></i> My Orders</a>
                <a class="nav-link" href="profile.php"><i class="fa-solid fa-user me-2"></i> Profile</a>
            </div>
        </div>

        <div class="col-md-9 col-lg-10 px-md-4">
            <?php if (isset($_GET['view'])): ?>
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2 class="text-primary m-0 fw-bold"><i class="fa-solid fa-box me-2 d-none d-md-inline-block"></i>
                        Manage Delivery</h2>
                    <a href="orders.php" class="btn btn-outline-secondary fw-bold rounded-pill px-3"><i
                            class="fa-solid fa-arrow-left me-1"></i> Back</a>
                </div>

                <div class="row">
                    <div class="col-md-7">
                        <div class="card p-4 shadow-sm border-0 mb-4 bg-light rounded-4">
                            <h5 class="mb-3 text-primary fw-bold text-uppercase letter-spacing-1"><i
                                    class="fa-solid fa-location-dot me-2 text-danger"></i> Delivery Destination</h5>
                            <h3 class="mb-2 fw-bold text-dark">
                                <?= htmlspecialchars($order['user_name']) ?>
                            </h3>
                            <div class="d-flex align-items-center mb-3 mt-1">
                                <a href="tel:<?= htmlspecialchars($order['phone']) ?>"
                                    class="btn btn-outline-primary btn-sm rounded-pill fw-bold">
                                    <i class="fa-solid fa-phone me-1"></i>
                                    <?= htmlspecialchars($order['phone']) ?>
                                </a>
                            </div>
                            <div class="bg-white p-3 rounded shadow-sm border">
                                <p class="mb-0 fw-bold text-muted"><i
                                        class="fa-solid fa-map-location-dot text-primary me-2"></i> Complete Address</p>
                                <p class="mt-2 mb-0 ms-4">
                                    <?= nl2br(htmlspecialchars($order['address'])) ?>
                                </p>
                            </div>
                        </div>

                        <div class="card p-4 shadow-sm border-0 mb-4 rounded-4">
                            <h5 class="mb-4 fw-bold border-bottom pb-2 text-primary"><i
                                    class="fa-solid fa-mug-hot me-2"></i> Order Items</h5>
                            <ul class="list-group list-group-flush mb-3">
                                <?php foreach ($items as $item): ?>
                                    <li
                                        class="list-group-item px-0 d-flex justify-content-between align-items-center border-bottom-0 pb-2">
                                        <span class="fs-5 text-dark">
                                            <?= htmlspecialchars($item['name']) ?> <strong
                                                class="ms-2 badge bg-light text-dark border">x
                                                <?= $item['quantity'] ?>
                                            </strong>
                                        </span>
                                        <span class="fw-bold text-muted">₹
                                            <?= number_format($item['price'] * $item['quantity'], 2) ?>
                                        </span>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                            <div class="d-flex justify-content-between border-top pt-3 mt-2">
                                <span class="fw-bold fs-5 text-uppercase text-muted">Total Collectible:</span>
                                <h3 class="text-success fw-bold m-0">₹
                                    <?= number_format($order['total_amount'], 2) ?>
                                </h3>
                            </div>

                            <div
                                class="mt-4 p-4 rounded-4 border shadow-sm <?= $order['payment_method'] == 'COD' ? 'bg-warning bg-opacity-10 border-warning' : 'bg-primary bg-opacity-10 border-primary' ?>">
                                <div class="d-flex align-items-center">
                                    <i
                                        class="fa-solid <?= $order['payment_method'] == 'COD' ? 'fa-money-bill-wave text-warning' : 'fa-qrcode text-primary' ?> fa-2x me-3"></i>
                                    <div>
                                        <strong class="d-block fs-5">Payment Method:
                                            <?= $order['payment_method'] ?>
                                        </strong>
                                        <?php if ($order['payment_method'] == 'COD'): ?>
                                            <small class="text-dark fw-bold">Important: Collect cash from customer upon
                                                delivery.</small>
                                        <?php else: ?>
                                            <small class="text-muted">Prepaid via UPI. Do not collect cash.</small>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-5">
                        <div class="card p-4 shadow-sm border-0 rounded-4 sticky-top" style="top: 80px; z-index: 10;">
                            <h5 class="mb-4 fw-bold text-primary"><i class="fa-solid fa-pen-to-square me-2"></i> Update
                                Order Status</h5>
                            <form method="POST" action="">
                                <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                                <div class="mb-4">
                                    <label class="form-label text-muted fw-bold text-uppercase small">Current Status</label>
                                    <select name="order_status"
                                        class="form-select form-select-lg fw-bold text-dark border-2 shadow-sm">
                                        <?php foreach ($statuses as $st): ?>
                                            <option value="<?= $st ?>" <?= $order['order_status'] == $st ? 'selected' : '' ?>>
                                                <?= $st ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <button type="submit" name="update_status"
                                    class="btn btn-primary btn-lg w-100 shadow fw-bold rounded-pill"
                                    <?= $order['order_status'] == 'Delivered' ? 'disabled' : '' ?>><i
                                        class="fa-solid fa-cloud-arrow-up me-2"></i> Save Status Update</button>
                                <?php if ($order['order_status'] == 'Delivered'): ?>
                                    <div class="alert alert-success text-center mt-4 mb-0 fw-bold border-0"><i
                                            class="fa-solid fa-circle-check fa-lg me-2"></i> This order has been delivered and
                                        is now complete.</div>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <h2 class="text-primary mb-4 fw-bold"><i class="fa-solid fa-list-check me-2"></i> My Assigned Orders</h2>
                <div class="card p-0 shadow-sm border-0 overflow-hidden rounded-4">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle m-0">
                            <thead class="table-light">
                                <tr>
                                    <th class="ps-4 text-secondary text-uppercase small fw-bold">Order ID</th>
                                    <th class="text-secondary text-uppercase small fw-bold">Customer Name</th>
                                    <th class="text-secondary text-uppercase small fw-bold">Contact Number</th>
                                    <th class="text-secondary text-uppercase small fw-bold">Amount</th>
                                    <th class="text-secondary text-uppercase small fw-bold">Method</th>
                                    <th class="text-secondary text-uppercase small fw-bold">Assign Date</th>
                                    <th class="text-secondary text-uppercase small fw-bold">Current Status</th>
                                    <th class="text-end pe-4 text-secondary text-uppercase small fw-bold">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($orders) > 0): ?>
                                    <?php foreach ($orders as $o): ?>
                                        <tr class="<?= $o['order_status'] == 'Delivered' ? 'bg-light text-muted' : '' ?>">
                                            <td
                                                class="ps-4 fw-bold <?= $o['order_status'] == 'Delivered' ? 'text-muted' : 'text-dark' ?>">
                                                #ORD-
                                                <?= str_pad($o['id'], 5, '0', STR_PAD_LEFT) ?>
                                            </td>
                                            <td class="fw-bold">
                                                <?= htmlspecialchars($o['user_name']) ?>
                                            </td>
                                            <td>
                                                <?php if ($o['order_status'] != 'Delivered'): ?>
                                                    <a href="tel:<?= htmlspecialchars($o['phone']) ?>"
                                                        class="btn btn-sm btn-outline-primary rounded-pill px-2 py-0"><i
                                                            class="fa-solid fa-phone fa-xs me-1"></i> Call</a>
                                                <?php else: ?>
                                                    <span class="text-muted"><i class="fa-solid fa-phone-slash me-1"></i> --</span>
                                                <?php endif; ?>
                                            </td>
                                            <td
                                                class="fw-bold <?= $o['order_status'] == 'Delivered' ? 'text-muted' : 'text-success' ?>">
                                                ₹
                                                <?= number_format($o['total_amount'], 2) ?>
                                            </td>
                                            <td><span class="badge bg-secondary">
                                                    <?= $o['payment_method'] ?>
                                                </span></td>
                                            <td class="small text-muted">
                                                <?= date('d M, h:i A', strtotime($o['created_at'])) ?>
                                            </td>
                                            <td>
                                                <?php
                                                $bgs = 'bg-info text-dark';
                                                if ($o['order_status'] == 'Delivered')
                                                    $bgs = 'bg-success bg-opacity-50 text-white';
                                                if ($o['order_status'] == 'Confirmed')
                                                    $bgs = 'bg-primary';
                                                if ($o['order_status'] == 'Preparing')
                                                    $bgs = 'bg-warning text-dark';
                                                ?>
                                                <span class="badge <?= $bgs ?> py-1 px-2">
                                                    <?= $o['order_status'] ?>
                                                </span>
                                            </td>
                                            <td class="text-end pe-4">
                                                <a href="orders.php?view=<?= $o['id'] ?>"
                                                    class="btn btn-sm <?= $o['order_status'] == 'Delivered' ? 'btn-outline-secondary' : 'btn-primary shadow-sm' ?> px-3 rounded-pill fw-bold">
                                                    <?= $o['order_status'] == 'Delivered' ? 'View' : 'Manage' ?>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8" class="text-center py-5">
                                            <i class="fa-solid fa-box-open fa-3x text-muted opacity-25 mb-3 d-block"></i>
                                            <span class="text-muted">No orders assigned to you yet.</span>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<style>
    .letter-spacing-1 {
        letter-spacing: 1px;
    }
</style>
<?php require_once '../includes/footer.php'; ?>