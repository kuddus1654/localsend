<?php
$page_title = "Delivery Dashboard";
require_once '../includes/header.php';
require_once '../includes/navbar.php';
requireDelivery();

$delivery_id = $_SESSION['delivery_boy_id'];

// Stats
$stmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE delivery_boy_id = ? AND order_status IN ('Confirmed', 'Preparing', 'Out for delivery')");
$stmt->execute([$delivery_id]);
$active_orders = $stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE delivery_boy_id = ? AND order_status = 'Delivered'");
$stmt->execute([$delivery_id]);
$completed_orders = $stmt->fetchColumn();

// Recent 5 active orders
$stmt = $pdo->prepare("SELECT o.*, u.name as user_name, u.phone, u.address FROM orders o JOIN users u ON o.user_id = u.id WHERE o.delivery_boy_id = ? AND o.order_status != 'Delivered' ORDER BY o.created_at DESC LIMIT 5");
$stmt->execute([$delivery_id]);
$recent_orders = $stmt->fetchAll();
?>
<div class="container-fluid my-5 flex-grow-1">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3 col-lg-2 d-none d-md-block admin-sidebar p-3">
            <h5 class="mb-4 text-center text-accent fw-bold">Delivery Menu</h5>
            <div class="nav flex-column nav-pills">
                <a class="nav-link active" href="dashboard.php"><i class="fa-solid fa-motorcycle me-2"></i> Dashboard</a>
                <a class="nav-link" href="orders.php"><i class="fa-solid fa-list-check me-2"></i> My Orders</a>
                <a class="nav-link" href="profile.php"><i class="fa-solid fa-user me-2"></i> Profile</a>
            </div>
        </div>

        <div class="col-md-9 col-lg-10 px-md-4">
            <h2 class="text-primary mb-4 fw-bold">Welcome, <?= htmlspecialchars($_SESSION['delivery_boy_name']) ?>! <i class="fa-solid fa-hand-wave text-warning"></i></h2>
            
            <div class="row g-4 mb-5">
                <div class="col-md-6">
                    <div class="card p-4 border-0 shadow-sm bg-primary text-white text-center rounded-4 h-100 position-relative overflow-hidden" style="border-bottom: 5px solid var(--accent-color) !important;">
                        <i class="fa-solid fa-motorcycle fa-4x mb-3 text-accent opacity-75 position-absolute" style="top: -10px; right: -10px;"></i>
                        <h1 class="display-3 fw-bold mb-0 position-relative z-1"><?= $active_orders ?></h1>
                        <p class="fs-5 mb-0 text-white-50 fw-bold position-relative z-1 text-uppercase letter-spacing-1">Active Deliveries</p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card p-4 border-0 shadow-sm bg-success text-white text-center rounded-4 h-100 position-relative overflow-hidden">
                        <i class="fa-solid fa-check-double fa-4x mb-3 text-white-50 opacity-25 position-absolute" style="top: -10px; right: -10px;"></i>
                        <h1 class="display-3 fw-bold mb-0 position-relative z-1"><?= $completed_orders ?></h1>
                        <p class="fs-5 mb-0 text-white-50 fw-bold position-relative z-1 text-uppercase letter-spacing-1">Completed Deliveries</p>
                    </div>
                </div>
            </div>
            
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4 class="fw-bold text-dark m-0"><i class="fa-solid fa-clock-rotate-left me-2 text-primary"></i> Recent Active Orders</h4>
                <a href="orders.php" class="btn btn-outline-primary btn-sm rounded-pill px-3 fw-bold">View All Assigned</a>
            </div>
            
            <div class="card p-0 shadow-sm border-0 overflow-hidden">
                <div class="table-responsive">
                    <table class="table table-hover align-middle m-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4 text-secondary text-uppercase small fw-bold">Order ID</th>
                                <th class="text-secondary text-uppercase small fw-bold">Customer Name</th>
                                <th class="text-secondary text-uppercase small fw-bold">Contact</th>
                                <th class="text-secondary text-uppercase small fw-bold">Amount</th>
                                <th class="text-secondary text-uppercase small fw-bold">Method</th>
                                <th class="text-secondary text-uppercase small fw-bold">Status</th>
                                <th class="text-end pe-4 text-secondary text-uppercase small fw-bold">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($recent_orders) > 0): ?>
                                <?php foreach($recent_orders as $o): ?>
                                <tr>
                                    <td class="ps-4 fw-bold text-dark">#ORD-<?= str_pad($o['id'], 5, '0', STR_PAD_LEFT) ?></td>
                                    <td class="fw-bold"><?= htmlspecialchars($o['user_name']) ?></td>
                                    <td><a href="tel:<?= htmlspecialchars($o['phone']) ?>" class="text-decoration-none text-muted"><i class="fa-solid fa-phone fa-sm me-1"></i> <?= htmlspecialchars($o['phone']) ?></a></td>
                                    <td class="fw-bold text-success">₹<?= number_format($o['total_amount'], 2) ?></td>
                                    <td><span class="badge bg-secondary"><?= $o['payment_method'] ?></span></td>
                                    <td>
                                        <?php 
                                            $bgs = 'bg-info text-dark';
                                            if ($o['order_status'] == 'Confirmed') $bgs = 'bg-primary';
                                            if ($o['order_status'] == 'Preparing') $bgs = 'bg-warning text-dark';
                                        ?>
                                        <span class="badge <?= $bgs ?> py-1 px-2"><?= $o['order_status'] ?></span>
                                    </td>
                                    <td class="text-end pe-4">
                                        <a href="orders.php?view=<?= $o['id'] ?>" class="btn btn-sm btn-primary px-3 rounded-pill fw-bold shadow-sm">Manage</a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="7" class="text-center py-5 text-muted"><i class="fa-solid fa-mug-hot fa-3x opacity-25 mb-3 d-block"></i> No active orders assigned currently. Enjoy a coffee break!</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<style>
.letter-spacing-1 { letter-spacing: 1px; }
</style>
<?php require_once '../includes/footer.php'; ?>
