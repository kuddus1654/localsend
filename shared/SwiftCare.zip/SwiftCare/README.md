# 🚑 SwiftCare – Ambulance Booking System

SwiftCare is a full dynamic web-based ambulance booking platform that allows users to book ambulances in real-time, manage pathology services, connect with hospitals, and (future-ready) track ambulances live.

---

## 🌐 Live Modules

### 👤 User Panel

* User registration & login (with robust error handling)
* Secure Password Visibility Toggles
* **New UI:** Premium Glassmorphism Interface
* Book ambulance (Emergency / Scheduled)
* Choose ambulance type
* Fare estimation
* Booking history with status tracking
* **New:** Automated Invoice PDF Generation
* **New:** Direct UPI Payment Gateway via QR Code
* Profile management
* Pathology test booking
* Prescription upload
* Report download

### 🚑 Driver Panel

* Secure login
* **New UI:** Premium Glassmorphism Interface
* Online / Offline availability toggle
* Accept / Reject booking requests
* View assigned rides & Ongoing Trips
* Booking history
* Earnings overview

### 🛠 Admin Panel

* Dashboard with analytics
* **New:** Advanced User Management (Block/Unblock, Auto-Refresh)
* **New:** Payment Verification System (Verify/Reject User Payments)
* **New:** Global Settings Panel (Configure Receiver UPI ID)
* Manage drivers
* Manage ambulance types
* Set pricing (base fare & per km)
* Manage hospitals
* Manage pathology tests
* Booking control & manual driver assignment
* CMS for website content
* Robust Foreign Key relationship handling

---

## 🧪 Pathology Module

* Book lab tests from home
* Pathological History Tracking & Automated Payments
* Home sample collection
* Lab partner management
* Dynamic test pricing

---

## 🏥 Hospital Module

* Add & manage hospitals
* Emergency availability status
* Hospital listing for users

---

## 🚀 Upcoming Features

* 📍 Live ambulance tracking
* 🛏 Hospital bed availability
* 🔔 Real-time notifications
* 📱 Mobile app version

---

## 💻 Technology Stack

### Frontend

* HTML5
* CSS3
* Bootstrap
* JavaScript

### Backend

* PHP (Core PHP)

### Database

* MySQL

### Local Server

* XAMPP / LAMP / WAMP

---

## 📂 Project Structure

```
SwiftCare/
│── admin/
│── user/
│── driver/
│── assets/
│── includes/
│── config/
│── database/
│── index.php
```

---

## ⚙️ Installation Guide

### 1️⃣ Clone the repository

```bash
git clone https://github.com/your-username/swiftcare.git
```

### 2️⃣ Move project to server directory

For XAMPP:

```
C:/xampp/htdocs/
```

### 3️⃣ Import Database

* Open phpMyAdmin
* Create database: `swiftcare`
* Import `swiftcare.sql`

### 4️⃣ Configure Database

Edit:

```
config/db.php
```

```php
$conn = mysqli_connect("localhost","root","","swiftcare");
```

### 5️⃣ Run Project

Open in browser:

```
http://localhost/swiftcare
```

---

## 🔐 Default Login Credentials

### Admin

Email: [admin@swiftcare.com](mailto:admin@swiftcare.com)
Password: 123456

### Driver

Email: [driver@swiftcare.com](mailto:driver@swiftcare.com)
Password: 123456

### User

Email: [user@swiftcare.com](mailto:user@swiftcare.com)
Password: 123456

---

## 💰 Fare Calculation Logic

* Base Fare
* Per KM Charge
* Emergency Charge (optional)
* Waiting Charge (optional)

---

## 🔄 Booking Status Flow

```
Pending → Assigned → On the Way → Reached → Completed
```

---

## 🎨 UI Theme

* Red → Emergency & alerts
* Blue → Trust & medical
* White → Clean healthcare layout

---

## 🤝 Contribution

Pull requests are welcome. For major changes, please open an issue first.

---

## 📞 Support

For support & business inquiries:

📧 [support@swiftcare.com](mailto:support@swiftcare.com)
📱 Emergency: +91-XXXXXXXXXX

---

## 📜 License

This project is licensed under the MIT License.

---

## ❤️ Vision

SwiftCare aims to make emergency medical transport fast, reliable, and accessible with one-click ambulance booking.

by aks0dev
