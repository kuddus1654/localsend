<?php
include 'includes/header.php';
include '../config/db.php';

// Handle Add Test
if (isset($_POST['add_test'])) {
    $test_name = $_POST['test_name'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    $conn->query("INSERT INTO pathology_tests (test_name, description, price) VALUES ('$test_name', '$description', '$price')");
    echo "<script>alert('Test Added'); window.location='pathology.php';</script>";
}

// Handle Update Test
if (isset($_POST['update_test'])) {
    $id = $_POST['id'];
    $test_name = $_POST['test_name'];
    $description = $_POST['description'];
    $price = $_POST['price'];

    $conn->query("UPDATE pathology_tests SET test_name='$test_name', description='$description', price='$price' WHERE id=$id");
    echo "<script>alert('Test Updated'); window.location='pathology.php';</script>";
}

// Handle Delete Test
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM pathology_tests WHERE id=$id");
    echo "<script>alert('Test Deleted'); window.location='pathology.php';</script>";
}

// Handle Edit Fetch
$edit_row = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $edit_row = $conn->query("SELECT * FROM pathology_tests WHERE id=$id")->fetch_assoc();
}
?>

<div class="container-fluid">
    <h2 class="mb-4">Manage Pathology Tests</h2>

    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header"><?php echo $edit_row ? 'Edit Test' : 'Add New Test'; ?></div>
                <div class="card-body">
                    <form method="POST">
                        <?php if ($edit_row): ?>
                            <input type="hidden" name="id" value="<?php echo $edit_row['id']; ?>">
                        <?php endif; ?>

                        <div class="mb-3">
                            <label>Test Name</label>
                            <input type="text" name="test_name" class="form-control"
                                value="<?php echo $edit_row['test_name'] ?? ''; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label>Description</label>
                            <textarea name="description" class="form-control"
                                required><?php echo $edit_row['description'] ?? ''; ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label>Price</label>
                            <input type="number" step="0.01" name="price" class="form-control"
                                value="<?php echo $edit_row['price'] ?? ''; ?>" required>
                        </div>

                        <?php if ($edit_row): ?>
                            <button type="submit" name="update_test" class="btn btn-warning w-100">Update Test</button>
                            <a href="pathology.php" class="btn btn-secondary w-100 mt-2">Cancel</a>
                        <?php else: ?>
                            <button type="submit" name="add_test" class="btn btn-primary w-100">Add Test</button>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Test List</div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Test Name</th>
                                <th>Description</th>
                                <th>Price</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $result = $conn->query("SELECT * FROM pathology_tests");
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>
                                        <td>{$row['id']}</td>
                                        <td>{$row['test_name']}</td>
                                        <td>{$row['description']}</td>
                                        <td>{$row['price']}</td>
                                        <td>
                                            <a href='pathology.php?edit={$row['id']}' class='btn btn-warning btn-sm'>Edit</a>
                                            <a href='pathology.php?delete={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                                        </td>
                                      </tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>