<?php
include 'includes/header.php';
include '../config/db.php';

// Update Status
if (isset($_POST['update_status'])) {
    $booking_id = $_POST['booking_id'];
    $status = $_POST['status'];

    $stmt = $conn->prepare("UPDATE pathology_bookings SET status=? WHERE id=?");
    $stmt->bind_param("si", $status, $booking_id);

    if ($stmt->execute()) {
        echo "<script>alert('Status Updated Successfully'); window.location='pathology_bookings.php';</script>";
    } else {
        echo "<script>alert('Error updating status');</script>";
    }
}

// Delete Logic
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM pathology_bookings WHERE id=$id");
    echo "<script>alert('Booking Deleted'); window.location='pathology_bookings.php';</script>";
    exit();
}

// Payment Verification Logic
if (isset($_POST['verify_payment'])) {
    $id = intval($_POST['booking_id']);
    $conn->query("UPDATE pathology_bookings SET payment_status='paid' WHERE id=$id");
    echo "<script>alert('Payment Verified Successfully'); window.location='pathology_bookings.php';</script>";
    exit();
}
if (isset($_POST['reject_payment'])) {
    $id = intval($_POST['booking_id']);
    $conn->query("UPDATE pathology_bookings SET payment_status='failed' WHERE id=$id");
    echo "<script>alert('Payment Rejected'); window.location='pathology_bookings.php';</script>";
    exit();
}
?>

<div class="container-fluid">
    <h2 class="mb-4">Manage Pathology Bookings</h2>
    <div class="card">
        <div class="card-body">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>User</th>
                        <th>Test Name</th>
                        <th>Address</th>
                        <th>Status</th>
                        <th>Payment</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $query = "SELECT pb.*, u.name as user_name, pt.test_name 
                              FROM pathology_bookings pb 
                              LEFT JOIN users u ON pb.user_id = u.id 
                              LEFT JOIN pathology_tests pt ON pb.test_id = pt.id 
                              ORDER BY pb.booking_date DESC";
                    $result = $conn->query($query);

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $status_badge = match ($row['status']) {
                                'pending' => 'bg-warning',
                                'collected' => 'bg-info',
                                'completed' => 'bg-success',
                                'cancelled' => 'bg-danger',
                                default => 'bg-secondary'
                            };

                            $payment_badge = match ($row['payment_status']) {
                                'paid' => "<span class='badge bg-success'>Paid</span>",
                                'verifying' => "<span class='badge bg-warning text-dark'><i class='fa-solid fa-clock'></i> Verifying</span><br><div class='mt-1'><form method='POST' style='display:inline;'><input type='hidden' name='booking_id' value='{$row['id']}'><button type='submit' name='verify_payment' class='btn btn-sm btn-success py-0 px-1' title='Verify Paid'><i class='fa-solid fa-check'></i></button></form> <form method='POST' style='display:inline;'><input type='hidden' name='booking_id' value='{$row['id']}'><button type='submit' name='reject_payment' class='btn btn-sm btn-danger py-0 px-1' title='Reject/Failed'><i class='fa-solid fa-x'></i></button></form></div>",
                                'failed' => "<span class='badge bg-danger'>Failed</span>",
                                default => "<span class='badge bg-secondary'>Pending</span>"
                            };

                            echo "<tr>
                                    <td>#{$row['id']}</td>
                                    <td>{$row['user_name']}</td>
                                    <td>{$row['test_name']}</td>
                                    <td>{$row['address']}</td>
                                    <td><span class='badge $status_badge'>" . ucfirst($row['status']) . "</span></td>
                                    <td>{$payment_badge}</td>
                                    <td>{$row['booking_date']}</td>
                                    <td>
                                        <button class='btn btn-primary btn-sm' data-bs-toggle='modal' data-bs-target='#statusModal{$row['id']}'>Update Status</button>
                                    </td>
                                  </tr>";

                            // Status Modal
                            echo "
                            <div class='modal fade' id='statusModal{$row['id']}' tabindex='-1'>
                                <div class='modal-dialog'>
                                    <div class='modal-content'>
                                        <div class='modal-header'>
                                            <h5 class='modal-title'>Update Status for Booking #{$row['id']}</h5>
                                            <button type='button' class='btn-close' data-bs-dismiss='modal'></button>
                                        </div>
                                        <form method='POST'>
                                            <div class='modal-body'>
                                                <input type='hidden' name='booking_id' value='{$row['id']}'>
                                                <label>Select Status</label>
                                                <select name='status' class='form-control' required>
                                                    <option value='pending' " . ($row['status'] == 'pending' ? 'selected' : '') . ">Pending</option>
                                                    <option value='collected' " . ($row['status'] == 'collected' ? 'selected' : '') . ">Sample Collected</option>
                                                    <option value='completed' " . ($row['status'] == 'completed' ? 'selected' : '') . ">Completed</option>
                                                </select>
                                            </div>
                                            <div class='modal-footer'>
                                                <button type='submit' name='update_status' class='btn btn-primary'>Update</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>";
                        }
                    } else {
                        echo "<tr><td colspan='7' class='text-center'>No bookings found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>