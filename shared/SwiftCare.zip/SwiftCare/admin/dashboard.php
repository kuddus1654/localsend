<?php
include 'includes/header.php';
include '../config/db.php';

// Fetch Quick Stats
$total_users = $conn->query("SELECT COUNT(*) FROM users WHERE role='user'")->fetch_row()[0];
$total_drivers = $conn->query("SELECT COUNT(*) FROM drivers")->fetch_row()[0];
$total_bookings = $conn->query("SELECT COUNT(*) FROM bookings")->fetch_row()[0];
$pending_bookings = $conn->query("SELECT COUNT(*) FROM bookings WHERE status='pending'")->fetch_row()[0];
?>

<div class="container-fluid py-2">
    <div class="row mb-5">
        <div class="col-md-12">
            <h2 class="fw-bold mb-1">System Overview</h2>
            <p class="text-muted">Monitor and manage all SwiftCare platform activities.</p>
        </div>
    </div>

    <div class="row g-4 mb-5">
        <div class="col-md-3">
            <div class="card glass-card hover-elevate border-0 bg-gradient-primary h-100">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-white-50 text-uppercase fw-bold mb-2">Total Users</h6>
                        <h2 class="display-5 fw-bold mb-0 text-white"><?php echo $total_users; ?></h2>
                    </div>
                    <div class="bg-white bg-opacity-25 rounded-circle p-3">
                        <i class="fa-solid fa-users fa-2x text-white"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card glass-card hover-elevate border-0 bg-gradient-secondary h-100">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-white-50 text-uppercase fw-bold mb-2">Total Drivers</h6>
                        <h2 class="display-5 fw-bold mb-0 text-white"><?php echo $total_drivers; ?></h2>
                    </div>
                    <div class="bg-white bg-opacity-25 rounded-circle p-3">
                        <i class="fa-solid fa-user-doctor fa-2x text-white"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card glass-card hover-elevate border-0 bg-gradient-dark h-100">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-white-50 text-uppercase fw-bold mb-2">Total Bookings</h6>
                        <h2 class="display-5 fw-bold mb-0 text-white"><?php echo $total_bookings; ?></h2>
                    </div>
                    <div class="bg-white bg-opacity-25 rounded-circle p-3">
                        <i class="fa-solid fa-calendar-check fa-2x text-white"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card glass-card hover-elevate border-0 bg-gradient-danger h-100">
                <div class="card-body d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-white-50 text-uppercase fw-bold mb-2">Pending Bookings</h6>
                        <h2 class="display-5 fw-bold mb-0 text-white"><?php echo $pending_bookings; ?></h2>
                    </div>
                    <div class="bg-white bg-opacity-25 rounded-circle p-3">
                        <i class="fa-solid fa-clock fa-2x text-white"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card glass-card border-0">
                <div class="card-header bg-transparent border-0 pb-0 pt-3">
                    <h4 class="fw-bold mb-0">Recent Bookings</h4>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th class="py-3">ID</th>
                                    <th class="py-3">User</th>
                                    <th class="py-3">Type</th>
                                    <th class="py-3">Status</th>
                                    <th class="py-3">Date</th>
                                </tr>
                            </thead>
                            <tbody class="border-top-0">
                                <?php
                                $recent_bookings = $conn->query("SELECT b.id, u.name, b.booking_type, b.status, b.booking_date 
                                                             FROM bookings b 
                                                             JOIN users u ON b.user_id = u.id 
                                                             ORDER BY b.booking_date DESC LIMIT 5");
                                if ($recent_bookings->num_rows > 0) {
                                    while ($row = $recent_bookings->fetch_assoc()) {
                                        $status_badge = '';
                                        switch (strtolower($row['status'])) {
                                            case 'pending':
                                                $status_badge = 'bg-warning text-dark';
                                                break;
                                            case 'assigned':
                                                $status_badge = 'bg-info bg-opacity-75 text-white';
                                                break;
                                            case 'completed':
                                                $status_badge = 'bg-success bg-opacity-75 text-white';
                                                break;
                                            default:
                                                $status_badge = 'bg-secondary';
                                        }
                                        echo "<tr>
                                            <td class='fw-bold'>#{$row['id']}</td>
                                            <td><div class='d-flex align-items-center'><div class='bg-light rounded-circle p-2 me-3'><i class='fa-solid fa-user text-primary'></i></div>{$row['name']}</div></td>
                                            <td><span class='badge bg-light text-dark border'> <i class='fa-solid " . ($row['booking_type'] == 'ambulance' ? 'fa-truck-medical text-danger' : 'fa-flask text-primary') . " me-1'></i>" . ucfirst($row['booking_type']) . "</span></td>
                                            <td><span class='badge {$status_badge} p-2'>" . ucfirst($row['status']) . "</span></td>
                                            <td class='text-muted'><i class='fa-regular fa-clock me-1'></i>{$row['booking_date']}</td>
                                          </tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='5' class='text-center py-4 text-muted'>No recent bookings found.</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>