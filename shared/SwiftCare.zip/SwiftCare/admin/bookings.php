<?php
include 'includes/header.php';
include '../config/db.php';

// Delete Booking Logic
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    // Clear dependent earnings first
    $conn->query("DELETE FROM driver_earnings WHERE booking_id=$id");
    $conn->query("DELETE FROM bookings WHERE id=$id");
    echo "<script>alert('Booking Deleted'); window.location='bookings.php';</script>";
    exit();
}

// Payment Verification Logic
if (isset($_POST['verify_payment'])) {
    $id = intval($_POST['booking_id']);
    $conn->query("UPDATE bookings SET payment_status='paid' WHERE id=$id");
    echo "<script>alert('Payment Verified Globally'); window.location='bookings.php';</script>";
    exit();
}
if (isset($_POST['reject_payment'])) {
    $id = intval($_POST['booking_id']);
    $conn->query("UPDATE bookings SET payment_status='failed' WHERE id=$id");
    echo "<script>alert('Payment Rejected'); window.location='bookings.php';</script>";
    exit();
}

// Assign Driver
if (isset($_POST['assign_driver'])) {
    $booking_id = $_POST['booking_id'];
    $driver_id = $_POST['driver_id'];

    $conn->query("UPDATE bookings SET driver_id='$driver_id', status='assigned' WHERE id='$booking_id'");
    echo "<script>alert('Driver Assigned Successfully'); window.location='bookings.php';</script>";
}
?>

<div class="container-fluid">
    <h2 class="mb-4">Manage Bookings</h2>
    <div class="card">
        <div class="card-body">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>User</th>
                        <th>Pickup</th>
                        <th>Drop</th>
                        <th>Status</th>
                        <th>Payment</th>
                        <th>Driver</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $query = "SELECT b.*, u.name as user_name, d.name as driver_name 
                              FROM bookings b 
                              LEFT JOIN users u ON b.user_id = u.id 
                              LEFT JOIN drivers d ON b.driver_id = d.id 
                              ORDER BY b.booking_date DESC";
                    $result = $conn->query($query);

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $status_badge = match ($row['status']) {
                                'pending' => 'bg-warning',
                                'assigned' => 'bg-info',
                                'completed' => 'bg-success',
                                'cancelled' => 'bg-danger',
                                default => 'bg-secondary'
                            };

                            $payment_badge = match ($row['payment_status']) {
                                'paid' => "<span class='badge bg-success'>Paid</span>",
                                'verifying' => "<span class='badge bg-warning text-dark'><i class='fa-solid fa-clock'></i> Verifying</span><br><div class='mt-1'><form method='POST' style='display:inline;'><input type='hidden' name='booking_id' value='{$row['id']}'><button type='submit' name='verify_payment' class='btn btn-sm btn-success py-0 px-1' title='Verify Paid'><i class='fa-solid fa-check'></i></button></form> <form method='POST' style='display:inline;'><input type='hidden' name='booking_id' value='{$row['id']}'><button type='submit' name='reject_payment' class='btn btn-sm btn-danger py-0 px-1' title='Reject/Failed'><i class='fa-solid fa-x'></i></button></form></div>",
                                'failed' => "<span class='badge bg-danger'>Failed</span>",
                                default => "<span class='badge bg-secondary'>Pending</span>"
                            };

                            echo "<tr>
                                    <td>#{$row['id']}</td>
                                    <td>{$row['user_name']}</td>
                                    <td>{$row['pickup_location']}</td>
                                    <td>{$row['drop_location']}</td>
                                    <td><span class='badge $status_badge'>" . ucfirst($row['status']) . "</span></td>
                                    <td>{$payment_badge}</td>
                                    <td>" . ($row['driver_name'] ?? 'Not Assigned') . "</td>
                                    <td>";

                            if ($row['status'] == 'pending') {
                                echo "<button class='btn btn-primary btn-sm' data-bs-toggle='modal' data-bs-target='#assignModal{$row['id']}'>Assign Driver</button>";
                            } else {
                                echo "<span class='text-muted'>No Action</span>";
                            }

                            echo "</td>
                                  </tr>";

                            // Assign Modal
                            if ($row['status'] == 'pending') {
                                $drivers = $conn->query("SELECT * FROM drivers WHERE status='online'"); // Only online drivers
                                echo "
                                <div class='modal fade' id='assignModal{$row['id']}' tabindex='-1'>
                                    <div class='modal-dialog'>
                                        <div class='modal-content'>
                                            <div class='modal-header'>
                                                <h5 class='modal-title'>Assign Driver for Booking #{$row['id']}</h5>
                                                <button type='button' class='btn-close' data-bs-dismiss='modal'></button>
                                            </div>
                                            <form method='POST'>
                                                <div class='modal-body'>
                                                    <input type='hidden' name='booking_id' value='{$row['id']}'>
                                                    <label>Select Driver</label>
                                                    <select name='driver_id' class='form-control' required>
                                                        <option value=''>Choose Driver</option>";
                                if ($drivers->num_rows > 0) {
                                    while ($d = $drivers->fetch_assoc()) {
                                        echo "<option value='{$d['id']}'>{$d['name']} (Online)</option>";
                                    }
                                } else {
                                    echo "<option value='' disabled>No Online Drivers</option>";
                                }
                                echo "                  </select>
                                                </div>
                                                <div class='modal-footer'>
                                                    <button type='submit' name='assign_driver' class='btn btn-primary'>Assign</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>";
                            }
                        }
                    } else {
                        echo "<tr><td colspan='7' class='text-center'>No bookings found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>