<?php
include 'includes/header.php';
include '../config/db.php';

// Handle Add Hospital
if (isset($_POST['add_hospital'])) {
    $name = $_POST['name'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];

    $conn->query("INSERT INTO hospitals (name, address, phone) VALUES ('$name', '$address', '$phone')");
    echo "<script>alert('Hospital Added'); window.location='hospitals.php';</script>";
}

// Handle Update Hospital
if (isset($_POST['update_hospital'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];

    $conn->query("UPDATE hospitals SET name='$name', address='$address', phone='$phone' WHERE id=$id");
    echo "<script>alert('Hospital Updated'); window.location='hospitals.php';</script>";
}

// Handle Delete Hospital
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM hospitals WHERE id=$id");
    echo "<script>alert('Hospital Deleted'); window.location='hospitals.php';</script>";
}

// Handle Edit Fetch
$edit_row = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $edit_row = $conn->query("SELECT * FROM hospitals WHERE id=$id")->fetch_assoc();
}
?>

<div class="container-fluid">
    <h2 class="mb-4">Manage Hospitals</h2>

    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header"><?php echo $edit_row ? 'Edit Hospital' : 'Add Hospital'; ?></div>
                <div class="card-body">
                    <form method="POST">
                        <?php if ($edit_row): ?>
                            <input type="hidden" name="id" value="<?php echo $edit_row['id']; ?>">
                        <?php endif; ?>

                        <div class="mb-3">
                            <label>Hospital Name</label>
                            <input type="text" name="name" class="form-control"
                                value="<?php echo $edit_row['name'] ?? ''; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label>Address</label>
                            <textarea name="address" class="form-control"
                                required><?php echo $edit_row['address'] ?? ''; ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label>Phone</label>
                            <input type="text" name="phone" class="form-control"
                                value="<?php echo $edit_row['phone'] ?? ''; ?>" required>
                        </div>

                        <?php if ($edit_row): ?>
                            <button type="submit" name="update_hospital" class="btn btn-warning w-100">Update
                                Hospital</button>
                            <a href="hospitals.php" class="btn btn-secondary w-100 mt-2">Cancel</a>
                        <?php else: ?>
                            <button type="submit" name="add_hospital" class="btn btn-primary w-100">Add Hospital</button>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Hospital List</div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Address</th>
                                <th>Phone</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $result = $conn->query("SELECT * FROM hospitals");
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>
                                        <td>{$row['id']}</td>
                                        <td>{$row['name']}</td>
                                        <td>{$row['address']}</td>
                                        <td>{$row['phone']}</td>
                                        <td><span class='badge bg-success'>{$row['emergency_status']}</span></td>
                                        <td>
                                            <a href='hospitals.php?edit={$row['id']}' class='btn btn-warning btn-sm'>Edit</a>
                                            <a href='hospitals.php?delete={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                                        </td>
                                      </tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>