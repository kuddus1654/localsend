<?php
include 'includes/header.php';
include '../config/db.php';

// Handle Add Driver
if (isset($_POST['add_driver'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = md5($_POST['password']);

    // Check if email exists
    $check = $conn->query("SELECT * FROM drivers WHERE email='$email'");
    if ($check->num_rows > 0) {
        $error = "Email already registered!";
    } else {
        $query = "INSERT INTO drivers (name, email, phone, password, status) VALUES ('$name', '$email', '$phone', '$password', 'offline')";
        if ($conn->query($query)) {
            echo "<script>alert('Driver Added Successfully'); window.location='drivers.php';</script>";
        } else {
            $error = "Error: " . $conn->error;
        }
    }
}

// Handle Actions
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);

    // Delete dependent records and clear foreign keys
    $conn->query("DELETE FROM driver_earnings WHERE driver_id=$id");
    $conn->query("UPDATE bookings SET driver_id=NULL WHERE driver_id=$id");

    // Delete driver
    $conn->query("DELETE FROM drivers WHERE id=$id");

    echo "<script>alert('Driver Deleted Successfully'); window.location='drivers.php';</script>";
    exit();
}

if (isset($_GET['approve'])) {
    $id = intval($_GET['approve']);
    $conn->query("UPDATE drivers SET status='online' WHERE id=$id"); // Simplified approval logic
    echo "<script>alert('Driver Approved'); window.location='drivers.php';</script>";
    exit();
}
?>

<div class="container-fluid">
    <h2 class="mb-4">Manage Drivers</h2>

    <div class="row">
        <!-- Add Driver Form -->
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">Add New Driver</div>
                <div class="card-body">
                    <?php if (isset($error)) {
                        echo "<div class='alert alert-danger'>$error</div>";
                    } ?>
                    <form method="POST">
                        <div class="mb-3">
                            <label>Name</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label>Email</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label>Phone</label>
                            <input type="text" name="phone" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label>Password</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <button type="submit" name="add_driver" class="btn btn-primary w-100">Add Driver</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Driver List -->
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Driver List</div>
                <div class="card-body">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $result = $conn->query("SELECT * FROM drivers");
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $status_badge = $row['status'] == 'online' ? 'bg-success' : 'bg-secondary';
                                    echo "<tr>
                                            <td>{$row['id']}</td>
                                            <td>{$row['name']}</td>
                                            <td>{$row['email']}</td>
                                            <td>{$row['phone']}</td>
                                            <td><span class='badge $status_badge'>" . ucfirst($row['status']) . "</span></td>
                                            <td>
                                                <a href='drivers.php?approve={$row['id']}' class='btn btn-success btn-sm'>Approve</a>
                                                <a href='drivers.php?delete={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                                            </td>
                                          </tr>";
                                }
                            } else {
                                echo "<tr><td colspan='6' class='text-center'>No drivers found</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>