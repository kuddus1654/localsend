<?php
include 'includes/header.php';
include '../config/db.php';

// Fetch current UPI ID
$upi_id = "admin@upi"; // Default
$res = $conn->query("SELECT content FROM cms WHERE section='upi_id'");
if ($res && $res->num_rows > 0) {
    $row = $res->fetch_assoc();
    $upi_id = $row['content'];
}

// Handle Update
$success_msg = "";
$error_msg = "";
if (isset($_POST['update_upi'])) {
    $new_upi = trim($_POST['upi_id']);

    // Simple validation
    if (!empty($new_upi) && strpos($new_upi, '@') !== false) {
        $stmt = $conn->prepare("UPDATE cms SET content=? WHERE section='upi_id'");
        $stmt->bind_param("s", $new_upi);

        if ($stmt->execute()) {
            $success_msg = "UPI ID updated successfully.";
            $upi_id = htmlspecialchars($new_upi); // Update view
        } else {
            $error_msg = "Database error. Failed to update.";
        }
    } else {
        $error_msg = "Invalid UPI ID Format. It must contain '@'";
    }
}
?>

<div class="container-fluid py-4">
    <div class="row mb-4">
        <div class="col-md-12">
            <h2 class="fw-bold mb-2">Platform Settings</h2>
            <p class="text-muted fs-5">Configure global platform variables like payment gateways.</p>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="card glass-card hover-elevate border-0"
                style="border-top: 4px solid var(--primary-color) !important;">
                <div class="card-header bg-transparent border-0 pt-4 pb-0">
                    <h5 class="fw-bold mb-0"><i class="fa-solid fa-money-bill-transfer text-primary me-2"></i> Payment
                        Gateway Setup</h5>
                </div>
                <div class="card-body p-4">
                    <?php if (!empty($success_msg)): ?>
                        <div class="alert alert-success alert-dismissible fade show">
                            <i class="fa-solid fa-check-circle me-2"></i>
                            <?= $success_msg ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($error_msg)): ?>
                        <div class="alert alert-danger alert-dismissible fade show">
                            <i class="fa-solid fa-triangle-exclamation me-2"></i>
                            <?= $error_msg ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <form method="POST">
                        <div class="mb-4">
                            <label class="form-label fw-bold text-muted">Admin Receiver UPI ID</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light border-end-0"><i
                                        class="fa-brands fa-google-pay text-primary fs-5"></i></span>
                                <input type="text" name="upi_id" class="form-control border-start-0"
                                    value="<?= htmlspecialchars($upi_id) ?>" placeholder="e.g., yourname@okicici"
                                    required>
                            </div>
                            <small class="text-muted mt-2 d-block">All patient bookings and pathology tests payments
                                will be directed to this UPI ID via QR Code.</small>
                        </div>
                        <button type="submit" name="update_upi" class="btn btn-primary px-4 rounded-pill">Save
                            Settings</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>