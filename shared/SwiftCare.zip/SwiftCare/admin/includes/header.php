<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - SwiftCare</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .sidebar {
            min-height: 100vh;
            background: linear-gradient(180deg, var(--dark-color) 0%, #1a1b26 100%);
            color: white;
            padding-top: 20px;
            box-shadow: 4px 0 15px rgba(0, 0, 0, 0.1);
        }

        .sidebar a {
            color: rgba(255, 255, 255, 0.7);
            padding: 12px 20px;
            display: block;
            text-decoration: none;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .sidebar a:hover,
        .sidebar a.active {
            color: white;
            background: rgba(255, 255, 255, 0.1);
            border-left: 4px solid var(--danger-color);
        }

        .sidebar a i {
            width: 25px;
        }

        .content {
            padding: 30px;
            background-color: var(--bg-color);
            min-height: 100vh;
        }
    </style>
</head>

<body>
    <div class="d-flex">
        <div class="sidebar col-md-2">
            <h3 class="text-center fw-bold mb-4 mt-2" style="color: var(--danger-color);"><i
                    class="fa-solid fa-shield"></i> Admin</h3>
            <a href="dashboard.php"><i class="fa-solid fa-gauge"></i> Dashboard</a>
            <a href="bookings.php"><i class="fa-solid fa-calendar-check"></i> Bookings</a>
            <a href="users.php"><i class="fa-solid fa-users"></i> Users</a>
            <a href="drivers.php"><i class="fa-solid fa-user-doctor"></i> Drivers</a>
            <a href="ambulances.php"><i class="fa-solid fa-truck-medical"></i> Ambulances</a>
            <a href="hospitals.php"><i class="fa-solid fa-hospital"></i> Hospitals</a>
            <a href="pathology.php"><i class="fa-solid fa-flask"></i> Pathology Tests</a>
            <a href="pathology_bookings.php"><i class="fa-solid fa-file-medical"></i> Pathology Bookings</a>
            <a href="settings.php"><i class="fa-solid fa-gear"></i> Settings</a>
            <a href="logout.php" class="text-danger mt-4"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
        </div>
        <div class="content col-md-10">