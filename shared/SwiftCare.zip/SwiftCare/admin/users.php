<?php
include 'includes/header.php';
include '../config/db.php';

// Handle Delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);

    // Delete dependent records first to avoid foreign key constraint errors
    $conn->query("DELETE FROM driver_earnings WHERE booking_id IN (SELECT id FROM bookings WHERE user_id=$id)");
    $conn->query("DELETE FROM bookings WHERE user_id=$id");
    $conn->query("DELETE FROM pathology_bookings WHERE user_id=$id");

    // Finally, delete the user
    $conn->query("DELETE FROM users WHERE id=$id");

    echo "<script>alert('User Deleted Successfully'); window.location='users.php';</script>";
}

// Handle Block/Unblock
if (isset($_GET['block'])) {
    $id = intval($_GET['block']);
    $conn->query("UPDATE users SET status='blocked' WHERE id=$id");
    header("Location: users.php");
    exit();
}
if (isset($_GET['unblock'])) {
    $id = intval($_GET['unblock']);
    $conn->query("UPDATE users SET status='active' WHERE id=$id");
    header("Location: users.php");
    exit();
}
?>

<!-- Auto Refresh Meta Tag -->
<meta http-equiv="refresh" content="30">

<div class="container-fluid">
    <h2 class="mb-4">Manage Users</h2>
    <div class="card">
        <div class="card-body">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Joined</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $result = $conn->query("SELECT * FROM users WHERE role='user'");
                    while ($row = $result->fetch_assoc()) {
                        $status_badge = $row['status'] == 'active' ? "<span class='badge bg-success'>Active</span>" : "<span class='badge bg-danger'>Blocked</span>";
                        $block_btn = $row['status'] == 'active' ? "<a href='users.php?block={$row['id']}' class='btn btn-warning btn-sm' onclick='return confirm(\"Block this user?\")'>Block</a>" : "<a href='users.php?unblock={$row['id']}' class='btn btn-success btn-sm'>Unblock</a>";

                        echo "<tr>
                                <td>{$row['id']}</td>
                                <td>{$row['name']}</td>
                                <td>{$row['email']}</td>
                                <td>{$row['phone']}</td>
                                <td><span class='badge bg-primary'>{$row['role']}</span></td>
                                <td>{$status_badge}</td>
                                <td>{$row['created_at']}</td>
                                <td>
                                    {$block_btn}
                                    <a href='users.php?delete={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                                </td>
                              </tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>