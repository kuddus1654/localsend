<?php
include 'includes/header.php';
include '../config/db.php';

// Handle Add Ambulance
if (isset($_POST['add_ambulance'])) {
    $type = $_POST['type'];
    $base_fare = $_POST['base_fare'];
    $price_per_km = $_POST['price_per_km'];
    $equipment = $_POST['equipment'];

    $conn->query("INSERT INTO ambulances (type, base_fare, price_per_km, equipment) VALUES ('$type', '$base_fare', '$price_per_km', '$equipment')");
    echo "<script>alert('Ambulance Type Added'); window.location='ambulances.php';</script>";
}

// Handle Update Ambulance
if (isset($_POST['update_ambulance'])) {
    $id = $_POST['id'];
    $type = $_POST['type'];
    $base_fare = $_POST['base_fare'];
    $price_per_km = $_POST['price_per_km'];
    $equipment = $_POST['equipment'];

    $conn->query("UPDATE ambulances SET type='$type', base_fare='$base_fare', price_per_km='$price_per_km', equipment='$equipment' WHERE id=$id");
    echo "<script>alert('Ambulance Type Updated'); window.location='ambulances.php';</script>";
}

// Handle Delete Ambulance
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM ambulances WHERE id=$id");
    echo "<script>alert('Ambulance Type Deleted'); window.location='ambulances.php';</script>";
}

// Handle Edit Fetch
$edit_row = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $edit_row = $conn->query("SELECT * FROM ambulances WHERE id=$id")->fetch_assoc();
}
?>

<div class="container-fluid">
    <h2 class="mb-4">Manage Ambulance Types</h2>

    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header"><?php echo $edit_row ? 'Edit Ambulance Type' : 'Add New Type'; ?></div>
                <div class="card-body">
                    <form method="POST">
                        <?php if ($edit_row): ?>
                            <input type="hidden" name="id" value="<?php echo $edit_row['id']; ?>">
                        <?php endif; ?>

                        <div class="mb-3">
                            <label>Type Name</label>
                            <input type="text" name="type" class="form-control"
                                value="<?php echo $edit_row['type'] ?? ''; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label>Base Fare</label>
                            <input type="number" step="0.01" name="base_fare" class="form-control"
                                value="<?php echo $edit_row['base_fare'] ?? ''; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label>Price Per KM</label>
                            <input type="number" step="0.01" name="price_per_km" class="form-control"
                                value="<?php echo $edit_row['price_per_km'] ?? ''; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label>Equipment</label>
                            <textarea name="equipment"
                                class="form-control"><?php echo $edit_row['equipment'] ?? ''; ?></textarea>
                        </div>

                        <?php if ($edit_row): ?>
                            <button type="submit" name="update_ambulance" class="btn btn-warning w-100">Update
                                Ambulance</button>
                            <a href="ambulances.php" class="btn btn-secondary w-100 mt-2">Cancel</a>
                        <?php else: ?>
                            <button type="submit" name="add_ambulance" class="btn btn-primary w-100">Add Ambulance</button>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card">
                <div class="card-header">All Types</div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Type</th>
                                <th>Base Fare</th>
                                <th>Per KM</th>
                                <th>Equipment</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $result = $conn->query("SELECT * FROM ambulances");
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>
                                        <td>{$row['id']}</td>
                                        <td>{$row['type']}</td>
                                        <td>{$row['base_fare']}</td>
                                        <td>{$row['price_per_km']}</td>
                                        <td>{$row['equipment']}</td>
                                        <td>
                                            <a href='ambulances.php?edit={$row['id']}' class='btn btn-warning btn-sm'>Edit</a>
                                            <a href='ambulances.php?delete={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                                        </td>
                                      </tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>