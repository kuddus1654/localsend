<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SwiftCare - Advanced Healthcare & Ambulance Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .hero-section {
            background: linear-gradient(135deg, rgba(67, 97, 238, 0.9) 0%, rgba(72, 149, 239, 0.9) 100%), url('https://images.unsplash.com/photo-1581056771107-24ca5f033842?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80') center/cover no-repeat;
            color: white;
            padding: 120px 0 80px;
            position: relative;
        }

        .portal-card {
            transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
            border: none;
            border-radius: 16px;
            overflow: hidden;
        }

        .portal-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
        }

        .icon-box {
            width: 80px;
            height: 80px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            margin-bottom: 20px;
        }

        .feature-item {
            padding: 30px;
            border-radius: 16px;
            background: white;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            height: 100%;
            transition: all 0.3s ease;
        }

        .feature-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            border-top: 4px solid var(--primary-color);
        }
    </style>
</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white sticky-top py-3">
        <div class="container">
            <a class="navbar-brand fs-3" href="#">
                <i class="fa-solid fa-truck-medical me-2"></i>SwiftCare
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto text-uppercase fw-bold" style="font-size: 0.9rem;">
                    <li class="nav-item"><a class="nav-link px-3" href="#home">Home</a></li>
                    <li class="nav-item"><a class="nav-link px-3" href="#about">About</a></li>
                    <li class="nav-item"><a class="nav-link px-3" href="#portals">Logins</a></li>
                    <li class="nav-item ms-lg-3"><a class="btn btn-primary rounded-pill px-4"
                            href="user/register.php">Get Started</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section id="home" class="hero-section text-center">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <h1 class="display-3 fw-bold mb-4">Emergency Care, Faster & Smarter</h1>
                    <p class="lead mb-5 opacity-75">SwiftCare bridges the gap between critical patients, on-demand
                        ambulances, and seamless pathology testing through one unified digital platform.</p>
                    <div class="d-flex justify-content-center gap-3">
                        <a href="user/login.php"
                            class="btn btn-light btn-lg px-5 rounded-pill shadow fw-bold text-primary">Book an
                            Ambulance</a>
                        <a href="#portals" class="btn btn-outline-light btn-lg px-5 rounded-pill fw-bold">Select
                            Portal</a>
                    </div>
                </div>
            </div>
        </div>
        <div style="position: absolute; bottom: -2px; left: 0; width: 100%; overflow: hidden; line-height: 0;">
            <svg viewBox="0 0 1200 120" preserveAspectRatio="none" style="width: calc(100% + 1.3px); height: 60px;">
                <path
                    d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V120H0V0C73.2,26.55,145.4,59.2,216.92,76.62,251.32,85.06,286.53,89.5,321.39,56.44Z"
                    fill="#f0f4f8"></path>
            </svg>
        </div>
    </section>

    <!-- Features / About Section -->
    <section id="about" class="py-5 bg-color">
        <div class="container py-5">
            <div class="text-center mb-5">
                <h2 class="fw-bold fs-1 text-dark mb-3">Why Choose SwiftCare?</h2>
                <p class="text-muted fs-5 max-w-75 mx-auto">A modern comprehensive system built to handle medical
                    logistics, bridging gaps between patients, drivers, and administrators via a unified approach.</p>
            </div>

            <div class="row g-4 text-center">
                <div class="col-md-4">
                    <div class="feature-item">
                        <div class="icon-box bg-danger bg-opacity-10 text-danger mb-4">
                            <i class="fa-solid fa-truck-fast fa-2x"></i>
                        </div>
                        <h4 class="fw-bold mb-3">Instant Booking</h4>
                        <p class="text-muted">Request emergency response vehicles immediately directly from your exact
                            geolocation with real-time driver assigning.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-item">
                        <div class="icon-box bg-primary bg-opacity-10 text-primary mb-4">
                            <i class="fa-solid fa-flask fa-2x"></i>
                        </div>
                        <h4 class="fw-bold mb-3">Home Pathology</h4>
                        <p class="text-muted">Avoid hospital queues. Book necessary tests online and have a technician
                            collect samples comfortably from your home address.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-item">
                        <div class="icon-box bg-success bg-opacity-10 text-success mb-4">
                            <i class="fa-solid fa-shield-halved fa-2x"></i>
                        </div>
                        <h4 class="fw-bold mb-3">Administrative Control</h4>
                        <p class="text-muted">An advanced admin tracking dashboard ensuring transparency across
                            ambulance allocation, driver limits, and hospital bed availability.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Portal Access Section -->
    <section id="portals" class="py-5 bg-white">
        <div class="container py-5">
            <div class="text-center mb-5">
                <h2 class="fw-bold fs-1 text-dark mb-3">Access Portals</h2>
                <p class="text-muted fs-5">Log in to the specific area designated for your role.</p>
            </div>

            <div class="row g-4 justify-content-center">
                <!-- User Portal -->
                <div class="col-md-4">
                    <div class="card portal-card bg-light h-100 text-center"
                        style="border-top: 5px solid var(--primary-color);">
                        <div class="card-body p-5">
                            <i class="fa-regular fa-user fa-3x text-primary mb-4"></i>
                            <h3 class="fw-bold mb-3">Patient Portal</h3>
                            <p class="text-muted mb-4 pb-2">Book ambulances, schedule lab tests, and track your ongoing
                                medical logistics securely.</p>
                            <a href="user/login.php" class="btn btn-outline-primary rounded-pill w-100 fw-bold">Login as
                                Patient</a>
                            <div class="mt-3">
                                <small class="text-muted">New here? <a href="user/register.php"
                                        class="text-decoration-none fw-bold">Register</a></small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Driver Portal -->
                <div class="col-md-4">
                    <div class="card portal-card bg-light h-100 text-center"
                        style="border-top: 5px solid var(--dark-color);">
                        <div class="card-body p-5">
                            <i class="fa-solid fa-truck-medical fa-3x text-dark mb-4"></i>
                            <h3 class="fw-bold mb-3">Driver Portal</h3>
                            <p class="text-muted mb-4 pb-2">Accept ride requests, manage your online availability, and
                                route securely to patients.</p>
                            <a href="driver/login.php" class="btn btn-outline-dark rounded-pill w-100 fw-bold">Login as
                                Driver</a>
                        </div>
                    </div>
                </div>

                <!-- Admin Portal -->
                <div class="col-md-4">
                    <div class="card portal-card bg-light h-100 text-center"
                        style="border-top: 5px solid var(--danger-color);">
                        <div class="card-body p-5">
                            <i class="fa-solid fa-shield fa-3x text-danger mb-4"></i>
                            <h3 class="fw-bold mb-3">Admin Portal</h3>
                            <p class="text-muted mb-4 pb-2">Manage users, oversee driver allocations, add hospitals, and
                                monitor platform health.</p>
                            <a href="admin/login.php" class="btn btn-outline-danger rounded-pill w-100 fw-bold">Login as
                                Admin</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-white text-center py-4">
        <div class="container">
            <h4 class="fw-bold mb-3"><i class="fa-solid fa-truck-medical me-2 text-danger"></i>SwiftCare</h4>
            <p class="text-white-50 mb-0">&copy;
                <?php echo date('Y'); ?> SwiftCare. Bridging healthcare gaps. All Rights Reserved.
            </p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>