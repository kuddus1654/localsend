<?php
include 'includes/header.php';
include '../config/db.php';

if (!isset($_GET['id']) || !isset($_GET['type'])) {
    echo "<script>alert('Invalid request'); window.location='history.php';</script>";
    exit();
}

$booking_id = intval($_GET['id']);
$type = $_GET['type'];
$user_id = $_SESSION['user_id'];

// Get UPI ID
$upi_id = "admin@upi";
$cms_res = $conn->query("SELECT content FROM cms WHERE section='upi_id'");
if ($cms_res && $cms_res->num_rows > 0) {
    $upi_id = $cms_res->fetch_assoc()['content'];
}

$amount = 0;
$payment_status = 'pending';
$return_url = 'history.php';

// Fetch details based on type
if ($type === 'ambulance') {
    $stmt = $conn->prepare("SELECT fare, payment_status FROM bookings WHERE id=? AND user_id=?");
    $stmt->bind_param("ii", $booking_id, $user_id);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows > 0) {
        $row = $res->fetch_assoc();
        $amount = $row['fare'];
        $payment_status = $row['payment_status'];
    } else {
        echo "<script>alert('Booking not found'); window.location='history.php';</script>";
        exit();
    }
} elseif ($type === 'pathology') {
    $stmt = $conn->prepare("SELECT pt.price, pb.payment_status FROM pathology_bookings pb JOIN pathology_tests pt ON pb.test_id = pt.id WHERE pb.id=? AND pb.user_id=?");
    $stmt->bind_param("ii", $booking_id, $user_id);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows > 0) {
        $row = $res->fetch_assoc();
        $amount = $row['price'];
        $payment_status = $row['payment_status'];
    } else {
        echo "<script>alert('Booking not found'); window.location='history.php';</script>";
        exit();
    }
} else {
    echo "<script>alert('Invalid booking type'); window.location='history.php';</script>";
    exit();
}

// Handle Payment Simulation
if (isset($_POST['mark_paid'])) {
    if ($type === 'ambulance') {
        $update = $conn->prepare("UPDATE bookings SET payment_status='verifying' WHERE id=?");
    } else {
        $update = $conn->prepare("UPDATE pathology_bookings SET payment_status='verifying' WHERE id=?");
    }
    $update->bind_param("i", $booking_id);
    if ($update->execute()) {
        echo "<script>alert('Payment submitted! Awaiting Admin verification.'); window.location='history.php';</script>";
        exit();
    } else {
        echo "<script>alert('Error updating payment status.');</script>";
    }
}

// Generate QR URI String (upi://pay?pa=UPI_ID&pn=Name&am=Amount&cu=INR)
$upi_link = "upi://pay?pa=" . urlencode($upi_id) . "&pn=SwiftCare&am=" . number_format($amount, 2, '.', '') . "&cu=INR";
$qr_api = "https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=" . urlencode($upi_link);
?>

<div class="container-fluid py-5">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-5">
            <div class="card glass-card hover-elevate border-0 text-center"
                style="border-top: 5px solid var(--primary-color) !important;">
                <div class="card-body p-5">

                    <?php if ($payment_status == 'paid'): ?>
                        <div class="my-4">
                            <i class="fa-solid fa-circle-check text-success" style="font-size: 80px;"></i>
                        </div>
                        <h3 class="fw-bold mb-3">Payment Successful</h3>
                        <p class="text-muted">Your payment of ₹
                            <?= number_format($amount, 2) ?> was completed.
                        </p>
                        <a href="history.php" class="btn btn-outline-primary rounded-pill mt-3 px-4">Back to My Bookings</a>
                    <?php else: ?>
                        <div class="mb-4">
                            <span class="badge bg-primary bg-opacity-10 text-primary px-3 py-2 fs-6 rounded-pill mb-3">
                                <i class="fa-brands fa-google-pay me-1"></i> Secure UPI Gateway
                            </span>
                            <h3 class="fw-bold mb-1">Complete Payment</h3>
                            <p class="text-muted">Scan the QR code below using any UPI App (GPay, PhonePe, Paytm) to confirm
                                your booking.</p>
                        </div>

                        <!-- Amount Display -->
                        <div class="bg-light p-3 rounded-4 mb-4 border shadow-sm">
                            <h5 class="text-muted mb-1 fs-6">Amount to Pay</h5>
                            <h1 class="fw-bold text-dark mb-0">₹
                                <?= number_format($amount, 2) ?>
                            </h1>
                        </div>

                        <!-- QR Code -->
                        <div class="bg-white p-3 rounded-4 shadow-sm border d-inline-block mb-4">
                            <img src="<?= $qr_api ?>" alt="UPI QR Code" class="img-fluid rounded" />
                        </div>

                        <div class="text-start bg-light p-3 rounded-3 mb-4 text-center">
                            <p class="mb-1 text-muted small">Or pay directly to UPI ID:</p>
                            <span class="user-select-all fw-bold fs-5">
                                <?= htmlspecialchars($upi_id) ?>
                            </span>
                        </div>

                        <!-- Payment Actions -->
                        <div class="alert alert-warning text-start" style="font-size: 0.9rem;">
                            <i class="fa-solid fa-circle-info me-2"></i> After scanning and completing the payment on your
                            mobile, click the button below to verify.
                        </div>

                        <form method="POST">
                            <button type="submit" name="mark_paid"
                                class="btn btn-success w-100 rounded-pill py-2 shadow-sm d-flex align-items-center justify-content-center fw-bold">
                                <i class="fa-solid fa-check-double me-2"></i> I have made the payment
                            </button>
                            <a href="history.php" class="btn btn-link text-muted mt-3 text-decoration-none">Pay Later</a>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>