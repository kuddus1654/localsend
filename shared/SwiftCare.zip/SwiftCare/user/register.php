<?php
include '../config/db.php';
session_start();

if (isset($_POST['register'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = md5($_POST['password']);

    try {
        // Check if email exists
        $check = $conn->query("SELECT * FROM users WHERE email='$email'");
        if ($check && $check->num_rows > 0) {
            $error = "Email already registered!";
        } else {
            $query = "INSERT INTO users (name, email, phone, password, role) VALUES ('$name', '$email', '$phone', '$password', 'user')";
            if ($conn->query($query)) {
                $_SESSION['success'] = "Registration Successful! Please Login.";
                header("Location: login.php");
                exit();
            } else {
                $error = "Error: Could not complete registration. Please try again.";
            }
        }
    } catch (Exception $e) {
        $error = "An unexpected database error occurred. Please try again later.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - SwiftCare</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body class="bg-light">
    <div class="auth-wrapper">
        <div class="auth-card glass-card hover-elevate">
            <div class="auth-header">
                <i class="fa-solid fa-user-plus text-primary"></i>
                <h3 class="mb-2">Create Account</h3>
                <p class="text-muted">Join the SwiftCare platform</p>
            </div>
            <?php if (isset($error)) {
                echo "<div class='alert alert-danger'>$error</div>";
            } ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Full Name</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fa-solid fa-user text-muted"></i></span>
                        <input type="text" name="name" class="form-control" placeholder="John Doe" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Email Address</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fa-solid fa-envelope text-muted"></i></span>
                        <input type="email" name="email" class="form-control" placeholder="john@example.com" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Phone Number</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fa-solid fa-phone text-muted"></i></span>
                        <input type="text" name="phone" class="form-control" placeholder="+1 234 567 8900" required>
                    </div>
                </div>
                <div class="mb-4">
                    <label class="form-label">Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fa-solid fa-lock text-muted"></i></span>
                        <input type="password" name="password" id="password" class="form-control"
                            placeholder="Create a strong password" required>
                        <span class="input-group-text" onclick="togglePassword()" style="cursor: pointer;">
                            <i class="fa fa-eye" id="toggleIcon"></i>
                        </span>
                    </div>
                </div>
                <button type="submit" name="register" class="btn btn-primary w-100 mb-3">Register Now</button>
            </form>
            <div class="text-center mt-3">
                <p class="mb-1 text-muted">Already have an account? <a href="login.php"
                        class="text-primary fw-bold text-decoration-none">Login here</a></p>
                <a href="../index.php" class="text-secondary text-decoration-none"><i
                        class="fa-solid fa-arrow-left me-1"></i>Back to Home</a>
            </div>
        </div>
    </div>

    <script>
        function togglePassword() {
            var passwordInput = document.getElementById("password");
            var toggleIcon = document.getElementById("toggleIcon");
            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                toggleIcon.classList.remove("fa-eye");
                toggleIcon.classList.add("fa-eye-slash");
            } else {
                passwordInput.type = "password";
                toggleIcon.classList.remove("fa-eye-slash");
                toggleIcon.classList.add("fa-eye");
            }
        }
    </script>
</body>

</html>