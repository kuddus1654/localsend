<?php
include 'includes/header.php';
include '../config/db.php';

$user_id = $_SESSION['user_id'];
?>

<div class="container-fluid">
    <h2 class="mb-4">My Bookings</h2>

    <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li class="nav-item">
            <button class="nav-link active" id="ambulance-tab" data-bs-toggle="tab" data-bs-target="#ambulance"
                type="button" role="tab">Ambulance</button>
        </li>
        <li class="nav-item">
            <button class="nav-link" id="pathology-tab" data-bs-toggle="tab" data-bs-target="#pathology" type="button"
                role="tab">Pathology</button>
        </li>
    </ul>

    <div class="tab-content mt-3" id="myTabContent">
        <!-- Ambulance History -->
        <div class="tab-pane fade show active" id="ambulance" role="tabpanel">
            <div class="card">
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Type</th>
                                <th>Pickup</th>
                                <th>Drop</th>
                                <th>Status</th>
                                <th>Payment</th>
                                <th>Fare</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $res = $conn->query("SELECT b.*, a.type FROM bookings b JOIN ambulances a ON b.ambulance_id = a.id WHERE user_id='$user_id' ORDER BY id DESC"); // Fixed table name
                            if ($res->num_rows > 0) {
                                while ($row = $res->fetch_assoc()) {
                                    $status_badge = match ($row['status']) {
                                        'pending' => 'bg-warning',
                                        'assigned' => 'bg-info',
                                        'completed' => 'bg-success',
                                        'cancelled' => 'bg-danger',
                                        default => 'bg-secondary'
                                    };

                                    $pay_badge = "<span class='badge bg-secondary'>Unknown</span>";
                                    if ($row['payment_status'] == 'paid') {
                                        $pay_badge = "<div class='d-flex align-items-center gap-2'><span class='badge bg-success'><i class='fa-solid fa-check'></i> Paid</span><a href='download_invoice.php?id={$row['id']}&type=ambulance' class='btn btn-sm btn-outline-secondary py-0 px-2' title='Download Invoice'><i class='fa-solid fa-file-invoice text-success'></i></a></div>";
                                    } elseif ($row['payment_status'] == 'verifying') {
                                        $pay_badge = "<span class='badge bg-warning text-dark'><i class='fa-solid fa-clock'></i> Verifying</span>";
                                    } else {
                                        $pay_badge = "<a href='payment.php?id={$row['id']}&type=ambulance' class='btn btn-sm btn-outline-primary rounded-pill px-3'>Pay Now</a>";
                                    }

                                    if ($row['status'] == 'cancelled')
                                        $pay_badge = "<span class='text-muted small'>N/A</span>";

                                    echo "<tr>
                                            <td>#{$row['id']}</td>
                                            <td>{$row['type']}</td>
                                            <td>{$row['pickup_location']}</td>
                                            <td>{$row['drop_location']}</td>
                                            <td><span class='badge $status_badge'>" . ucfirst($row['status']) . "</span></td>
                                            <td>{$pay_badge}</td>
                                            <td class='fw-bold text-success'>₹{$row['fare']}</td>
                                          </tr>";
                                }
                            } else {
                                echo "<tr><td colspan='7' class='text-center'>No ambulance bookings found</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Pathology History -->
        <div class="tab-pane fade" id="pathology" role="tabpanel">
            <div class="card">
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Test Name</th>
                                <th>Address</th>
                                <th>Status</th>
                                <th>Payment</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $res = $conn->query("SELECT pb.*, pt.test_name FROM pathology_bookings pb JOIN pathology_tests pt ON pb.test_id = pt.id WHERE user_id='$user_id' ORDER BY id DESC");
                            if ($res->num_rows > 0) {
                                while ($row = $res->fetch_assoc()) {
                                    $status_badge = match ($row['status']) {
                                        'pending' => 'bg-warning text-dark',
                                        'collected' => 'bg-info text-dark',
                                        'completed' => 'bg-success',
                                        'cancelled' => 'bg-danger',
                                        default => 'bg-secondary'
                                    };

                                    $pay_badge = "<span class='badge bg-secondary'>Unknown</span>";
                                    if ($row['payment_status'] == 'paid') {
                                        $pay_badge = "<div class='d-flex align-items-center gap-2'><span class='badge bg-success'><i class='fa-solid fa-check'></i> Paid</span><a href='download_invoice.php?id={$row['id']}&type=pathology' class='btn btn-sm btn-outline-secondary py-0 px-2' title='Download Invoice'><i class='fa-solid fa-file-invoice text-success'></i></a></div>";
                                    } elseif ($row['payment_status'] == 'verifying') {
                                        $pay_badge = "<span class='badge bg-warning text-dark'><i class='fa-solid fa-clock'></i> Verifying</span>";
                                    } else {
                                        $pay_badge = "<a href='payment.php?id={$row['id']}&type=pathology' class='btn btn-sm btn-outline-primary rounded-pill px-3'>Pay Now</a>";
                                    }

                                    if ($row['status'] == 'cancelled')
                                        $pay_badge = "<span class='text-muted small'>N/A</span>";

                                    echo "<tr>
                                            <td>#{$row['id']}</td>
                                            <td>{$row['test_name']}</td>
                                            <td>{$row['address']}</td>
                                            <td><span class='badge $status_badge'>" . ucfirst($row['status']) . "</span></td>
                                            <td>{$pay_badge}</td>
                                            <td>{$row['booking_date']}</td>
                                          </tr>";
                                }
                            } else {
                                echo "<tr><td colspan='6' class='text-center'>No pathology bookings found</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>