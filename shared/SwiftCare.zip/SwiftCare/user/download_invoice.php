<?php
session_start();
include '../config/db.php';

if (!isset($_SESSION['user_id']) || !isset($_GET['id']) || !isset($_GET['type'])) {
    die("Unauthorized access or invalid request");
}

$user_id = $_SESSION['user_id'];
$booking_id = intval($_GET['id']);
$type = $_GET['type'];

// Fetch user data
$user_res = $conn->query("SELECT * FROM users WHERE id=$user_id");
$user = $user_res->fetch_assoc();

$invoice_date = date('d M Y');
$booking_details = [];

if ($type == 'ambulance') {
    $stmt = $conn->prepare("SELECT b.*, a.type FROM bookings b JOIN ambulances a ON b.ambulance_id = a.id WHERE b.id=? AND b.user_id=?");
    $stmt->bind_param("ii", $booking_id, $user_id);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows > 0) {
        $row = $res->fetch_assoc();
        if ($row['payment_status'] != 'paid') {
            die("<h3 style='font-family: sans-serif; text-align: center; margin-top: 50px;'>Invoice not available for unpaid bookings.</h3>");
        }
        $booking_details = [
            'Description' => "Ambulance Booking ({$row['type']})",
            'Pickup' => $row['pickup_location'],
            'Drop' => $row['drop_location'],
            'Date' => $row['booking_date'],
            'Amount' => $row['fare']
        ];
    } else {
        die("Booking not found");
    }
} elseif ($type == 'pathology') {
    $stmt = $conn->prepare("SELECT pb.*, pt.test_name, pt.price FROM pathology_bookings pb JOIN pathology_tests pt ON pb.test_id = pt.id WHERE pb.id=? AND pb.user_id=?");
    $stmt->bind_param("ii", $booking_id, $user_id);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows > 0) {
        $row = $res->fetch_assoc();
        if ($row['payment_status'] != 'paid') {
            die("<h3 style='font-family: sans-serif; text-align: center; margin-top: 50px;'>Invoice not available for unpaid bookings.</h3>");
        }
        $booking_details = [
            'Description' => "Pathology Test ({$row['test_name']})",
            'Address' => $row['address'],
            'Date' => $row['booking_date'],
            'Amount' => $row['price']
        ];
    } else {
        die("Booking not found");
    }
} else {
    die("Invalid Type");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice #
        <?= strtoupper($type[0]) . str_pad($booking_id, 4, '0', STR_PAD_LEFT) ?> - SwiftCare
    </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Inter', sans-serif;
        }

        .invoice-card {
            background: #fff;
            padding: 50px;
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            margin-top: 50px;
        }

        .invoice-header {
            border-bottom: 2px solid #eee;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }

        .text-primary-brand {
            color: #4361ee;
        }

        @media print {
            body {
                background: white;
                -webkit-print-color-adjust: exact;
            }

            .invoice-card {
                box-shadow: none;
                border: none;
                margin-top: 0;
                padding: 0;
            }

            .no-print {
                display: none !important;
            }
        }
    </style>
</head>

<body>

    <div class="container mb-5">
        <div class="row justify-content-center">
            <div class="col-lg-8 border-1">
                <div class="invoice-card border">
                    <!-- Header -->
                    <div class="d-flex justify-content-between align-items-center invoice-header">
                        <div>
                            <h2 class="fw-bold text-primary-brand mb-0"><i
                                    class="fa-solid fa-truck-medical me-2"></i>SwiftCare</h2>
                            <p class="text-muted mb-0 mt-1">Advanced Healthcare Management</p>
                        </div>
                        <div class="text-end">
                            <h2 class="fw-bold mb-0 text-dark">INVOICE</h2>
                            <p class="text-muted mb-0">#
                                <?= strtoupper($type[0]) ?>-
                                <?= str_pad($booking_id, 5, '0', STR_PAD_LEFT) ?>
                            </p>
                            <p class="text-muted mb-0">Issue Date:
                                <?= $invoice_date ?>
                            </p>
                        </div>
                    </div>

                    <!-- Bill To -->
                    <div class="row mb-5">
                        <div class="col-sm-6">
                            <p class="text-muted mb-1 text-uppercase fw-bold" style="font-size: 0.85rem;">Billed To</p>
                            <h5 class="fw-bold mb-1">
                                <?= htmlspecialchars($user['name']) ?>
                            </h5>
                            <p class="mb-0 text-muted"><i class="fa-solid fa-envelope me-2"></i>
                                <?= htmlspecialchars($user['email']) ?>
                            </p>
                            <p class="mb-0 text-muted"><i class="fa-solid fa-phone me-2"></i>
                                <?= htmlspecialchars($user['phone']) ?>
                            </p>
                        </div>
                        <div class="col-sm-6 text-sm-end mt-4 mt-sm-0">
                            <p class="text-muted mb-1 text-uppercase fw-bold" style="font-size: 0.85rem;">Payment
                                Information</p>
                            <div class="d-inline-block bg-success bg-opacity-10 px-4 py-2 rounded">
                                <h4 class="text-success fw-bold mb-0"><i class="fa-solid fa-circle-check me-1"></i> PAID
                                </h4>
                                <small class="text-success d-block text-center mt-1">via UPI</small>
                            </div>
                        </div>
                    </div>

                    <!-- Table -->
                    <table class="table table-bordered mb-4">
                        <thead class="bg-light">
                            <tr>
                                <th class="py-3">Description</th>
                                <th class="py-3 text-end" style="width: 150px;">Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="py-4">
                                    <span class="fw-bold fs-5 d-block mb-2">
                                        <?= $booking_details['Description'] ?>
                                    </span>
                                    <small class="text-muted d-block mb-2"><i class="fa-regular fa-calendar me-1"></i>
                                        Booking Date:
                                        <?= $booking_details['Date'] ?>
                                    </small>

                                    <?php if ($type == 'ambulance'): ?>
                                        <div class="bg-light p-2 rounded small">
                                            <div class="mb-1"><strong><i
                                                        class="fa-solid fa-location-dot text-danger me-1"></i>
                                                    Pickup:</strong>
                                                <?= htmlspecialchars($booking_details['Pickup']) ?>
                                            </div>
                                            <div><strong><i class="fa-solid fa-flag-checkered text-success me-1"></i>
                                                    Drop:</strong>
                                                <?= htmlspecialchars($booking_details['Drop']) ?>
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <div class="bg-light p-2 rounded small">
                                            <div><strong><i class="fa-solid fa-location-dot text-danger me-1"></i>
                                                    Address:</strong>
                                                <?= htmlspecialchars($booking_details['Address']) ?>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td class="text-end align-middle fw-bold fs-5 text-dark">₹
                                    <?= number_format($booking_details['Amount'], 2) ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                    <!-- Summary -->
                    <div class="row justify-content-end mb-5">
                        <div class="col-md-6 col-lg-5">
                            <div class="d-flex justify-content-between border-bottom pb-2 mb-2">
                                <span class="text-muted">Subtotal:</span>
                                <span>₹
                                    <?= number_format($booking_details['Amount'], 2) ?>
                                </span>
                            </div>
                            <div class="d-flex justify-content-between border-bottom pb-2 mb-2">
                                <span class="text-muted">Tax (GST - 0%):</span>
                                <span>₹0.00</span>
                            </div>
                            <div class="d-flex justify-content-between mt-3 bg-light p-3 rounded">
                                <span class="fw-bold fs-5 text-dark">Total Paid:</span>
                                <span class="fw-bold fs-5 text-success">₹
                                    <?= number_format($booking_details['Amount'], 2) ?>
                                </span>
                            </div>
                        </div>
                    </div>

                    <!-- Footer -->
                    <div class="text-center text-muted border-top pt-4">
                        <p class="mb-1 text-dark fw-bold">Thank you for choosing SwiftCare for your medical needs!</p>
                        <small>If you have any questions about this invoice, please contact support at
                            support@swiftcare.com</small>
                    </div>
                </div>

                <!-- Print Actions -->
                <div class="text-center mt-4 no-print mb-5">
                    <button onclick="window.print()" class="btn btn-primary btn-lg rounded-pill shadow px-5"><i
                            class="fa-solid fa-print me-2"></i> Print / Save as PDF</button>
                    <a href="history.php" class="btn btn-light btn-lg rounded-pill shadow px-5 ms-3">Back to
                        Bookings</a>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Optionally auto-open print dialog on load
        // window.onload = function() { window.print(); }
    </script>

</body>

</html>