<?php
include 'includes/header.php';
include '../config/db.php';

if (isset($_POST['book_test'])) {
    $user_id = $_SESSION['user_id'];
    $test_id = $_POST['test_id'];
    $address = $_POST['address'];

    $query = "INSERT INTO pathology_bookings (user_id, test_id, address, status) VALUES ('$user_id', '$test_id', '$address', 'pending')";

    if ($conn->query($query)) {
        $booking_id = $conn->insert_id;
        echo "<script>alert('Test Booked Successfully! Please complete your payment.'); window.location='payment.php?id=$booking_id&type=pathology';</script>";
    } else {
        echo "<script>alert('Error: {$conn->error}');</script>";
    }
}
?>

<div class="container-fluid py-4">
    <div class="row mb-5">
        <div class="col-md-12 text-center text-md-start">
            <h2 class="fw-bold mb-2">Pathology Tests</h2>
            <p class="text-muted fs-5">Book lab tests from the comfort of your home. Safe, quick, and reliable.</p>
        </div>
    </div>

    <div class="row g-4">
        <?php
        $res = $conn->query("SELECT * FROM pathology_tests");
        if ($res->num_rows > 0) {
            while ($row = $res->fetch_assoc()) {
                echo "
                <div class='col-md-4'>
                    <div class='card glass-card hover-elevate h-100 border-0 d-flex flex-column' style='border-top: 4px solid var(--primary-color) !important;'>
                        <div class='card-body p-4 d-flex flex-column'>
                            <div class='d-flex justify-content-between align-items-start mb-3'>
                                <div class='bg-primary bg-opacity-10 rounded-circle d-inline-flex justify-content-center align-items-center' style='width: 50px; height: 50px;'>
                                    <i class='fa-solid fa-vial fa-lg text-primary'></i>
                                </div>
                                <span class='badge bg-light text-dark shadow-sm px-3 py-2 fs-6 border border-light'>₹" . number_format($row['price'], 2) . "</span>
                            </div>
                            <h4 class='card-title fw-bold mb-2'>{$row['test_name']}</h4>
                            <p class='card-text text-muted flex-grow-1'>{$row['description']}</p>
                            <button class='btn btn-primary w-100 mt-4 rounded-pill' data-bs-toggle='modal' data-bs-target='#testModal{$row['id']}'>
                                Book Test Now <i class='fa-solid fa-arrow-right ms-2'></i>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Booking Modal -->
                <div class='modal fade' id='testModal{$row['id']}' tabindex='-1' aria-hidden='true'>
                    <div class='modal-dialog modal-dialog-centered'>
                        <div class='modal-content border-0 shadow-lg' style='border-radius: 16px;'>
                            <div class='modal-header bg-light border-bottom-0' style='border-radius: 16px 16px 0 0;'>
                                <h5 class='modal-title fw-bold text-dark w-100 text-center position-relative'>
                                    <i class='fa-solid fa-flask text-primary me-2'></i> Book {$row['test_name']}
                                    <button type='button' class='btn-close position-absolute end-0 top-50 translate-middle-y me-2' data-bs-dismiss='modal'></button>
                                </h5>
                            </div>
                            <form method='POST'>
                                <div class='modal-body p-4'>
                                    <div class='alert alert-info bg-primary bg-opacity-10 border-0 rounded text-center mb-4'>
                                        <strong>Total Amount: </strong> ₹" . number_format($row['price'], 2) . "
                                    </div>
                                    <input type='hidden' name='test_id' value='{$row['id']}'>
                                    <div class='mb-3'>
                                        <label class='form-label fw-bold text-muted'>Home Collection Address</label>
                                        <div class='input-group'>
                                            <span class='input-group-text bg-light border-end-0'><i class='fa-solid fa-location-dot text-muted'></i></span>
                                            <textarea name='address' class='form-control border-start-0' rows='3' placeholder='Enter complete address with landmark...' required></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class='modal-footer border-top-0 bg-light' style='border-radius: 0 0 16px 16px;'>
                                    <button type='button' class='btn btn-secondary rounded-pill px-4' data-bs-dismiss='modal'>Cancel</button>
                                    <button type='submit' name='book_test' class='btn btn-primary rounded-pill px-4'>Confirm Booking</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                ";
            }
        } else {
            echo "<div class='col-12 text-center py-5'>
                     <i class='fa-solid fa-flask-vial fa-3x text-muted mb-3'></i>
                     <h4 class='text-muted'>No pathology tests available at the moment.</h4>
                   </div>";
        }
        ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>