<?php
include 'includes/header.php';
include '../config/db.php';

if (isset($_POST['book'])) {
    $user_id = $_SESSION['user_id'];
    $ambulance_id = $_POST['ambulance_id'];
    $pickup = $_POST['pickup'];
    $drop = $_POST['drop'];
    $distance = $_POST['distance']; // Demo: User enters distance manually

    // Calculate Fare
    $amb = $conn->query("SELECT base_fare, price_per_km FROM ambulances WHERE id=$ambulance_id")->fetch_assoc();
    $fare = $amb['base_fare'] + ($distance * $amb['price_per_km']);

    $query = "INSERT INTO bookings (user_id, ambulance_id, pickup_location, drop_location, distance, fare, status, booking_type) 
              VALUES ('$user_id', '$ambulance_id', '$pickup', '$drop', '$distance', '$fare', 'pending', 'emergency')";

    if ($conn->query($query)) {
        $booking_id = $conn->insert_id;
        echo "<script>alert('Booking Successful! Please complete your payment.'); window.location='payment.php?id=$booking_id&type=ambulance';</script>";
    } else {
        echo "<script>alert('Error: {$conn->error}');</script>";
    }
}
?>

<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-danger text-white">
                    <h4>Book an Ambulance</h4>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label>Pickup Location</label>
                            <textarea name="pickup" class="form-control" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label>Drop Location</label>
                            <textarea name="drop" class="form-control" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label>Ambulance Type</label>
                            <select name="ambulance_id" class="form-control" required>
                                <?php
                                $res = $conn->query("SELECT * FROM ambulances");
                                while ($row = $res->fetch_assoc()) {
                                    echo "<option value='{$row['id']}'>{$row['type']} (Base: ₹{$row['base_fare']} + ₹{$row['price_per_km']}/km)</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label>Estimated Distance (KM)</label>
                            <input type="number" step="0.1" name="distance" class="form-control"
                                placeholder="Enter approx distance" required>
                        </div>
                        <button type="submit" name="book" class="btn btn-danger w-100">Book Ambulance</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>