</div> <!-- End Container -->
<footer class="bg-white text-center py-4 mt-5"
    style="border-top: 1px solid rgba(0,0,0,0.05); box-shadow: 0 -5px 15px rgba(0,0,0,0.02);">
    <p class="mb-0 text-muted">&copy; <?php echo date('Y'); ?> <span
            style="color: var(--primary-color); font-weight: 600;">SwiftCare</span>. All Rights Reserved.</p>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>