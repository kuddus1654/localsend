<?php
include 'includes/header.php';

$user_id = $_SESSION['user_id'];
?>

<div class="row mb-5">
    <div class="col-md-12 text-center text-md-start">
        <h2 class="fw-bold mb-2">Welcome back,
            <span class="text-primary"><?php echo $_SESSION['user_name']; ?>! 👋</span>
        </h2>
        <p class="text-muted fs-5">What would you like to do today?</p>
    </div>
</div>

<div class="row justify-content-center g-4">
    <!-- Ambulance Booking -->
    <div class="col-md-4">
        <div class="card glass-card hover-elevate h-100 border-0"
            style="border-top: 5px solid var(--danger-color) !important;">
            <div class="card-body text-center d-flex flex-column">
                <div class="mb-4">
                    <div class="d-inline-flex align-items-center justify-content-center bg-danger bg-opacity-10 rounded-circle"
                        style="width: 80px; height: 80px;">
                        <i class="fa-solid fa-truck-medical fa-2x text-danger"></i>
                    </div>
                </div>
                <h4 class="card-title fw-bold mb-3">Book Ambulance</h4>
                <p class="card-text text-muted flex-grow-1">Request an emergency or scheduled ambulance to your location
                    immediately.</p>
                <a href="book_ambulance.php" class="btn btn-danger w-100 mt-3 rounded-pill">Book Now <i
                        class="fa-solid fa-arrow-right ms-2"></i></a>
            </div>
        </div>
    </div>

    <!-- Pathology Tests -->
    <div class="col-md-4">
        <div class="card glass-card hover-elevate h-100 border-0"
            style="border-top: 5px solid var(--primary-color) !important;">
            <div class="card-body text-center d-flex flex-column">
                <div class="mb-4">
                    <div class="d-inline-flex align-items-center justify-content-center bg-primary bg-opacity-10 rounded-circle"
                        style="width: 80px; height: 80px;">
                        <i class="fa-solid fa-flask fa-2x text-primary"></i>
                    </div>
                </div>
                <h4 class="card-title fw-bold mb-3">Pathology Tests</h4>
                <p class="card-text text-muted flex-grow-1">Book lab tests from the comfort of your home with certified
                    professionals.</p>
                <a href="pathology.php" class="btn btn-primary w-100 mt-3 rounded-pill">Book Test <i
                        class="fa-solid fa-arrow-right ms-2"></i></a>
            </div>
        </div>
    </div>

    <!-- Recent Bookings -->
    <div class="col-md-4">
        <div class="card glass-card hover-elevate h-100 border-0"
            style="border-top: 5px solid var(--warning-color) !important;">
            <div class="card-body text-center d-flex flex-column">
                <div class="mb-4">
                    <div class="d-inline-flex align-items-center justify-content-center bg-warning bg-opacity-10 rounded-circle"
                        style="width: 80px; height: 80px;">
                        <i class="fa-solid fa-list-check fa-2x text-warning"></i>
                    </div>
                </div>
                <h4 class="card-title fw-bold mb-3">My Bookings</h4>
                <p class="card-text text-muted flex-grow-1">View your past and active bookings, track status, and manage
                    appointments.</p>
                <a href="history.php" class="btn btn-warning text-dark w-100 mt-3 rounded-pill">View History <i
                        class="fa-solid fa-arrow-right ms-2"></i></a>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>