<?php
session_start();
include '../config/db.php';

if (isset($_POST['login'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = md5($_POST['password']);

    try {
        $query = "SELECT * FROM users WHERE email='$email' AND password='$password' AND role='user'";
        $result = $conn->query($query);

        if ($result && $result->num_rows == 1) {
            $row = $result->fetch_assoc();
            
            if (isset($row['status']) && $row['status'] === 'blocked') {
                $error = "Your account has been blocked by the administrator. Please contact support.";
            } else {
                $_SESSION['user_id'] = $row['id'];
                $_SESSION['user_name'] = $row['name'];
                header("Location: dashboard.php");
                exit();
            }
        } else {
            $error = "Invalid Email or Password!";
        }
    } catch (Exception $e) {
        $error = "An unexpected error occurred during login. Please try again later.";
        // In a real application, you would log $e->getMessage() to a file here.
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - SwiftCare</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body class="bg-light">
    <div class="auth-wrapper">
        <div class="auth-card glass-card hover-elevate">
            <div class="auth-header">
                <i class="fa-solid fa-truck-medical text-primary"></i>
                <h3 class="mb-2">Welcome Back</h3>
                <p class="text-muted">Sign in to your SwiftCare account</p>
            </div>
            <?php
            if (isset($_SESSION['success'])) {
                echo "<div class='alert alert-success'>{$_SESSION['success']}</div>";
                unset($_SESSION['success']);
            }
            if (isset($error)) {
                echo "<div class='alert alert-danger'>$error</div>";
            }
            ?>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Email Address</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fa-solid fa-envelope text-muted"></i></span>
                        <input type="email" name="email" class="form-control" placeholder="Enter your email" required>
                    </div>
                </div>
                <div class="mb-4">
                    <label class="form-label">Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fa-solid fa-lock text-muted"></i></span>
                        <input type="password" name="password" id="password" class="form-control"
                            placeholder="Enter password" required>
                        <span class="input-group-text" onclick="togglePassword()" style="cursor: pointer;">
                            <i class="fa fa-eye" id="toggleIcon"></i>
                        </span>
                    </div>
                </div>
                <button type="submit" name="login" class="btn btn-primary w-100 mb-3">Login to Dashboard</button>
            </form>
            <div class="text-center mt-3">
                <p class="mb-1 text-muted">New user? <a href="register.php"
                        class="text-primary fw-bold text-decoration-none">Create an account</a></p>
                <a href="../index.php" class="text-secondary text-decoration-none"><i
                        class="fa-solid fa-arrow-left me-1"></i>Back to Home</a>
            </div>
        </div>
    </div>

    <script>
        function togglePassword() {
            var passwordInput = document.getElementById("password");
            var toggleIcon = document.getElementById("toggleIcon");
            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                toggleIcon.classList.remove("fa-eye");
                toggleIcon.classList.add("fa-eye-slash");
            } else {
                passwordInput.type = "password";
                toggleIcon.classList.remove("fa-eye-slash");
                toggleIcon.classList.add("fa-eye");
            }
        }
    </script>
</body>

</html>