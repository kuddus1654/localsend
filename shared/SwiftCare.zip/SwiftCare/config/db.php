<?php
$conn = mysqli_connect("localhost", "root", "", "swiftcare");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>