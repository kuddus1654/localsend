CREATE DATABASE IF NOT EXISTS swiftcare;
USE swiftcare;
-- 👤 USERS TABLE
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    status ENUM('active', 'blocked') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
-- 🚑 DRIVERS TABLE
CREATE TABLE IF NOT EXISTS drivers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(15),
    password VARCHAR(255),
    ambulance_id INT,
    status ENUM('online', 'offline') DEFAULT 'offline',
    documents TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
-- 🚐 AMBULANCE TYPES
CREATE TABLE IF NOT EXISTS ambulances (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type VARCHAR(100),
    base_fare DECIMAL(10, 2),
    price_per_km DECIMAL(10, 2),
    equipment TEXT,
    image VARCHAR(255)
);
-- 🏥 HOSPITALS
CREATE TABLE IF NOT EXISTS hospitals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150),
    address TEXT,
    phone VARCHAR(15),
    emergency_status ENUM('available', 'unavailable') DEFAULT 'available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
-- 🧪 PATHOLOGY TESTS
CREATE TABLE IF NOT EXISTS pathology_tests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    test_name VARCHAR(150),
    description TEXT,
    price DECIMAL(10, 2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
-- 📦 BOOKINGS
CREATE TABLE IF NOT EXISTS bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    driver_id INT NULL,
    ambulance_id INT,
    pickup_location TEXT,
    drop_location TEXT,
    distance DECIMAL(10, 2),
    fare DECIMAL(10, 2),
    status ENUM(
        'pending',
        'assigned',
        'on_the_way',
        'reached',
        'completed',
        'cancelled'
    ) DEFAULT 'pending',
    payment_status ENUM('pending', 'verifying', 'paid', 'failed') DEFAULT 'pending',
    booking_type ENUM('emergency', 'scheduled') DEFAULT 'emergency',
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (driver_id) REFERENCES drivers(id),
    FOREIGN KEY (ambulance_id) REFERENCES ambulances(id)
);
-- 🧾 PATHOLOGY BOOKINGS
CREATE TABLE IF NOT EXISTS pathology_bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    test_id INT,
    address TEXT,
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('pending', 'collected', 'completed') DEFAULT 'pending',
    payment_status ENUM('pending', 'verifying', 'paid', 'failed') DEFAULT 'pending',
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (test_id) REFERENCES pathology_tests(id)
);
-- ⭐ CMS CONTENT (Dynamic Website Control)
CREATE TABLE IF NOT EXISTS cms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    section VARCHAR(100),
    content TEXT
);
-- 💳 DEFAULT UPI ID
INSERT INTO cms (section, content)
SELECT 'upi_id',
    'admin@upi'
WHERE NOT EXISTS (
        SELECT *
        FROM cms
        WHERE section = 'upi_id'
    );
-- 💰 DRIVER EARNINGS
CREATE TABLE IF NOT EXISTS driver_earnings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    driver_id INT,
    booking_id INT,
    amount DECIMAL(10, 2),
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (driver_id) REFERENCES drivers(id),
    FOREIGN KEY (booking_id) REFERENCES bookings(id)
);
-- 🔐 DEFAULT ADMIN
INSERT INTO users (name, email, phone, password, role)
SELECT 'Admin',
    'admin@swiftcare.com',
    '9999999999',
    MD5('123456'),
    'admin'
WHERE NOT EXISTS (
        SELECT *
        FROM users
        WHERE email = 'admin@swiftcare.com'
    );
-- 👤 DEFAULT USER
INSERT INTO users (name, email, phone, password, role)
SELECT 'Test User',
    'user@swiftcare.com',
    '8888888888',
    MD5('123456'),
    'user'
WHERE NOT EXISTS (
        SELECT *
        FROM users
        WHERE email = 'user@swiftcare.com'
    );
-- 🚑 SAMPLE AMBULANCE TYPES
INSERT INTO ambulances (type, base_fare, price_per_km, equipment)
SELECT *
FROM (
        SELECT 'Basic Ambulance' AS type,
            500 AS base_fare,
            25 AS price_per_km,
            'Stretcher, Oxygen' AS equipment
    ) AS tmp
WHERE NOT EXISTS (
        SELECT *
        FROM ambulances
        WHERE type = 'Basic Ambulance'
    )
LIMIT 1;
INSERT INTO ambulances (type, base_fare, price_per_km, equipment)
SELECT *
FROM (
        SELECT 'ICU Ambulance',
            1500,
            50,
            'Ventilator, Cardiac Monitor'
    ) AS tmp
WHERE NOT EXISTS (
        SELECT *
        FROM ambulances
        WHERE type = 'ICU Ambulance'
    )
LIMIT 1;
INSERT INTO ambulances (type, base_fare, price_per_km, equipment)
SELECT *
FROM (
        SELECT 'Oxygen Ambulance',
            800,
            30,
            'Oxygen Cylinder'
    ) AS tmp
WHERE NOT EXISTS (
        SELECT *
        FROM ambulances
        WHERE type = 'Oxygen Ambulance'
    )
LIMIT 1;
-- 🚗 SAMPLE DRIVER
INSERT INTO drivers (name, email, phone, password, status)
SELECT 'Test Driver',
    'driver@swiftcare.com',
    '7777777777',
    MD5('123456'),
    'offline'
WHERE NOT EXISTS (
        SELECT *
        FROM drivers
        WHERE email = 'driver@swiftcare.com'
    );