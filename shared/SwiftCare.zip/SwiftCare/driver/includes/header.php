<?php
session_start();
if (!isset($_SESSION['driver_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Driver Panel - SwiftCare</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body class="bg-light">

    <nav class="navbar navbar-expand-lg sticky-top" style="border-bottom: 3px solid var(--dark-color);">
        <div class="container">
            <a class="navbar-brand text-dark" href="dashboard.php"
                style="background: none; -webkit-text-fill-color: var(--dark-color);"><i
                    class="fa-solid fa-ambulance"></i> Driver Panel</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="dashboard.php"><i class="fa-solid fa-gauge me-1"></i>
                            Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="my_rides.php"><i class="fa-solid fa-route me-1"></i>
                            My Rides</a></li>
                    <li class="nav-item"><a class="nav-link text-danger" href="logout.php"><i
                                class="fa-solid fa-right-from-bracket me-1"></i> Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container dashboard-container">