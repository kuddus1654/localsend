<?php
include 'includes/header.php';
include '../config/db.php';

$driver_id = $_SESSION['driver_id'];

// Toggle Availability
if (isset($_POST['toggle_status'])) {
    $current_status = $_POST['current_status'];
    $new_status = ($current_status == 'online') ? 'offline' : 'online';
    $conn->query("UPDATE drivers SET status='$new_status' WHERE id='$driver_id'");
    echo "<meta http-equiv='refresh' content='0'>";
}

// Fetch Status
$driver = $conn->query("SELECT * FROM drivers WHERE id='$driver_id'")->fetch_assoc();
$status = $driver['status'];
$status_color = ($status == 'online') ? 'success' : 'secondary';
$status_icon = ($status == 'online') ? 'fa-circle-check' : 'fa-circle-pause';

// Fetch Assigned Rides
$assigned_rides = $conn->query("SELECT COUNT(*) FROM bookings WHERE driver_id='$driver_id' AND status='assigned'")->fetch_row()[0];
$ongoing_rides = $conn->query("SELECT COUNT(*) FROM bookings WHERE driver_id='$driver_id' AND status IN ('on_the_way', 'reached')")->fetch_row()[0];
$completed_rides = $conn->query("SELECT COUNT(*) FROM bookings WHERE driver_id='$driver_id' AND status='completed'")->fetch_row()[0];
?>

<div class="row mb-5 mt-3">
    <div class="col-md-12 text-center">
        <div class="d-inline-flex align-items-center justify-content-center bg-dark text-white rounded-circle mb-3 shadow"
            style="width: 80px; height: 80px;">
            <i class="fa-solid fa-ambulance fa-2x"></i>
        </div>
        <h2 class="fw-bold">Welcome,
            <span class="text-primary"><?php echo $_SESSION['driver_name']; ?></span>
        </h2>
        <p class="text-muted fs-5 mb-4">View your assigned rides and manage your availability status.</p>

        <form method="POST" class="d-inline-block p-4 glass-card bg-white mt-2">
            <h5 class="mb-3">Duty Status</h5>
            <input type="hidden" name="current_status" value="<?php echo $status; ?>">
            <button type="submit" name="toggle_status"
                class="btn btn-<?php echo $status_color; ?> btn-lg rounded-pill px-4 shadow-sm hover-elevate">
                <i class="fa-solid <?php echo $status_icon; ?> me-2"></i>
                Currently: <?php echo ucfirst($status); ?> (Click to Toggle)
            </button>
        </form>
    </div>
</div>

<div class="row g-4 justify-content-center">
    <div class="col-md-4">
        <div class="card glass-card hover-elevate h-100 border-0 text-center d-flex flex-column"
            style="border-top: 5px solid var(--warning-color) !important;">
            <div class="card-body p-4 d-flex flex-column">
                <div class="mb-3">
                    <div class="d-inline-flex bg-warning bg-opacity-10 rounded-circle p-3">
                        <i class="fa-solid fa-bell fa-2x text-warning"></i>
                    </div>
                </div>
                <h1 class="display-4 fw-bold mb-1"><?php echo $assigned_rides; ?></h1>
                <h5 class="text-muted mb-4">New Assigned</h5>
                <a href="my_rides.php" class="btn btn-dark w-100 rounded-pill mt-auto">View Alerts <i
                        class="fa-solid fa-arrow-right ms-2"></i></a>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card glass-card hover-elevate h-100 border-0 text-center d-flex flex-column"
            style="border-top: 5px solid var(--primary-color) !important;">
            <div class="card-body p-4 d-flex flex-column">
                <div class="mb-3">
                    <div class="d-inline-flex bg-primary bg-opacity-10 rounded-circle p-3">
                        <i class="fa-solid fa-route fa-2x text-primary"></i>
                    </div>
                </div>
                <h1 class="display-4 fw-bold mb-1"><?php echo $ongoing_rides; ?></h1>
                <h5 class="text-muted mb-4">Ongoing Trips</h5>
                <a href="my_rides.php" class="btn btn-primary w-100 rounded-pill mt-auto">Update Status <i
                        class="fa-solid fa-location-arrow ms-2"></i></a>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card glass-card hover-elevate h-100 border-0 text-center d-flex flex-column"
            style="border-top: 5px solid var(--success-color) !important;">
            <div class="card-body p-4 d-flex flex-column">
                <div class="mb-3">
                    <div class="d-inline-flex bg-success bg-opacity-10 rounded-circle p-3">
                        <i class="fa-solid fa-check-double fa-2x text-success"></i>
                    </div>
                </div>
                <h1 class="display-4 fw-bold mb-1"><?php echo $completed_rides; ?></h1>
                <h5 class="text-muted mb-0">Completed</h5>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>