<?php
include 'includes/header.php';
include '../config/db.php';

$driver_id = $_SESSION['driver_id'];

// Actions
if (isset($_GET['action']) && isset($_GET['id'])) {
    $booking_id = $_GET['id'];
    $action = $_GET['action'];
    $new_status = '';

    if ($action == 'start')
        $new_status = 'on_the_way';
    if ($action == 'reach')
        $new_status = 'reached';
    if ($action == 'complete')
        $new_status = 'completed';

    if ($new_status) {
        $conn->query("UPDATE bookings SET status='$new_status' WHERE id='$booking_id' AND driver_id='$driver_id'");
        echo "<script>window.location='my_rides.php';</script>";
    }
}
?>

<h2 class="mb-4">My Rides</h2>
<div class="card">
    <div class="card-body">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Booking ID</th>
                    <th>Pickup</th>
                    <th>Drop</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $res = $conn->query("SELECT * FROM bookings WHERE driver_id='$driver_id' ORDER BY id DESC");
                if ($res->num_rows > 0) {
                    while ($row = $res->fetch_assoc()) {
                        $status = $row['status'];
                        $btn = "";

                        if ($status == 'assigned') {
                            $btn = "<a href='my_rides.php?action=start&id={$row['id']}' class='btn btn-primary btn-sm'>Start Ride</a>";
                        } elseif ($status == 'on_the_way') {
                            $btn = "<a href='my_rides.php?action=reach&id={$row['id']}' class='btn btn-warning btn-sm'>Reached</a>";
                        } elseif ($status == 'reached') {
                            $btn = "<a href='my_rides.php?action=complete&id={$row['id']}' class='btn btn-success btn-sm'>Complete</a>";
                        } else {
                            $btn = "<span class='text-muted'>Completed</span>";
                        }

                        echo "<tr>
                                <td>#{$row['id']}</td>
                                <td>{$row['pickup_location']}</td>
                                <td>{$row['drop_location']}</td>
                                <td><span class='badge bg-info'>$status</span></td>
                                <td>$btn</td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='5' class='text-center'>No rides assigned</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'includes/footer.php'; ?>